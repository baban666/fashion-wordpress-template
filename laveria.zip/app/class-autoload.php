<?php
function LavAutoLoader($className) {
	if (file_exists(get_template_directory() . '/app/' . str_replace('\\', '/', $className) . '.php')) {
		if(!class_exists($className)){
			require_once get_template_directory() . '/app/' . str_replace('\\', '/', $className) . '.php';
			return true;
		}
	}

}

spl_autoload_register('LavAutoLoader');
