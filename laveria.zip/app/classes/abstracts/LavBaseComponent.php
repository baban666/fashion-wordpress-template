<?php


namespace classes\abstracts;


use classes\providers\LavComponentsProvider;
use interfaces\ILavComponent;

abstract class LavBaseComponent implements ILavComponent{

	public $name;
	public $settings;
	public $helper;
	public $metaBoxes;
	public $components;

	public function __construct($name, $settingsProvider, $helpersProvider, $metaBoxesProvider) {
		$this->name = $name;
		$this->settings = $settingsProvider->getSettings();
		$this->helper = $helpersProvider;
		$this->metaBoxes = $metaBoxesProvider;
		$this->components = LavComponentsProvider::getInstance();
	}

	public function getName() {
		return $this->name;
	}

	public function getValue($key) {
		return !empty($this->settings[$key]) ? $this->settings[$key] : null;
	}

	abstract public function render($args = null);



}
