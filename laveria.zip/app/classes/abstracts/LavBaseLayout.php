<?php


namespace classes\abstracts;


use interfaces\ILavLayout;

abstract class LavBaseLayout implements ILavLayout{

	public $name;
	public $settings;
	public $helper;
	public $metaBoxes;
	public $components;

	public function __construct($name, $settingsProvider, $helpersProvider, $metaBoxesProvider, $componentsProvider ) {
		$this->name = $name;
		$this->settings = $settingsProvider->getSettings();
		$this->helper = $helpersProvider;
		$this->metaBoxes = $metaBoxesProvider;
		$this->components = $componentsProvider;
	}

	public function renderBodyHead(){
	?>
	<!doctype html>
	<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11">
		<?php wp_head(); ?>
	</head>
	<?php
	}

	abstract public function renderHeader();
	abstract public function renderPage();
	abstract public function renderIndex();
	abstract public function renderSingle();
	abstract public function renderSidebar();
	abstract public function renderFooter();
	abstract public function renderBodyFooter();


	public function getName() {
		return $this->name;
	}

	public function getValue($key) {
		return !empty($this->settings[$key]) ? $this->settings[$key] : null;
	}

	public function render404Page($args = null) {
		$this->renderHeader();

		if($this->settings['general-page-header-layout'] === 'full-width' ){
			$this->components->getComponent( '404-header' )->render();
		}
		$this->components->getComponent('404')->render();
	}

	public function renderSearchPage($args = null) {
		$this->renderHeader();
		$componentType = $this->helper->getComponentType();
		if($this->getValue('general-blog-header-layout') === 'full-width'){
			$this->components->getComponent( 'search-header' )->render();
		}
		$this->components->getComponent('search')->render($componentType);
	}
}
