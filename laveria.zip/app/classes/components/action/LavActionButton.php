<?php


namespace classes\components\action;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavActionButton extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$customButton = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-action' );
		$customButtonTarget = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-action-new-window' ) ? '_blank' : '_self';
		$buttonTarget = $this->getValue( 'header-action-new-window' ) ? '_blank' : '_self';

		$customText = $customButton
			? $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-action-text' )
			: $this->getValue( 'header-action-text' );
		$customLink = $customButton
			? $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-action-link' )
			: $this->getValue( 'header-action-link' );
		$customTarget = $customButton
			? $customButtonTarget
			: $buttonTarget
		?>
		<?php if ( $customText && $customLink ): ?>
            <a class="lav-btn-default" href="<?php echo esc_url( $customLink ) ?>"
               target="<?php echo esc_attr( $customTarget ); ?>">
				<?php echo esc_html( $customText ) ?>
            </a>
		<?php endif; ?>
		<?php

	}

}
