<?php


namespace classes\components\author;

use classes\abstracts\LavBaseComponent;


class LavArchiveAuthorInfo extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render($args = null) {
	    $authorUrl = $this->helper->removeProtocol( get_the_author_meta( 'user_url' ) );
		?>
        <section>
            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 author-avatar">
                        <div class="author-avatar-box">
                            <?php echo get_avatar( get_the_author_meta( 'user_email' ), 300, '', '', array(
                                'class'      => 'card-img-top-widget'
                            ) ); ?>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 author-desc">
                        <div class="author-desc-box">
                            <p>
                                <?php the_author_meta( 'description' ); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row author-info">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 author-name">
                    <div class="author-name-box">
                        <h4 class="author-name">
                            <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
                        </h4>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 author-contact">
                    <div class="author-contact-box">
                        <?php if ( get_the_author_meta( 'user_url' ) ): ?>
                            <div class="website">
                                <a class="author-website" href="<?php the_author_meta( 'user_url' ); ?>">
                                    <i class="fas fa-globe"></i><?php echo esc_html(  $authorUrl); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="email">
                            <a class="author-email" href="mailto:<?php the_author_meta( 'user_email' ); ?>">
                                <i class="fas fa-envelope-open-text"></i><?php the_author_meta( 'user_email' ); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
		<?php
	}
}
