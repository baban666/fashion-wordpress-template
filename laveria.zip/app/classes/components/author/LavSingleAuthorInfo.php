<?php


namespace classes\components\author;


use classes\abstracts\LavBaseComponent;

class LavSingleAuthorInfo extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <section class="author-box">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 single-author-image">
	                <?php $this->components->getComponent( 'section-author-avatar' )->render(); ?>
                </div>
                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 single-author-text">
                    <h2 class="author-name">
                        <?php echo get_the_author_meta('display_name', get_the_author_meta( 'ID' )); ?>
                    </h2>
                    <p><?php the_author_meta( 'description' ); ?></p>
                    <a  class="lav-btn-outline" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
                    <?php esc_html_e( 'View All Posts', 'laveria' ); ?>
                    </a>
                </div>
            </div>
        </section>
		<?php
	}
}
