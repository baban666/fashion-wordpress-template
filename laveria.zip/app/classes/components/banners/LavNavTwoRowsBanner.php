<?php


namespace classes\components\banners;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavNavTwoRowsBanner extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-two-rows-header-background') );

		$bgColor = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl =  $bannerDetails['image-url'];
		$imageAlt =  $bannerDetails['image-alt'];

        ?>
        <header class="lav-hero-two-rows" <?php echo sprintf( 'style="background: linear-gradient(155deg, %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>>
            <div class="hero-text">
                <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>">
                    <div class="banner-info">
	                    <?php if($this->getValue('header-logo')): ?>
		                    <?php $this->components->getComponent( 'logo' )->render(); ?>
	                    <?php endif; ?>
	                    <?php $this->components->getComponent( 'mail-top' )->render(); ?>
	                    <?php $this->components->getComponent( 'address-top' )->render(); ?>
	                    <?php $this->components->getComponent( 'social' )->render(); ?>
                    </div>
                </div><!-- .container(-fluid) -->
            </div>
			<?php if ( ! empty( $imageUrl ) ): ?>
                <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image" alt="<?php echo esc_attr($imageAlt)?>">
                <div class="overlay"></div>
            <?php endif; ?>
        </header>
        <?php

	}

}
