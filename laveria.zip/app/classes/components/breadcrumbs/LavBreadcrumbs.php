<?php


namespace classes\components\breadcrumbs;


use classes\abstracts\LavBaseComponent;



class LavBreadcrumbs extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    if (function_exists('the_crumbs')){
		    the_crumbs($args);
        }
	}
}
