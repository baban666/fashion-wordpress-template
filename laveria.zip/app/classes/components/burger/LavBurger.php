<?php


namespace classes\components\burger;


use classes\abstracts\LavBaseComponent;



class LavBurger extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$isActive = $this->getValue('header-burger-menu');
	    if ($this->getValue('general-layout') == 'custom-menu-layout'){
		    $isActive = $this->getValue('general-layout');
        }
	    if (!empty($isActive) && $this->getValue('header-burger-menu-log-in')){
		    $isActive = is_user_logged_in();
        }
	    ?>
		<?php if(!empty($isActive)): ?>
            <button class="burger-sidebar-button <?php esc_html_e($args); ?>"  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                <i class="las la-ellipsis-v"></i>
            </button>
		<?php endif; ?>
        <?php
	}

}
