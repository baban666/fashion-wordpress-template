<?php


namespace classes\components\burger;


use classes\abstracts\LavBaseComponent;


class LavBurgerSidebar extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$isActive = $this->getValue('header-burger-menu');
		if ($this->getValue('general-layout') == 'custom-menu-layout'){
			$isActive = $this->getValue('general-layout');
		}

		if (!empty($isActive) && $this->getValue('header-burger-menu-log-in')){
			$isActive = is_user_logged_in();
		}
		?>
		<?php if(!empty($isActive)): ?>
            <aside id="offcanvasRight" class="burger offcanvas offcanvas-end" tabindex="-1" aria-labelledby="offcanvasRightLabel">
                <div class="offcanvas-header">
					<?php if($this->getValue('header-burger-menu-avatar')): ?>
						<?php $this->components->getComponent( 'user-avatar' )->render(); ?>
					<?php endif; ?>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                        <i class="las la-times"></i>
                    </button>
                </div>
				<?php if ( is_active_sidebar( 'lav-burger-1' ) ) : ?>
                    <div class="offcanvas-body">
						<?php dynamic_sidebar( 'lav-burger-1' ); ?>
                    </div>
				<?php endif; ?>
            </aside><!-- #secondary-burger -->
		<?php endif; ?>

		<?php

	}

}
