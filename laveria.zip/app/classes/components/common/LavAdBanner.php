<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;

class LavAdBanner extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$content = $this->getValue('header-ad-banner-content');
		if(!empty($args)){
			$content = $args;
		}
		printf( '<div class="alice-ad-banner col-12 mb-4">%1$s</div>', do_shortcode($content)  );
	}
}
