<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavAuthorAvatar extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$customAvatar = $this->helper->getUserProfileSetting( 'alice-profile-avatar', get_the_author_meta( 'ID') );
		?>

		<?php if (!empty($customAvatar) && !empty($customAvatar['url'])): ?>
            <div class="author">
                <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>">
                    <img alt="<?php echo esc_html($customAvatar["alt"]) ?>" src="<?php echo esc_url($customAvatar["thumbnail"]) ?>" class="avatar avatar-96 photo" height="96" width="96" loading="lazy">
                    <span><?php the_author(); ?></span>
                </a>
            </div>
        <?php else: ?>
            <div class="author">
                <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>">
					<?php echo get_avatar( get_the_author_meta( 'ID' ) ); ?>
                    <span><?php the_author(); ?></span>
                </a>
            </div>
		<?php endif; ?>

		<?php

	}
}
