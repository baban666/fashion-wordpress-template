<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavAuthorRating extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <div class="author-rating">
	        <?php if ( !empty($args['title'])): ?>
                <div class="author-rating-title"><?php echo esc_html( $args['title'] ); ?></div>
	        <?php endif; ?>
	        <?php if ( !empty($args['score'])): ?>
                <div class="score">
                    <div class="range">
				        <?php LavHelpersProvider::getScore( intval( $args['score'] ) ); ?>
                    </div>
                </div>
	        <?php endif; ?>
        </div>
		<?php

	}
}
