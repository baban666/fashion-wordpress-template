<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavBookMeta extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

	    $genre = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-genre' );
	    $date = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-date' );
	    $publisher = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-publisher' );
	    $ibsn = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-ibsn' );
	    $pages = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-pages' );
	    $language = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-language' );
		?>
        <div class="row book-meta">
            <div class="col-md-12 col-lg-6 book-meta-column-left">
	            <?php if ( !empty($genre)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('Genre:', 'laveria')?></span>
                        <span><?php echo esc_html($genre)?></span>
                    </div>
	            <?php endif; ?>
	            <?php if ( !empty($date)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('Date Publication:', 'laveria')?></span>
                        <span><?php echo esc_html($date)?></span>
                    </div>
	            <?php endif; ?>
	            <?php if ( !empty($publisher)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('Publisher:', 'laveria')?></span>
                        <span><?php echo esc_html($publisher)?></span>
                    </div>
	            <?php endif; ?>
            </div>
            <div class="col-md-12 col-lg-6 book-meta-column-right">
	            <?php if ( !empty($ibsn)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('IBSN:', 'laveria')?></span>
                        <span><?php echo esc_html($ibsn)?></span>
                    </div>
	            <?php endif; ?>
	            <?php if ( !empty($pages)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('Pages:', 'laveria')?></span>
                        <span><?php echo esc_html($pages)?></span>
                    </div>
	            <?php endif; ?>
	            <?php if ( !empty($language)): ?>
                    <div class="value">
                        <span><?php echo esc_html__('Language:', 'laveria')?></span>
                        <span><?php echo esc_html($language)?></span>
                    </div>
	            <?php endif; ?>
            </div>
        </div>
		<?php

	}
}
