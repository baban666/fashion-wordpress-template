<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavContentNone extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <section class="no-results not-found">
            <div class="page-header">
                <h2 class="page-info"><?php esc_html_e( 'Nothing Found', 'laveria' ); ?></h2>
            </div><!-- .page-header -->

            <div class="page-content">
				<?php
				if ( is_home() && current_user_can( 'publish_posts' ) ) :

					printf(
						'<p>' . wp_kses(
						/* translators: 1: link to WP admin new post page. */
							__( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'laveria' ),
							array(
								'a' => array(
									'href' => array(),
								),
							)
						) . '</p>',
						esc_url( admin_url( 'post-new.php' ) )
					);

                elseif ( is_search() ) :
					?>
                    <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'laveria' ); ?></p>
					<?php
					get_search_form();

				else :
					?>

                    <p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'laveria' ); ?></p>
					<?php
					get_search_form();

				endif;
				?>
            </div><!-- .page-content -->
        </section><!-- .no-results -->
		<?php

	}
}
