<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;

class LavIrRating extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <div class="ir-rating" data-rating="<?php echo esc_attr($args['score']); ?>">
	        <?php if ( !empty($args['url'])): ?>
                <div class="alice-indie-image">
                    <img src="<?php echo esc_url($args['url']); ?>" alt="<?php echo esc_attr($args['alt']); ?>" class="ir-logo">
                </div>
	        <?php endif; ?>
            <div class="progress-wrapper">
                <div class="row">
                    <div class="col">
                        <div class="alice-progress-line">
                            <div class="alice-tooltip"></div>
                            <div class="progress">
                                <div class="determinate">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-2 round-progress">
                        <div class="loader">
                        <span class="loader-mask-left">
                            <span class="loader-line"></span>
                        </span>
                            <span class="loader-mask-right">
                            <span class="loader-line"></span>
                        </span>
                        <?php if ( !empty($args['score'])): ?>
                            <div class="value">
                                <?php echo esc_html( number_format( $args['score'], 1 ) ) ?>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

		<?php

	}
}
