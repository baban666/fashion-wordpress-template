<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavPostNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		the_post_navigation(
			array(
				'prev_text' => '<i class="las la-arrow-left"></i><span class="nav-subtitle">' . esc_html__( 'Previous Post', 'laveria' ) . '</span>',
				'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next Post', 'laveria' ) . '</span><i class="las la-arrow-right"></i>',
			)
		);
	}
}
