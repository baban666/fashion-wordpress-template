<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavProsCons extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $values = null, $type = 'pros' ) {
		if ( empty( $values ) || ! is_array( $values ) ) {
			return;
		}
		$icon = $type == 'pros'
			? '<i class="las la-plus"></i>'
			: '<i class="las la-minus"></i>';
		?>
        <div class="pros-cons">
			<?php foreach ( $values as $value ): ?>
				<?php
				if ( empty( $value[ 'meta-single-reading-' . $type . '-value' ] ) ) {
					continue;
				}
				$text = ! empty( $value[ 'meta-single-reading-' . $type . '-value' ] ) ? $value[ 'meta-single-reading-' . $type . '-value' ] : '';
				echo sprintf(
					wp_kses(
						'<div class="pros-cons-item"><div class="' . $type . '-icon"> %1s </div> <div class="pros-cons-text">%2s</div> </div>',
						array(
							'div'  => array(
								'class' => array(),
							),
							'i'    => array(
								'class' => array(),
							),
							'span' => array(
								'class' => array(),
							),
						)
					),
					$icon, $text
				); ?>
			<?php endforeach; ?>
        </div>
		<?php
	}
}
