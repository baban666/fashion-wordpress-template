<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavReviewStars extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

    ?>
    <div class="amazon-review">
        <div class="amazon-image">
            <img src="<?php echo esc_url( $args['url'] ); ?>" alt="<?php echo esc_url( $args['alt'] ); ?>" class="amazon-logo">
        </div>
	    <?php LavHelpersProvider::getAmazonStars($args['score']); ?>
    </div>
    <?php

	}
}
