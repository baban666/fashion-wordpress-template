<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavShareButtons extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render($args = null) {
		$links = $this->renderLinks($this->getValue('shop-share-buttons'));

		if (!empty($links)){
			echo '<div class="custom-social-share"><div class=" branded">' . wp_kses_post($links) . '</div></div>';
		}

	}

	public function renderLinks($platforms = array()) {
		$links = array(
			'facebook' => '<a class="fb"  href="https://www.facebook.com/sharer/sharer.php?u=' . esc_html__(get_permalink()) . '" target="_blank"><i class="lab la-facebook-f"></i></a>',
			'twitter'  => '<a class="tw"  href="https://twitter.com/intent/tweet?url=' . esc_html__(get_permalink()) . '" target="_blank"><i class="lab la-twitter"></i></a>',
			'pinterest'=> '<a class="pinterest"  href="https://pinterest.com/pin/create/button/?url=' . esc_html__(get_permalink()) . '&media=' . wp_get_attachment_url(get_post_thumbnail_id()).'&description='.esc_html(get_the_title()).'" target="_blank"><i class="lab la-pinterest-p"></i></a>',
			'whatsapp' => '<a class="whatsapp" href="https://api.whatsapp.com/send?text=' . esc_html__(get_permalink()) . '" target="_blank"><i class="lab la-whatsapp"></i></a>',
			'telegram' => '<a class="telegram" href="https://t.me/share/url?url=' . esc_html__(get_permalink()) . '" target="_blank"><i class="lab la-telegram"></i></a>',
			'email'    => '<a class="vimeo"  href="mailto:?subject=Check this out: ' . esc_html(get_the_title()) . '&body=Check out this link: ' . esc_html__(get_permalink()) . '"><i class="las la-envelope"></i></a>',
			'linkedin' => '<a class="in"  href="https://www.linkedin.com/shareArticle?mini=true&url=' . esc_html__(get_permalink()) . '&title=' . esc_html(get_the_title()) . '" target="_blank"><i class="lab la-linkedin-in"></i></a>'
		);

		$html = '';
		if(!empty($platforms) && is_array($platforms)) {
			foreach ($platforms as $platform) {
				if (isset($links[$platform])) {
					$html .= $links[$platform];
				}
			}
		}

		return $html;
	}


}
