<?php


namespace classes\components\common;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;

class LavUserAvatar extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		if (is_user_logged_in()) {
			// User is logged in, get user's avatar and name
			$current_user_id = get_current_user_id();
			$current_user_data = get_userdata($current_user_id);
			$user_display_name = $current_user_data->display_name;
			$user_avatar = get_avatar($current_user_id, 45); // is the avatar size in pixels
			$customAvatar = $this->helper->getUserProfileSetting( 'alice-profile-avatar', $current_user_id );
				if (!empty($customAvatar["thumbnail"])){
					$user_avatar = '<img alt="'. esc_html($customAvatar["alt"]) .'" src="'. esc_url($customAvatar["thumbnail"]).'" class="avatar avatar-96 photo" height="45" width="45" loading="lazy">';
				}
		} else {
			// User is not logged in, set a placeholder using the default WordPress avatar
			$user_display_name = esc_html__('Guest', 'laveria');
			$user_avatar = get_avatar('', 45, '', esc_html__('Guest Avatar', 'laveria'), array('class' => 'avatar')); // Default WordPress avatar
		}

		printf( '<div class="user-profile"><div class="user-avatar">%1$s</div><div class="user-name">%2$s</div></div>', $user_avatar , esc_html( $user_display_name ) );

	}
}
