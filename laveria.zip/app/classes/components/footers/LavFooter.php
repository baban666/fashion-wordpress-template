<?php


namespace classes\components\footers;


use classes\abstracts\LavBaseComponent;


class LavFooter extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Start Footer -->
        <div class="wrapper" id="wrapper-footer">
            <footer id="colophon" class="site-footer">
                <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>">
                    <div class="row footer-row">
						<?php $this->components->getComponent( 'footer-sidebar' )->render(); ?>
                    </div><!-- row end -->
                </div><!-- container end -->
	            <?php if ( $this->getValue('footer-copyright-enable') ): ?>
		            <?php $this->components->getComponent( 'footer-copyright' )->render(); ?>
	            <?php endif; ?>
            </footer><!-- #colophon -->
        </div><!-- wrapper end -->
        <!-- End Footer -->
		<?php

	}

}
