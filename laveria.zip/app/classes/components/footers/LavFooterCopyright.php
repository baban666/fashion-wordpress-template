<?php


namespace classes\components\footers;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavFooterCopyright extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $col = $this->getValue('footer-copyright-content') && $this->getValue('footer-copyright-menu') ? 'col-md-6' : 'col-md-12';
	    $menuCenter = $this->getValue('footer-copyright-content')? ' ' : ' justify-content-center';
	    $copyCenter = $this->getValue('footer-copyright-menu') ? ' ' : ' text-center';
		$year = date("Y");
		$copy = str_replace('{date}', $year, $this->getValue('footer-copyright-content'));
		?>
        <!-- Start Footer Copyright -->
        <div class="copyright-wrapper">
            <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
                <div class="row">
					<?php if ( $this->getValue('footer-copyright-enable') && $this->getValue('footer-copyright-content') ): ?>
                        <div class="<?php echo esc_attr($col . $copyCenter); ?>">
                            <p class="site-info">
								<?php echo esc_html( $copy ); ?>
                            </p><!-- .site-info -->
                        </div>
					<?php endif; ?>
					<?php if ( $this->getValue('footer-copyright-menu') ): ?>
                        <div class="<?php echo esc_attr($col); ?>">
                            <nav class="navbar <?php echo esc_attr($menuCenter); ?>" role="navigation">
								<?php
								wp_nav_menu( array(
									'theme_location'  => 'menu-3',
									'depth'           => 1,
									'container'       => 'div',
									'container_class' => 'footer-nav',
									'container_id'    => 'footer-nav-menu',
									'menu_class'      => 'nav',
									'fallback_cb'     => 'LavNavWalker::fallback',
									'walker'          => new LavNavWalker( '' ),
								) );
								?>
                            </nav>
                        </div>
					<?php endif; ?>
                </div><!-- row end -->
            </div><!-- container end -->
        </div>
        <!-- End Footer Copyright -->
		<?php

	}

}
