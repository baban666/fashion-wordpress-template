<?php


namespace classes\components\footers;


use classes\abstracts\LavBaseComponent;


class LavFooterTopLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Start Footer Top line -->
        <div class="wrapper footer-top" id="footer-top-line">
			<?php if ( $this->getValue('footer-top-container')): ?>
            <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
                <div class="row justify-content-center">
                    <div class="col-md-12">
			<?php endif; ?>
            <?php if ( $this->getValue('footer-top-content') ): ?>
                    <?php echo do_shortcode( $this->getValue('footer-top-content') ); ?>
            <?php endif; ?>
		    <?php if ( $this->getValue('footer-top-container')): ?>
                    </div><!--col end -->
                </div><!-- row end -->
            </div><!-- container end -->
		    <?php endif; ?>
        </div><!-- wrapper end -->
        <!-- End Footer Top line -->
		<?php

	}

}
