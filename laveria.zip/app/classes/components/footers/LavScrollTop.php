<?php


namespace classes\components\footers;


use classes\abstracts\LavBaseComponent;


class LavScrollTop extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $id = null ) {
		$isFooterActive = $this->getValue('footer-enable') && !$this->metaBoxes->getPageMeta( $id, 'meta-page-footer' );
		if($this->getValue('global-scroll-top') && !$isFooterActive){
			add_action( 'wp_footer', array( $this, 'renderAnchor' ), 99 );
		}
		?>
        <!-- Start Scroll Top -->
        <div class="scrollToTopBtn">
            <i class="las la-arrow-up"></i>
        </div>
        <!-- End Scroll Top -->
		<?php

	}

	public function renderAnchor( $args = null ) {
		?>
        <!-- #scrollToTopBtnAnchor -->
        <div id="scrollToTopBtnAnchor"></div>
        <!-- End #scrollToTopBtnAnchor -->
		<?php

	}

}
