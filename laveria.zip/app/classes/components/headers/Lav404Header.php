<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class Lav404Header extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-page-header-background') );

		$bgColor = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl =  $bannerDetails['image-url'];
		$imageAlt =  $bannerDetails['image-alt'];
		$direction = $bannerDetails['direction'];
		?>
        <header class="lav-hero page-header single-page" <?php echo sprintf( 'style="background: linear-gradient(155deg, %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor) , '100%' ); ?>>
            <div class="hero-text container">
                <h1 class="page-title text-start">
                    <?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'laveria' ); ?>
                </h1>
            </div>
            <?php if ( ! empty( $imageUrl ) ): ?>
                <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image"
                     alt="<?php echo esc_attr( $imageAlt ) ?>">
            <?php endif; ?>
			<?php if ( ! empty( $imageUrl )): ?>
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
			<?php endif; ?>
        </header>
		<?php

	}

}
