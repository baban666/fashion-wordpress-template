<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class LavIndexHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

	    $bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-blog-header-background') );


        $bgColor = $bannerDetails['bg-color'];
        $gradientColor = $bannerDetails['gradient-color'];
        $imageUrl =  $bannerDetails['image-url'];
        $imageAlt =  $bannerDetails['image-alt'];
		$direction = $bannerDetails['direction'];
		?>
        <header class="lav-hero page-header" <?php echo sprintf( 'style="background: linear-gradient(155deg, %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>>
            <div class="hero-text container">
				<?php
				if ( is_home() && ! is_front_page() ) :
					?>
                    <h2 class="page-title screen-reader-text news-detail-title text-white mt-lg-5 mb-lg-4"><?php single_post_title(); ?></h2>
				<?php
				endif;
				the_archive_title( '<h1 class="page-title text-start">', '</h1>' );
				if($this->getValue('global-loop-show-description')){
					the_archive_description( '<div class="archive-description">', '</div>' );
                }
				?>

                <div class="d-flex justify-content-start align-items-center">
					<?php $this->components->getComponent( 'breadcrumbs' )->render( array( 'blog' => esc_html__('Blog', 'laveria') , 'home' => esc_html__('Home', 'laveria') ) ); ?>
                </div>
            </div>
			<?php if ( ! empty( $imageUrl ) ): ?>
                <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image" alt="<?php echo esc_attr($imageAlt)?>">
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
            <?php endif; ?>
        </header>
		<?php

	}

}
