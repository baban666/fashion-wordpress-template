<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class LavSearchHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-blog-header-background') );

		$bgColor = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl =  $bannerDetails['image-url'];
		$imageAlt =  $bannerDetails['image-alt'];
		$direction = $bannerDetails['direction'];
		?>
        <header class="lav-hero page-header" <?php echo sprintf( 'style="background: linear-gradient(155deg, %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>>
            <div class="hero-text container">
                <h1 class="page-title text-start">
		            <?php
		            /* translators: %s: search query. */
		            printf( esc_html__( 'Search Results for: %s', 'laveria' ), '<span>' . get_search_query() . '</span>' );
		            ?>
                </h1>
                <div class="d-flex justify-content-start align-items-center">
					<?php $this->components->getComponent( 'breadcrumbs' )->render( array( 'blog' => esc_html__('Blog', 'laveria') , 'home' => esc_html__('Home', 'laveria') ) ); ?>
                </div>
            </div>
			<?php if ( ! empty( $imageUrl ) ): ?>
                <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image" alt="<?php echo esc_attr($imageAlt)?>">
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
            <?php endif; ?>

        </header>
		<?php

	}

}
