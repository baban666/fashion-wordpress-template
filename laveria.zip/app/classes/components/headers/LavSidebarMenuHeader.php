<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class LavSidebarMenuHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <div class="page-heading sticky-top">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                    Toggle
                </a>
                <div class="toggler">
                    <a href="#" class="sidebar-hide ">
                        <i class="fas fa-times"></i>
                    </a>
                </div>
            </header>
        </div>
		<?php

	}

}
