<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class LavSingleReadingHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-single-header-background') );

		$bgColor = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl =  $bannerDetails['image-url'];
		$imageAlt =  $bannerDetails['image-alt'];
		$direction     = $bannerDetails['direction'];
		?>
        <div class="lav-hero single-header single-default-header single-reading single-page" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr( $bgColor ), '25%', esc_attr( $gradientColor ), '100%' ); ?>>
            <?php if ( has_post_thumbnail() ): ?>
				<?php lav_post_thumbnail(); ?>
			<?php else: ?>
				<?php if ( ! empty( $imageUrl ) ): ?>
                    <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image"
                         alt="<?php echo esc_attr( $imageAlt ) ?>">
				<?php endif; ?>
			<?php endif; ?>
	        <?php if ( has_post_thumbnail() || ! empty( $imageUrl )): ?>
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
	        <?php endif; ?>
        </div>
		<?php

	}

}
