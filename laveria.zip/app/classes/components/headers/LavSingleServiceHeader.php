<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;


class LavSingleServiceHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue('general-single-header-background') );

		$bgColor = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl =  $bannerDetails['image-url'];
		$imageAlt =  $bannerDetails['image-alt'];
		$direction     = $bannerDetails['direction'];

		$showCat = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-category' ), $this->getValue( 'global-single-show-category' ) );
		$showDate = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-date' ), $this->getValue( 'global-single-show-date' ) );
		$showAuthor = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author' ), $this->getValue( 'global-single-show-author' ) );
		$showComments = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-comment' ), $this->getValue( 'global-single-show-comment' ) );
		$showCrumbs = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-crumbs' ), $this->getValue( 'global-single-show-crumbs' ) );

		$actionText = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-action-text' );
		$actionLink = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-action-link' );
		$desc = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-description' );
		$target = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-action-new-window' ) ? '_blank' : '_self'
		?>

        <div class="lav-hero single-header single-default-header single-service single-page" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr( $bgColor ), '25%', esc_attr( $gradientColor ), '100%' ); ?>>
            <div class="hero-text container">
				<?php if ( $showCat ): ?>
					<?php the_category(); ?>
				<?php endif; ?>
                <div class="entry-header">
					<?php the_title( '<h1 class="entry-title text-start">', '</h1>' ); ?>
                </div><!-- .entry-header -->
	            <?php if($desc): ?>
                <div class="single-desc">
                     <?php echo esc_html($desc); ?>
                </div>
	            <?php endif; ?>
	            <?php if($actionText && $actionLink): ?>
                <div class="single-action">
                    <a  class="lav-btn-default" href="<?php echo esc_url($actionLink) ?>" target="<?php echo esc_attr($target);?>">
                        <?php echo esc_html($actionText); ?>
                    </a>
                </div>
	            <?php endif; ?>
                <div class="entry-meta">
					<?php if ( $showDate ): ?>
						<?php lav_posted_on(); ?>
					<?php endif; ?>
					<?php if ( $showAuthor): ?>
						<?php $this->components->getComponent( 'author-avatar' )->render(); ?>
					<?php endif; ?>
					<?php if ( $showComments ): ?>
                        <div class="comments">
                            <a href="<?php echo esc_url( get_comments_link() ); ?>">
                                <i class="las la-comment"></i>
								<?php echo get_comments_number(); ?>
                            </a>
                        </div>
					<?php endif; ?>
                </div><!-- .entry-meta -->

	            <?php if ( $showCrumbs ): ?>
                    <div class="d-flex justify-content-start align-items-center">
			            <?php $this->components->getComponent( 'breadcrumbs' )->render( array( 'blog' => esc_html__('Blog', 'laveria') , 'home' => esc_html__('Home', 'laveria') ) ); ?>
                    </div>
	            <?php endif; ?>
            </div>
			<?php if ( has_post_thumbnail() ): ?>
				<?php lav_post_thumbnail(); ?>
			<?php else: ?>
				<?php if ( ! empty( $imageUrl ) ): ?>
                    <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image"
                         alt="<?php echo esc_attr( $imageAlt ) ?>">
				<?php endif; ?>
			<?php endif; ?>
	        <?php if ( has_post_thumbnail() || ! empty( $imageUrl )): ?>
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
	        <?php endif; ?>
        </div>
		<?php

	}

}
