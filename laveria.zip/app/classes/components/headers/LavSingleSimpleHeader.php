<?php


namespace classes\components\headers;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;


class LavSingleSimpleHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$bannerDetails = $this->helper->getBannerDetails( $this->getValue( 'general-single-header-background' ) );

		$bgColor       = $bannerDetails['bg-color'];
		$gradientColor = $bannerDetails['gradient-color'];
		$imageUrl      = $bannerDetails['image-url'];
		$imageAlt      = $bannerDetails['image-alt'];
		$direction     = $bannerDetails['direction'];

		$showCat      = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-category' ), $this->getValue( 'global-single-show-category' ) );
		$showDate     = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-date' ), $this->getValue( 'global-single-show-date' ) );
		$showAuthor   = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author' ), $this->getValue( 'global-single-show-author' ) );
		$showComments = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-comment' ), $this->getValue( 'global-single-show-comment' ) );
		$showCrumbs   = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-crumbs' ), $this->getValue( 'global-single-show-crumbs' ) );

		$actionText = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-action-text' );
		$actionLink = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-action-link' );
		$desc       = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-description' );
		$badge      = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-badge' );
		$target     = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-action-new-window' ) ? '_blank' : '_self';
		$aValue     = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-simple-rating' );


		?>
        <div class="container lav-hero-simple sec__container lav-hero single-header single-simple single-page" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr( $bgColor ), '25%', esc_attr( $gradientColor ), '100%' ); ?>>
            <div class="hero-text-section">
                <div class="row">
                    <div class="col-md-8">
                        <div class="carousel__explanation">
                            <div class="entry-meta">
								<?php if ( $showAuthor ): ?>
                                    <div class="book__author">
										<?php $this->components->getComponent( 'author-avatar' )->render(); ?>
                                    </div>
								<?php endif; ?>
								<?php if ( $showDate ): ?>
									<?php lav_posted_on(); ?>
								<?php endif; ?>
								<?php if ( $showComments ): ?>
                                    <div class="comments">
                                        <a href="<?php echo esc_url( get_comments_link() ); ?>">
                                            <i class="las la-comment"></i>
											<?php echo get_comments_number(); ?>
                                        </a>
                                    </div>
								<?php endif; ?>
                            </div><!-- .entry-meta -->
                            <div class="entry-header book__name">
								<?php the_title( '<h1 class="entry-title text-start">', '</h1>' ); ?>
                            </div><!-- .entry-header -->
							<?php if ( $showCat ): ?>
								<?php the_category(); ?>
							<?php endif; ?>
							<?php if ( ! empty( $aValue ) || ! empty( $badge ) ): ?>
                                <div class="feedback">
									<?php if ( $aValue ): ?>
										<?php LavHelpersProvider::getAmazonStars( $aValue ); ?>
									<?php endif; ?>
									<?php if ( $badge ): ?>
                                        <div class="marketing__badge">
                                        <span class="marketing__badge-icon">
                                           <i class="las la-certificate"></i>
                                        </span>
                                            <span class="marketing__badge-title"><?php echo esc_html( $badge ); ?></span>
                                        </div>
									<?php endif; ?>
                                </div>
							<?php endif; ?>
							<?php if ( $desc ): ?>
                                <div class="single-desc book__summary">
									<?php echo esc_html( $desc ); ?>
                                </div>
							<?php endif; ?>
							<?php if ( $actionText && $actionLink ): ?>
                                <div class="single-action my-5">
                                    <a class="lav-btn-outline" href="<?php echo esc_url( $actionLink ) ?>"
                                       target="<?php echo esc_attr( $target ); ?>">
										<?php echo esc_html( $actionText ); ?>
                                    </a>
                                </div>
							<?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="carousel__media">
							<?php if ( has_post_thumbnail() ): ?>
								<?php lav_post_thumbnail(); ?>
							<?php else: ?>
								<?php if ( ! empty( $imageUrl ) ): ?>
                                    <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image"
                                         alt="<?php echo esc_attr( $imageAlt ) ?>">
								<?php endif; ?>
							<?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 mt-3">
						<?php if ( $showCrumbs ): ?>
                            <div class="d-flex justify-content-start align-items-center">
								<?php $this->components->getComponent( 'breadcrumbs' )->render( array(
									'blog' => esc_html__( 'Blog', 'laveria' ),
									'home' => esc_html__( 'Home', 'laveria' )
								) ); ?>
                            </div>
						<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
		<?php

	}

}
