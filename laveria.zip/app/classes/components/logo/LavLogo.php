<?php


namespace classes\components\logo;


use classes\abstracts\LavBaseComponent;


class LavLogo extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Site Branding Start -->
        <div class="site-branding">
	        <?php if ( ! has_custom_logo() ) { ?>
		        <?php
		        if ( is_front_page() && is_home() ) :
			        ?>
                    <h2 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h2>
		        <?php
		        else :
			        ?>
                    <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
		        <?php
		        endif;
		        $lav_description = get_bloginfo( 'description', 'display' );
		        if ( $lav_description || is_customize_preview() ) :
			        ?>
                    <p class="site-description"><?php echo esc_html($lav_description);?></p>
		        <?php endif; ?>
		        <?php
	        } else {
		        the_custom_logo();
	        }
	        ?>
        </div> <!-- .site-branding -->
        <!-- Site Branding Start -->
        <?php

	}

}
