<?php


namespace classes\components\loops;


use classes\abstracts\LavBaseComponent;

class LavLoopCards extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		/* Start the Loop */
		$post_counter = 0; // Initialize a post counter
		$template = $this->getValue( 'general-' . $args . '-loop-layout' );
		$adContent = $this->getValue( 'global-loop-ad-banner-content' );
		?>
        <div class="lav-posts-grid">
            <div class="row row-<?php echo esc_attr( $template ); ?>">
				<?php
				while ( have_posts() ) : the_post();
					$post_counter++; // Increment the post counter
					if ( file_exists( LAV_LOOPS_PATH . $template . '.php' ) ) {
						include LAV_LOOPS_PATH . $template . '.php';
						if (!empty($this->getValue('global-loop-show-ad-banner')) && $post_counter % 2 == 0 ){
							$this->components->getComponent( 'ad-banner' )->render($adContent);
						}
					} else {
						esc_html_e( 'No Contents Found', 'laveria' );
					}
				endwhile;
				?>
            </div>
        </div>
		<?php

		/* End the Loop */
	}

}
