<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavBookMenuNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Toggle right offcanvas</button>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
            <div class="offcanvas-header">
                <h5 id="offcanvasRightLabel">Offcanvas right</h5>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <!-- Navbar Start -->
                <nav id="site-navigation" class="sidebar-wrapper active">
                    <h2 id="main-nav-label" class="screen-reader-text">
			            <?php esc_html_e( 'Main Navigation', 'laveria' ); ?>
                    </h2>
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'menu-1',
                        'depth'          => 2, // 1 = no dropdowns, 2 = with dropdowns.
                        'container'      => false,
                        'menu_class'     => 'navbar-nav',
                        'fallback_cb'    => 'LavNavWalker::fallback',
                        'walker'         => new LavNavWalker( '' ),
                    ) );
                    ?>
                </nav><!-- #site-navigation -->
                <!-- Navbar End -->
            </div>
        </div>

		<?php
	}

}
