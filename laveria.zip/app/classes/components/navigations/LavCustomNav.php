<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		?>
		<?php if($this->getValue('header-promo-bar')): ?>
			<?php $this->components->getComponent('promo-bar')->render(); ?>
		<?php endif; ?>
		<?php if($this->getValue('general-custom-header-sticky-enable')): ?>
			<?php $this->components->getComponent('custom-sticky-line')->render(); ?>
		<?php endif; ?>
		<?php if($this->getValue('general-custom-header-top-enable')): ?>
			<?php $this->components->getComponent('custom-top-line')->render(); ?>
		<?php endif; ?>
		<?php if($this->getValue('general-custom-header-middle-enable')): ?>
			<?php $this->components->getComponent('custom-middle-line')->render(); ?>
		<?php endif; ?>
		<?php if($this->getValue('general-custom-header-bottom-enable')): ?>
			<?php $this->components->getComponent('custom-bottom-line')->render(); ?>
		<?php endif; ?>
		<?php if($this->getValue('general-custom-header-mobile-enable')): ?>
			<?php $this->components->getComponent('custom-mobile-line')->render(); ?>
		<?php endif; ?>
		<?php
	}

}
