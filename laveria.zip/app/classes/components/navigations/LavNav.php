<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$shadow      = $this->getValue( 'header-shadow' ) ? 'shadow-sm' : '';
		$upper       = $this->getValue( 'header-upper' ) ? 'text-uppercase' : '';
		$navClass    = $this->helper->topNavClassTopLine( $this->settings );
		$disableLogo = ! $this->getValue( 'header-logo' ) ? ' disable-logo' : ' enable-logo';
		$menu        = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-nav' );
		$menuType    = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-type' );

		if(!empty($menuType)){
			$navClass = $menuType;
        }

		?>
        <!-- Navbar Start -->
        <nav id="site-navigation"
             class="navbar navbar-expand-lg navbar-light <?php echo esc_attr( $shadow . ' ' . $navClass . $disableLogo ); ?>">
            <h2 id="main-nav-label" class="screen-reader-text">
				<?php esc_html_e( 'Main Navigation', 'laveria' ); ?>
            </h2>
            <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
				<?php if ( $this->getValue( 'header-logo' ) ): ?>
					<?php $this->components->getComponent( 'logo' )->render(); ?>
				<?php endif; ?>
				<?php if ( function_exists( 'wc_get_cart_url' )): ?>
                    <div class="top-icons d-inline-flex ms-auto mobile-soc-icons d-block d-md-block d-lg-none">
						<?php $this->components->getComponent( 'mini-cart' )->render(); ?>
                    </div>
				<?php endif; ?>
				<?php if ( $this->getValue( 'header-search' ) ): ?>
                    <button type="button"
                            class="search-toggle mobile-search-toggle d-block d-xxl-none d-xl-none d-lg-none"
                            data-bs-toggle="modal" data-bs-target="#searchModal">
                        <i class="las la-search"></i>
                    </button>
				<?php endif; ?>
				<?php if ( $this->getValue( 'header-social-mobile' ) ): ?>
                    <div class="d-inline-flex ms-auto mobile-soc-icons d-block d-md-block d-lg-none">
						<?php $this->components->getComponent( 'social' )->render(); ?>
                    </div>
				<?php endif; ?>
                <button class="navbar-toggler" type="button" aria-label="Menu toggle" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                    <i class="las la-bars"></i>
                </button>
				<?php if ( $this->getValue( 'header-burger-menu' ) ): ?>
					<?php $this->components->getComponent( 'burger' )->render( ' burger-mobile d-block d-md-block d-lg-none' ); ?>
				<?php endif; ?>
                <div class="collapse navbar-collapse" id="navbarCollapse">
					<?php
					if ( ! $args ) {
						wp_nav_menu( array(
							'menu'           => $menu,
							'theme_location' => 'menu-1',
							'depth'          => 3, // 1 = no dropdowns, 2 = with dropdowns.
							'container'      => false,
							'menu_class'     => 'navbar-nav py-0 ' . $upper,
							'fallback_cb'    => 'LavNavWalker::fallback',
							'walker'         => new LavNavWalker( '' ),
						) );
					}
					?>
					<?php if ( $this->getValue( 'header-social' ) ): ?>
						<?php $this->components->getComponent( 'social' )->render(); ?>
					<?php endif; ?>
					<?php if ( function_exists( 'wc_get_cart_url' )): ?>
						<?php $this->components->getComponent( 'mini-cart' )->render(); ?>
					<?php endif; ?>
					<?php if ( $this->getValue( 'header-search' ) ): ?>
						<?php $this->components->getComponent( 'header-search' )->render(); ?>
					<?php endif; ?>
	                <?php if($this->getValue('header-phone-main') === '1' && $this->getValue( 'header-phone-main-position' ) !== '1'): ?>
		                <?php $this->components->getComponent( 'phone-top' )->render(); ?>
	                <?php endif; ?>
					<?php if ( $this->getValue( 'header-action' ) ): ?>
						<?php $this->components->getComponent( 'action-button' )->render(); ?>
					<?php endif; ?>
	                <?php if($this->getValue('header-phone-main') === '1' && $this->getValue( 'header-phone-main-position' ) === '1'): ?>
		                <?php $this->components->getComponent( 'phone-top' )->render(); ?>
	                <?php endif; ?>
					<?php if ( $this->getValue( 'header-burger-menu' )): ?>
						<?php $this->components->getComponent( 'burger' )->render(); ?>
					<?php endif; ?>
                </div>
            </div><!-- .container(-fluid) -->
        </nav><!-- #site-navigation -->
        <!-- Navbar End -->
		<?php
		$this->components->getComponent( 'nav-mobile' )->render();
	}

}
