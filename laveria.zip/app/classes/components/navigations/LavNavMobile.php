<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavNavMobile extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$menu        = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-nav' );
		?>
        <!-- Navbar Mobile Start -->
        <div class="offcanvas offcanvas-mobile offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
            <div class="offcanvas-header">
	            <?php if($this->getValue('header-logo')): ?>
		            <?php $this->components->getComponent( 'logo' )->render(); ?>
	            <?php endif; ?>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="offcanvas-body">
                <div class="navbar-collapse">
					<?php
					wp_nav_menu( array(
						'menu'  => $menu,
						'theme_location'  => 'menu-2',
						'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
						'container' => false,
						'menu_class'      => 'navbar-nav ms-auto py-0',
						'fallback_cb'     => 'LavNavWalker::fallback',
						'walker'          => new LavNavWalker('mobile'),
					) );
					?>
                    <div class="off-canvas-footer">
                    <?php if($this->getValue('header-phone-top') === '1' || $this->getValue('header-email-top') === '1'  || $this->getValue('header-address-top') === '1'): ?>
                        <div class="position-relative align-items-center">
                            <?php if($this->getValue('header-email-top') === '1'): ?>
                                <?php $this->components->getComponent( 'mail-top' )->render(); ?>
                            <?php endif; ?>
                            <?php if($this->getValue('header-phone-top') === '1'): ?>
                                <?php $this->components->getComponent( 'phone-top' )->render(); ?>
                            <?php endif; ?>
                            <?php if($this->getValue('header-address-top') === '1'): ?>
                                <?php $this->components->getComponent( 'address-top' )->render(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if($this->getValue('header-social-mobile')): ?>
                        <div class="d-inline-flex mobile-soc-icons">
                            <?php $this->components->getComponent( 'social' )->render(); ?>
                        </div>
                    <?php endif; ?>
	                <?php if($this->getValue('header-action')): ?>
		                <?php $this->components->getComponent( 'action-button' )->render(); ?>
	                <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Navbar Mobile Start -->
        <?php

	}

}
