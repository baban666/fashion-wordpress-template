<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavSidebarMenuNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Navbar Start -->
        <nav id="site-navigation" class="sidebar-wrapper active">
            <h2 id="main-nav-label" class="screen-reader-text">
				<?php esc_html_e( 'Main Navigation', 'laveria' ); ?>
            </h2>
            <div class="d-flex flex-column h-100 flex-shrink-0 p-3 bg-light">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-between">
			            <?php $this->components->getComponent( 'logo' )->render(); ?>
                        <button class="sidebar-toggler btn">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="sidebar-menu mb-auto">
		            <?php
		            wp_nav_menu( array(
			            'theme_location' => 'menu-1',
			            'depth'          => 2, // 1 = no dropdowns, 2 = with dropdowns.
			            'container'      => false,
			            'menu_class'     => 'navbar-nav',
			            'fallback_cb'    => 'LavNavWalker::fallback',
			            'walker'         => new LavNavWalker( '' ),
		            ) );
		            ?>
                </div>
                <div class="d-flex flex-column">
                    <button type="button" class="btn text-dark" data-bs-toggle="modal" data-bs-target="#searchModal"><i
                                class="fa fa-search"></i></button>
		            <?php $this->components->getComponent( 'social' )->render(); ?>
                    <a href="#" class="btn btn-primary py-2 px-4 ms-3">Appointment</a>
                </div>
            </div>
        </nav><!-- #site-navigation -->
        <!-- Navbar End -->
		<?php
	}

}
