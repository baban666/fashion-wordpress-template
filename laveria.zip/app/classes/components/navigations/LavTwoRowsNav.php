<?php


namespace classes\components\navigations;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavTwoRowsNav extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$shadow = $this->getValue('header-shadow') ? 'shadow-sm' : ' ';
		$transparent = $this->getValue('general-two-rows-transparent') ? ' row-transparent' : ' ';
		$upper = $this->getValue('header-upper') ? 'text-uppercase' : ' ';
		$navClass = $this->helper->topNavClassTopLine($this->settings);
		$disableLogo = !$this->getValue('header-logo') ? ' disable-logo' : ' enable-logo';
		$menu        = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-nav' );
		$cart        = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-cart' );
		$menuType    = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-type' );

		if(!empty($menuType)){
			$navClass = $menuType;
		}
		?>
        <!-- Navbar Start -->
        <nav id="site-navigation" class="navbar navbar-expand-lg navbar-light <?php echo esc_attr( $shadow . $navClass . $disableLogo . $transparent); ?>">

            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>">
                <div class="top-row-nav">
                    <?php if($this->getValue('header-logo')): ?>
                        <?php $this->components->getComponent( 'logo' )->render(); ?>
                    <?php endif; ?>
                    <div class="top-rov-col text-lg-end">
		                <?php if($this->getValue('header-phone-top') === '1'): ?>
			                <?php $this->components->getComponent( 'phone-top' )->render(); ?>
		                <?php endif; ?>
		                <?php if($this->getValue('header-social')): ?>
                            <div class="d-inline-flex">
				                <?php $this->components->getComponent( 'social' )->render(); ?>
                            </div>
		                <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="wrapper-menu">
                <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>">
		            <?php if($this->getValue('header-logo')): ?>
			            <?php $this->components->getComponent( 'logo' )->render(); ?>
		            <?php endif; ?>
		            <?php if($this->getValue('header-search')): ?>
                        <button type="button" class="search-toggle mobile-search-toggle d-block d-xxl-none d-xl-none d-lg-none" data-bs-toggle="modal" data-bs-target="#searchModal">
                            <i class="las la-search"></i>
                        </button>
		            <?php endif; ?>
                    <button class="navbar-toggler" type="button" aria-label="Menu toggle" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                        <i class="las la-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
			            <?php
			            if(!$args){
				            wp_nav_menu( array(
					            'menu'           => $menu,
					            'theme_location' => 'menu-1',
					            'depth'          => 3, // 1 = no dropdowns, 2 = with dropdowns.
					            'container'      => false,
					            'menu_class'     => 'navbar-nav py-0 ' . $upper,
					            'fallback_cb'    => 'LavNavWalker::fallback',
					            'walker'         => new LavNavWalker( '' ),
				            ) );
			            }
			            ?>
			            <?php if ( $this->getValue( 'header-social' ) ): ?>
				            <?php $this->components->getComponent( 'social' )->render(); ?>
			            <?php endif; ?>
			            <?php if ( function_exists( 'wc_get_cart_url' ) && !$cart ): ?>
				            <?php $this->components->getComponent( 'mini-cart' )->render(); ?>
			            <?php endif; ?>
			            <?php if ( $this->getValue( 'header-search' ) ): ?>
				            <?php $this->components->getComponent( 'header-search' )->render(); ?>
			            <?php endif; ?>
			            <?php if($this->getValue('header-phone-main') === '1' && $this->getValue( 'header-phone-main-position' ) !== '1'): ?>
				            <?php $this->components->getComponent( 'phone-top' )->render(); ?>
			            <?php endif; ?>
			            <?php if ( $this->getValue( 'header-action' ) ): ?>
				            <?php $this->components->getComponent( 'action-button' )->render(); ?>
			            <?php endif; ?>
			            <?php if($this->getValue('header-phone-main') === '1' && $this->getValue( 'header-phone-main-position' ) === '1'): ?>
				            <?php $this->components->getComponent( 'phone-top' )->render(); ?>
			            <?php endif; ?>
			            <?php if ( $this->getValue( 'header-burger-menu' )): ?>
				            <?php $this->components->getComponent( 'burger' )->render(); ?>
			            <?php endif; ?>
                    </div>
                </div><!-- .container(-fluid) -->
            </div>
        </nav><!-- #site-navigation -->
        <!-- Navbar End -->
		<?php
		$this->components->getComponent( 'nav-mobile' )->render();
	}

}
