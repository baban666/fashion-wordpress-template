<?php

namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomAccountLink extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$link = get_permalink( $this->getValue( 'header-account-link' ) );
		?>
        <a type="button" href="<?php echo esc_url( $link ) ?>" class="btn lav-wishlist">
            <i class="lar la-user"></i>
        </a>
		<?php
	}

}
