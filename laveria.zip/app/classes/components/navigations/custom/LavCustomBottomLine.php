<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomBottomLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$rows = $this->helper->getEnabledElementsCustomHeader( $this->getValue( 'general-custom-header-bottom-set' ) );
		$shadow      = $this->getValue( 'header-shadow' ) ? 'shadow-sm' : '';
		$navClass    = $this->helper->topNavClassTopLine( $this->settings );
		$disableLogo = ! $this->getValue( 'header-logo' ) ? ' disable-logo' : ' enable-logo';
		$menuType    = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-type' );

		if(!empty($menuType)){
			$navClass = $menuType;
		}

		?>
        <!-- Custom Bottom Line Start -->
        <div class="bottom-row-nav d-none d-lg-block navbar navbar-expand-lg navbar-light <?php echo esc_attr( $shadow . ' ' . $navClass . $disableLogo ); ?>">
            <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?> d-none d-lg-block top-line">
                <div class="row align-items-center">
                    <div class="col-auto d-flex justify-content-start text-lg-start custom-top-left">
						<?php if ( ! empty( $rows['general-custom-header-bottom-settings-left'] ) && is_array( $rows['general-custom-header-bottom-settings-left'] ) ): ?>
							<?php foreach ( $rows['general-custom-header-bottom-settings-left'] as $key => $value ): ?>
								<?php $this->components->getComponent( $key )->render(); ?>
							<?php endforeach; ?>
						<?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-center flex-fill text-lg-center custom-top-center">
						<?php if ( ! empty( $rows['general-custom-header-bottom-settings-center'] ) && is_array( $rows['general-custom-header-bottom-settings-center'] ) ): ?>
							<?php foreach ( $rows['general-custom-header-bottom-settings-center'] as $key => $value ): ?>
								<?php $this->components->getComponent( $key )->render(); ?>
							<?php endforeach; ?>
						<?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-end text-lg-end custom-top-right">
						<?php if ( ! empty( $rows['general-custom-header-bottom-settings-right'] ) && is_array( $rows['general-custom-header-bottom-settings-right'] ) ): ?>
							<?php foreach ( $rows['general-custom-header-bottom-settings-right'] as $key => $value ): ?>
								<?php $this->components->getComponent( $key )->render(); ?>
							<?php endforeach; ?>
						<?php endif; ?>
                    </div>
                </div>
            </div><!-- .container(-fluid) -->
        </div>
        <!-- Custom Bottom Line End -->
		<?php
	}

}
