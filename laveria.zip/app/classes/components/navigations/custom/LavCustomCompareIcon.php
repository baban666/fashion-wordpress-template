<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomCompareIcon extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $link = get_permalink($this->getValue('shop-compare-page'));
		?>
        <a type="button" href="<?php echo esc_url($link) ?>" class="btn compare">
            <i class="las la-sync-alt"></i>
        </a>
		<?php
	}

}
