<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomHomeIcon extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		?>
        <a type="button" href="<?php echo esc_url( home_url( '/' ) ) ?>" class="btn custom-home">
            <i class="las la-home"></i>
        </a>
		<?php
	}

}
