<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomMainNavigation extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$upper       = $this->getValue( 'header-upper' ) ? 'text-uppercase' : ' ';
		$menu        = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-nav' );

		?>
        <!-- Navbar Start -->
        <nav class="main-navbar navbar navbar-expand-lg navbar-light">
            <h2 id="main-nav-label" class="screen-reader-text">
				<?php esc_html_e( 'Main Navigation', 'laveria' ); ?>
            </h2>
            <div class="collapse navbar-collapse" id="navbarCollapse">
				<?php
				if ( ! $args ) {
					wp_nav_menu( array(
						'menu'           => $menu,
						'theme_location' => 'menu-1',
						'depth'          => 3, // 1 = no dropdowns, 2 = with dropdowns.
						'container'      => false,
						'menu_class'     => 'navbar-nav py-0 ' . $upper,
						'fallback_cb'    => 'LavNavWalker::fallback',
						'walker'         => new LavNavWalker( '' ),
					) );
				}
				?>
            </div>
        </nav><!-- #site-navigation -->
		<?php
	}

}
