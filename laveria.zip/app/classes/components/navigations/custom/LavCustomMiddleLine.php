<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomMiddleLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$rows = $this->helper->getEnabledElementsCustomHeader($this->getValue('general-custom-header-middle-set'));
		$shadow      = $this->getValue( 'header-shadow' ) ? 'shadow-sm' : '';
		$navClass    = $this->helper->topNavClassTopLine( $this->settings );
		$disableLogo = ! $this->getValue( 'header-logo' ) ? ' disable-logo' : ' enable-logo';
		$menuType    = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-type' );

		if(!empty($menuType)){
			$navClass = $menuType;
		}
		?>
        <!-- Custom Middle Line Start -->
        <div class="middle-row-nav <?php echo esc_attr( $shadow . ' ' . $navClass . $disableLogo ); ?>">
            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?> top-line d-none d-lg-block py-2">
                <div class="row align-items-center flex-nowrap">
                    <div class="col-auto d-flex justify-content-start text-lg-start custom-top-left">
		                <?php if(!empty($rows['general-custom-header-middle-settings-left']) && is_array($rows['general-custom-header-middle-settings-left'])): ?>
			                <?php foreach($rows['general-custom-header-middle-settings-left'] as $key => $value): ?>
				                <?php $this->components->getComponent( $key )->render(); ?>
			                <?php endforeach; ?>
		                <?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-center flex-fill text-lg-center custom-top-center">
		                <?php if(!empty($rows['general-custom-header-middle-settings-center']) && is_array($rows['general-custom-header-middle-settings-center'])): ?>
			                <?php foreach($rows['general-custom-header-middle-settings-center'] as $key => $value): ?>
				                <?php $this->components->getComponent( $key )->render(); ?>
			                <?php endforeach; ?>
		                <?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-end text-lg-end custom-top-right">
		                <?php if(!empty($rows['general-custom-header-middle-settings-right']) && is_array($rows['general-custom-header-middle-settings-right'])): ?>
			                <?php foreach($rows['general-custom-header-middle-settings-right'] as $key => $value): ?>
				                <?php $this->components->getComponent( $key )->render(); ?>
			                <?php endforeach; ?>
		                <?php endif; ?>
                    </div>
                </div>
            </div><!-- .container(-fluid) -->
        </div>
        <!-- Custom Middle Line End -->
        <?php
	}

}
