<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomMobileLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$rows = $this->helper->getEnabledElementsCustomHeader( $this->getValue( 'general-custom-header-mobile-set' ) );
		$navClass    = $this->helper->topNavClassTopLine( $this->settings );
		$menuType    = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-type' );

		if(!empty($menuType)){
			$navClass = $menuType;
		}
		?>
        <!-- Custom Mobile Start -->
        <div class="mobile-top-row d-flex p-1 d-lg-none alice-sticky-top <?php echo esc_attr( $navClass ); ?>">
            <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
                <div class="col flex-wrap align-items-center d-flex justify-content-between">
                <?php if ( ! empty( $rows['general-custom-header-mobile-settings-top'] ) && is_array( $rows['general-custom-header-mobile-settings-top'] ) ): ?>
                    <?php foreach ( $rows['general-custom-header-mobile-settings-top'] as $key => $value ): ?>
                        <?php $this->components->getComponent( $key )->render(); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
            </div><!-- .container(-fluid) -->
        </div><!-- #site-navigation -->
        <!-- Custom Mobile End -->
		<?php
		$this->components->getComponent( 'custom-nav-mobile' )->render();
	}

}
