<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomMobileNavigation extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$menu = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu-nav' );
		?>
        <div class="navbar-collapse">
			<?php
			wp_nav_menu( array(
				'menu'           => $menu,
				'theme_location' => 'menu-2',
				'depth'          => 2, // 1 = no dropdowns, 2 = with dropdowns.
				'container'      => false,
				'menu_class'     => 'navbar-nav ms-auto py-0',
				'fallback_cb'    => 'LavNavWalker::fallback',
				'walker'         => new LavNavWalker( 'mobile' ),
			) );
			?>
        </div>
		<?php
	}

}
