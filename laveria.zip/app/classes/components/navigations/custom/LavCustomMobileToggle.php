<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomMobileToggle extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
		<button class="navbar-toggler" type="button" aria-label="Menu toggle" data-bs-toggle="offcanvas"
		        data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
			<i class="las la-bars"></i>
		</button>
		<?php
	}

}
