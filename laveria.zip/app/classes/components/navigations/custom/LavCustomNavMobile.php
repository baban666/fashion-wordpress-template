<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomNavMobile extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$values = $this->getValue( 'general-custom-header-mobile-set' );
		$tabOne = !empty($values['general-custom-header-mobile-settings-canvas-tab-one'])
			? $values['general-custom-header-mobile-settings-canvas-tab-one']
			: esc_html__('Menu', 'laveria');
		$tabTwo = !empty($values['general-custom-header-mobile-settings-canvas-tab-two'])
			? $values['general-custom-header-mobile-settings-canvas-tab-two']
			: esc_html__('Catalog', 'laveria');
		$rows = $this->helper->getEnabledElementsCustomHeader( $values );
		?>
        <!-- Navbar Mobile Start -->
        <div class="offcanvas custom-offcanvas-mobile offcanvas-mobile offcanvas-start" tabindex="-1" id="offcanvasExample"
             aria-labelledby="offcanvasExampleLabel">
            <div class="offcanvas-header">
				<?php if ( ! empty( $rows['general-custom-header-mobile-settings-canvas-head'] ) && is_array( $rows['general-custom-header-mobile-settings-canvas-head'] ) ): ?>
					<?php foreach ( $rows['general-custom-header-mobile-settings-canvas-head'] as $key => $value ): ?>
						<?php $this->components->getComponent( $key )->render(); ?>
					<?php endforeach; ?>
				<?php endif; ?>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="offcanvas-body">
	            <?php if ( ! empty( $values['general-custom-header-mobile-settings-canvas-tab-enable'] ) && is_array( $rows['general-custom-header-mobile-settings-canvas-tab'] ) ): ?>
                <ul class="nav nav-tabs nav-fill" id="ex1" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a
                                class="nav-link active"
                                id="ex2-tab-1"
                                data-bs-toggle="tab"
                                href="#ex2-tabs-1"
                                role="tab"
                                aria-controls="ex2-tabs-1"
                                aria-selected="true"
                        ><?php echo esc_html($tabOne)?></a
                        >
                    </li>
                    <li class="nav-item" role="presentation">
                        <a
                                class="nav-link"
                                id="ex2-tab-3"
                                data-bs-toggle="tab"
                                href="#ex2-tabs-3"
                                role="tab"
                                aria-controls="ex2-tabs-3"
                                aria-selected="false"
                        ><?php echo esc_html($tabTwo)?></a>
                    </li>
                </ul>
	            <?php endif; ?>
                <div class="tab-content" id="ex2-content">
                    <div class="tab-pane fade show active" id="ex2-tabs-1" role="tabpanel" aria-labelledby="ex2-tab-1">
                    <?php if ( ! empty( $rows['general-custom-header-mobile-settings-canvas-body'] ) && is_array( $rows['general-custom-header-mobile-settings-canvas-body'] ) ): ?>
                        <?php foreach ( $rows['general-custom-header-mobile-settings-canvas-body'] as $key => $value ): ?>
                            <?php $this->components->getComponent( $key )->render(); ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </div>
	                <?php if ( ! empty( $values['general-custom-header-mobile-settings-canvas-tab-enable'] ) && is_array( $rows['general-custom-header-mobile-settings-canvas-tab'] ) ): ?>
                    <div class="tab-pane fade" id="ex2-tabs-3" role="tabpanel" aria-labelledby="ex2-tab-3">
	                    <?php foreach (  $rows['general-custom-header-mobile-settings-canvas-tab'] as $key => $value ): ?>
		                    <?php $this->components->getComponent( $key )->render(); ?>
	                    <?php endforeach; ?>
                    </div>
	                <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Navbar Mobile Start -->
		<?php

	}

}
