<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomNotices extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
        $rows = $this->getValue('header-notices-group');

        if (empty($rows) && !is_array( $rows )){
            return;
        }
		$html = '';
		foreach ( $rows as $key => $value ){
			$html .= '<li><a class="dropdown-item" href="'. esc_html($value['notice-link']) .'">'. esc_html($value['notice-text']) .'</a></li>';
		}
		?>
        <div class="dropdown">
            <button  class="btn lav-notices" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="las la-bell"></i>
            </button>
            <?php echo sprintf( '<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink">%1$s</ul>', $html ) ?>
        </div>
		<?php
	}

}
