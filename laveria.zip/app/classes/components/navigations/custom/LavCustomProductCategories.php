<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomProductCategories extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$hideEmpty = ! empty( $this->getValue( 'header-categories-hide-empty' ) );
		$thumb     = ! empty( $this->getValue( 'header-categories-hide-thumb' ) );
		$cat       = $this->getValue( 'header-categories-manual' );
		$exclude   = $this->getValue( 'header-categories-exclude' );
		$type      = ! empty( $this->getValue( 'header-categories-type' ) )
			? $this->getValue( 'header-categories-type' )
			: 'all';
		$order     = ! empty( $this->getValue( 'header-categories-order' ) )
			? $this->getValue( 'header-categories-order' )
			: 'ASC';
		$orderBy   = ! empty( $this->getValue( 'header-categories-order-by' ) )
			? $this->getValue( 'header-categories-order-by' )
			: 'menu_order';
		$title     = ! empty( $this->getValue( 'header-categories-title' ) )
			? $this->getValue( 'header-categories-title' )
			: esc_html__( 'Product Categories', 'laveria' );

		$query = array(
			'hide_empty' => empty( $hideEmpty ),
			'orderby'    => $orderBy,
			'order'      => $order,
		);

		if ( $type == 'manual' ) {
			$query ['include'] = $cat;
		}

		if ( $type == 'all' && ! empty( $exclude ) ) {
			$query ['exclude'] = $exclude;
		}

		$product_categories = get_terms( 'product_cat', $query );

		?>
		<?php if ( ! empty( $product_categories ) && ! is_wp_error( $product_categories ) ): ?>
            <ul class="nav navbar-nav product-category-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle show" href="#" id="productCategoriesDropdown" role="button"
                       data-bs-toggle="dropdown" aria-expanded="true">
                        <i class="las la-bars"></i><?php esc_html_e( $title ) ?>
                    </a>
                    <ul class="dropdown-menu show" aria-labelledby="productCategoriesDropdown">
						<?php foreach ( $product_categories as $category ) : ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo get_term_link( $category ); ?>">
									<?php if ( $thumb ): ?>
										<?php echo $this->getThumbnail( $category->term_id ) ?>
									<?php endif; ?>
									<?php echo esc_html( $category->name ); ?>
                                </a>
                            </li>
						<?php endforeach; ?>
                    </ul>
                </li>
            </ul>
		<?php endif; ?>
		<?php

	}

	public function getThumbnail( $id ) {
		$placeholder  = $this->getValue( 'header-categories-placeholder' );
		$thumbnail_id = get_term_meta( $id, 'thumbnail_id', true );
		$image        = wp_get_attachment_url( $thumbnail_id );
		$image_alt    = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
		if ( empty( $image ) && function_exists( 'wc_placeholder_img_src' ) && ! empty( $placeholder ) ) {
			$image = wc_placeholder_img_src();
		}
		if ( empty( $image )) {
			return '';
		}

		return '<img src=' . esc_url( $image ) . ' alt="' . esc_html( $image_alt ) . '" width="20" height="20" />';
	}

}
