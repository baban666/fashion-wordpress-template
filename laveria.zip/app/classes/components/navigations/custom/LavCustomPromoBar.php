<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomPromoBar extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$cookkie   = isset($_COOKIE['promotionClosed']) ? true : false;
		$mobile    = '1';
		$class     = $mobile == '0' ? ' mobile-hidden' : '';
		?>
		<?php if($this->getValue('header-promo-bar-text' )&& $cookkie !== true): ?>
            <div id="promo-bar" class="grad-anim-1 d-none d-md-block alice-promotion-bar <?php echo esc_attr( $class ); ?>">
                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?> text-lg-center">
                    <span id="promo-bar-close" class="panel-close"><i class="las la-times"></i></span>
	                <?php echo do_shortcode( wp_kses_post($this->getValue('header-promo-bar-text'))  ); ?>
                </div>
            </div>
		<?php endif; ?>
		<?php
	}

}
