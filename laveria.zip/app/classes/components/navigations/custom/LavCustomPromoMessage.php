<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomPromoMessage extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
		<?php if($this->getValue('header-promo-message-text')): ?>
            <div class="py-1 promo-info">
                <p class="m-0">
                    <i class="las la-bullhorn"></i></i><?php echo wp_kses_post($this->getValue('header-promo-message-text')) ?>
                </p>
            </div>
		<?php endif; ?>
		<?php
	}

}
