<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavCustomTopLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$rows = $this->helper->getEnabledElementsCustomHeader($this->getValue('general-custom-header-top-set'));
		?>
        <!-- Custom Topbar Start -->
        <div class="top-bar custom-top-bar d-none d-xxl-block d-xl-block d-lg-block">
            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?> d-none d-lg-block">
                <div class="row align-items-center">
                    <div class="col-auto d-flex justify-content-start text-lg-start custom-top-left">
	                    <?php if(!empty($rows['general-custom-header-top-settings-left']) && is_array($rows['general-custom-header-top-settings-left'])): ?>
		                    <?php foreach($rows['general-custom-header-top-settings-left'] as $key => $value): ?>
			                    <?php $this->components->getComponent( $key )->render(); ?>
		                    <?php endforeach; ?>
	                    <?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-center flex-fill text-lg-center custom-top-center">
	                    <?php if(!empty($rows['general-custom-header-top-settings-center']) && is_array($rows['general-custom-header-top-settings-center'])): ?>
		                    <?php foreach($rows['general-custom-header-top-settings-center'] as $key => $value): ?>
			                    <?php $this->components->getComponent( $key )->render(); ?>
		                    <?php endforeach; ?>
	                    <?php endif; ?>
                    </div>
                    <div class="col-auto d-flex justify-content-end text-lg-end custom-top-right">
	                    <?php if(!empty($rows['general-custom-header-top-settings-right']) && is_array($rows['general-custom-header-top-settings-right'])): ?>
		                    <?php foreach($rows['general-custom-header-top-settings-right'] as $key => $value): ?>
			                    <?php $this->components->getComponent( $key )->render(); ?>
		                    <?php endforeach; ?>
	                    <?php endif; ?>
                    </div>
                </div>
            </div><!-- .container(-fluid) -->
        </div>
        <!-- Custom Topbar End -->
        <?php

	}

}
