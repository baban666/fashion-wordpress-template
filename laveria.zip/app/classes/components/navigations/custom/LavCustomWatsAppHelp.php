<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomWatsAppHelp extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

	    $link = get_permalink($this->getValue('shop-compare-page'));

		?>
        <a class="btn btn-outline-success" href="https://wa.me/<?php echo esc_url($link) ?>">
            <i class="fab fa-whatsapp fa-2x"></i>
            <span>Heed help?<br>+994 50 123 45 67</span>
        </a>
		<?php
	}

}
