<?php


namespace classes\components\navigations\custom;


use classes\abstracts\LavBaseComponent;


class LavCustomWishlistIcon extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$link = get_permalink( $this->getValue( 'shop-wishlist-page' ) );
		?>
        <a type="button" href="<?php echo esc_url( $link ) ?>" class="btn lav-wishlist">
            <i class="lab la-gratipay"></i>
        </a>
		<?php
	}

}
