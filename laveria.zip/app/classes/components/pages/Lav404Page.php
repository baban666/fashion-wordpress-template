<?php


namespace classes\components\pages;


use classes\abstracts\LavBaseComponent;


class Lav404Page extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>

        <!-- Start Content -->
        <div class="wrapper <?php echo esc_attr( 'col' ); ?>" id="page-wrapper" data-sticky-container>
            <?php if ( !$this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-container' ) ): ?>
                <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>" id="content" tabindex="-1">
            <?php endif; ?>
                    <div class="row full-row">
                        <!-- Start Main -->
                        <main id="primary" class="site-main content-area col-md-12">
	                        <?php if ( $this->getValue('general-page-header-layout') !== 'full-width') : ?>
		                        <?php $this->components->getComponent( '404-header' )->render(); ?>
	                        <?php endif; ?>
                            <section class="error-404 not-found">

                                <div class="page-content">
                                    <h2 class="widget-title">
                                        <?php esc_html_e( '404', 'laveria' ); ?>
                                    </h2>
                                    <p class="widget-desc">
                                        <?php esc_html_e( 'Page Not Found', 'laveria' ); ?>
                                    </p>
                                    <a class="lav-btn-default"  href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Homepage', 'laveria' ); ?></a>
                                </div><!-- .page-content -->
                            </section><!-- .error-404 -->

                        </main><!-- #main -->
                        <!-- End Main -->
                    </div><!-- .row -->

            <?php if ( !$this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-container' ) ): ?>
                </div><!-- #content -->
            <?php endif; ?>
        </div><!-- #page-wrapper -->
        <!-- End Content -->
		<?php
		get_footer();
	}

}



