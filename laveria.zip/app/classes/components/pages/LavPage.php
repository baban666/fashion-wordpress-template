<?php


namespace classes\components\pages;


use classes\abstracts\LavBaseComponent;


class LavPage extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$fullRow = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-container' ) ? 'full-row' : 'box-row';
		$globalColumn = $this->helper->getPageColumn($this->settings);
		if ( $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-sidebar' ) ) {
			$globalColumn = 'col-md-12';
		}
		?>

        <!-- Start Content -->
        <div class="wrapper <?php echo esc_attr( 'col' ); ?>" id="page-wrapper" data-sticky-container>
            <?php if ( !$this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-container' ) ): ?>
                <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>" id="content" tabindex="-1">
            <?php endif; ?>
                    <div class="row <?php echo esc_attr( $fullRow ); ?>">
                        <!-- Start Main -->
                        <main id="primary" class="site-main content-area <?php echo esc_attr( $globalColumn ); ?>">

                            <?php

                            while ( have_posts() ) :
                                the_post();
                                ?>
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                    <?php if ( $this->getValue('general-page-header-layout') !== 'full-width' && !$this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-header' ) ) : ?>
                                         <?php $this->components->getComponent( 'page-header' )->render(); ?>
                                    <?php endif; ?>
                                    <div class="entry-content">
                                        <?php
                                        the_content();

                                        wp_link_pages(
                                            array(
                                                'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'laveria' ),
                                                'after'  => '</div>',
                                            )
                                        );
                                        ?>
                                    </div><!-- .entry-content -->

                                    <?php if ( get_edit_post_link() ) : ?>
                                        <footer class="entry-footer page-footer container">
                                            <?php
                                            edit_post_link(
                                                sprintf(
                                                    wp_kses(
                                                    /* translators: %s: Name of current post. Only visible to screen readers */
                                                        __( 'Edit <span class="screen-reader-text">%s</span>', 'laveria' ),
                                                        array(
                                                            'span' => array(
                                                                'class' => array(),
                                                            ),
                                                        )
                                                    ),
                                                    wp_kses_post( get_the_title() )
                                                ),
                                                '<span class="edit-link">',
                                                '</span>'
                                            );
                                            ?>
                                        </footer><!-- .entry-footer -->
                                    <?php endif; ?>
                                </article><!-- #post-<?php the_ID(); ?> -->


                                <?php

                                // If comments are open or we have at least one comment, load up the comment template.
                                if ( comments_open() || get_comments_number() ) :
                                    comments_template();
                                endif;

                            endwhile; // End of the loop.
                            ?>

                        </main><!-- #main -->
                        <!-- End Main -->

                        <!-- Start Sidebar -->
                        <?php get_sidebar(); ?>
                        <!-- End Sidebar -->
                    </div><!-- .row -->

            <?php if ( !$this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-container' ) ): ?>
                </div><!-- #content -->
            <?php endif; ?>
        </div><!-- #page-wrapper -->
        <!-- End Content -->
		<?php
		get_footer();
	}

}
