<?php


namespace classes\components\pages;


use classes\abstracts\LavBaseComponent;


class LavSearchPage extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>

        <!-- Start Content -->
        <div class="wrapper <?php echo esc_attr( 'col' ); ?>" id="page-wrapper" data-sticky-container>

            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?>" id="content" tabindex="-1">
                <div class="row">

                    <!-- Start Main -->
                    <main id="primary" class="site-main content-area <?php echo esc_attr( $this->helper->getPageColumn($this->settings) ); ?>">
	                    <?php if ( $this->getValue('general-blog-header-layout') !== 'full-width' ) : ?>
		                    <?php $this->components->getComponent( 'search-header' )->render(); ?>
	                    <?php endif; ?>

                        <?php if ( have_posts() ) : ?>
                            <div class="row">
								<?php $this->components->getComponent( 'loop-cards' )->render( $args ); ?>
                            </div><!-- .row -->
							<?php
							$this->components->getComponent( 'pagination' )->render();
						else :
							$this->components->getComponent( 'content-none' )->render();
						endif;
						?>
                    </main><!-- #main -->
                    <!-- End Main -->

                    <!-- Start Sidebar -->
					<?php get_sidebar(); ?>
                    <!-- End Sidebar -->
                </div><!-- .row -->

            </div><!-- #content -->

        </div><!-- #page-wrapper -->
        <!-- End Content -->
		<?php
		get_footer();
	}

}
