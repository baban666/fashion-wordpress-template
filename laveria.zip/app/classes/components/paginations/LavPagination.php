<?php


namespace classes\components\paginations;

use classes\abstracts\LavBaseComponent;


class LavPagination extends LavBaseComponent {
	public $pagination;

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		$pagination = !empty($this->getValue('general-pagination'))
            ? $this->getValue('general-pagination')
            : 'simply';
		$this->setPagination( $pagination );
	}

	public function getPagination() {
		if ( $this->pagination === 'prev-next' ) {
			return the_posts_navigation();
		} else {
			return $this->simplePagination();
		}
	}

	public function render( $args = null ) {
		$this->getPagination();
	}

	public function setPagination( $pagination ) {
		$this->pagination = $pagination;
	}

	public function simplePagination( $args = array(), $class = 'pagination' ) {

		if ( ! isset( $args['total'] ) && $GLOBALS['wp_query']->max_num_pages <= 1 ) {
			return;
		}

		$args = wp_parse_args(
			$args,
			array(
				'mid_size'           => 2,
				'prev_next'          => true,
				'prev_text'          => '<i class="las la-arrow-left"></i>',
				'next_text'          => '<i class="las la-arrow-right"></i>',
				'type'               => 'array',
				'current'            => max( 1, get_query_var( 'paged' ) ),
				'screen_reader_text' => __( 'Posts navigation', 'laveria' ),
			)
		);

		$links = paginate_links( $args );
		if ( ! $links ) {
			return;
		}

		?>

        <nav aria-labelledby="posts-nav-label">

            <h2 id="posts-nav-label" class="screen-reader-text">
				<?php echo esc_html( $args['screen_reader_text'] ); ?>
            </h2>

            <ul class="<?php echo esc_attr( $class ); ?>">

				<?php
				foreach ( $links as $key => $link ) {
					?>
                    <li class="page-item <?php echo strpos( $link, 'current' ) ? 'active' : ''; ?>">
						<?php echo str_replace( 'page-numbers', 'page-link', $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </li>
					<?php
				}
				?>

            </ul>

        </nav>

		<?php
	}


}
