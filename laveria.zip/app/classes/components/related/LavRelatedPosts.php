<?php


namespace classes\components\related;

use classes\abstracts\LavBaseComponent;


class LavRelatedPosts extends LavBaseComponent  {
	public $args;
	public $template;
	public static $template_path = LAV_TPL_PATH . '/loops/';

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		$this->setTemplate('related-grid');
	}

	public function setTemplate( $template ) {
		$this->template = $template;
	}

	public function getArgs($id) {
		$post_qty = (int) $this->getValue('global-single-related-quantity');
		switch ($this->getValue('global-single-related-type')) :
			case 'tag':
				$tags = wp_get_post_tags($id);
				if ($tags) {
					$tag_ids = array();
					foreach ($tags as $individual_tag) {
						$tag_ids[] = $individual_tag->term_id;
					}

					$this->args = array(
						'tag__in' => $tag_ids,
						'post__not_in' => array($id),
						'posts_per_page' => $post_qty,
						'ignore_sticky_posts' => true
					);
				}
				break;

			default :
				$categories = get_the_category($id);

				if ($categories) {
					$category_ids = array();
					foreach ($categories as $individual_category) {
						$category_ids[] = $individual_category->term_id;
					}

					$this->args = array(
						'category__in' => $category_ids,
						'post__not_in' => array($id),
						'showposts' => $post_qty,
						'ignore_sticky_posts' => true
					);
				}
		endswitch;
				return $this->args;
	}

	public function render($id = null) {
		$posts = new \WP_Query( $this->getArgs($id) );
			?>
		<div class="related-posts lav-posts-grid">
            <div class="alice-icon-box-content">
                <div class="alice-icon-box-icon">
                    <h2 class="related-posts-heading">
		                <?php echo esc_html__('Related posts', 'laveria'); ?>
                    </h2>
                </div>
            </div>
            <div class="posts-cards row">
                <?php if ($posts->have_posts()) : ?>
                    <?php while ( $posts->have_posts() ) : $posts->the_post(); ?>
                        <?php include self::$template_path . $this->template . '.php'; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <div class="col-md-12 not-found">
                        <p>
	                        <?php echo esc_html__( 'No Contents Found', 'laveria' ); ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
		</div>
		<?php
		wp_reset_postdata();
	}

}
