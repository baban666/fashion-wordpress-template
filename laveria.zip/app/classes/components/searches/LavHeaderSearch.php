<?php


namespace classes\components\searches;


use classes\abstracts\LavBaseComponent;



class LavHeaderSearch extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Search Icon -->
        <button type="button" class="search-toggle" data-bs-toggle="modal"
                data-bs-target="#searchModal">
            <i class="las la-search"></i>
        </button>
        <!-- Search Icon End -->
        <?php

	}

}
