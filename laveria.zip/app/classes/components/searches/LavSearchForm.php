<?php


namespace classes\components\searches;


use classes\abstracts\LavBaseComponent;



class LavSearchForm extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Full Screen Search Start -->
        <div class="modal search-modal fade" id="searchModal" tabindex="-1">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <i class="las la-times"></i>
                        </button>
                    </div>
                    <div class="modal-body d-flex align-items-center justify-content-center">
                        <?php get_search_form() ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Full Screen Search End -->
        <?php

	}

}
