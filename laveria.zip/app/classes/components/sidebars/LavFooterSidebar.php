<?php


namespace classes\components\sidebars;


use classes\abstracts\LavBaseComponent;


class LavFooterSidebar extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		add_action( 'widgets_init', array($this, 'registerSidebars') );
	}

	public function getSidebarsQuantity() {

        $count = 0;
		for ($i = 1; $i <= 4; $i++) {
			if (is_active_sidebar( 'lav-footer-' . $i )){
				$count += 1;
            }
		}
		return $count;

	}

	public function getColumnClass($quantity) {

		switch ($quantity) {
			case 2:
				return 'col-lg-6 col-md-6';
				break;
			case 3:
				return 'col-lg-4 col-md-12';
				break;
			case 4:
				return 'col-lg-3 col-md-6';
				break;
			default:
				return 'col-lg-12 col-md-12';
		}

	}

	public function renderColumn( $index, $class ) {

		if ( ! is_active_sidebar( 'lav-footer-' . $index ) ) {
			return;
		}
		?>
        <!-- Footer column Start -->
        <div class=" <?php echo esc_attr($class)?>">
	        <?php dynamic_sidebar( 'lav-footer-' . $index ); ?>
        </div>
        <!-- Footer column End -->
		<?php

	}

	public function render( $args = null ) {

	    $sidebarQuantity = $this->getSidebarsQuantity();
	    if($sidebarQuantity === 0){
	        return;
	    }
		for ($i = 1; $i <= 4; $i++) {
			$this->renderColumn($i, $this->getColumnClass($sidebarQuantity));
		}

	}

	public function registerSidebars() {

		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 1', 'laveria' ),
				'id'            => 'lav-footer-1',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 2', 'laveria' ),
				'id'            => 'lav-footer-2',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 3', 'laveria' ),
				'id'            => 'lav-footer-3',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 4', 'laveria' ),
				'id'            => 'lav-footer-4',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

	}
}
