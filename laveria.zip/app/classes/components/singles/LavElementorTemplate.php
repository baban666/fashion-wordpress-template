<?php


namespace classes\components\singles;


use classes\abstracts\LavBaseComponent;


class LavElementorTemplate extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		while ( have_posts() ) :
			the_post();

			?>

            <!-- Start Content -->
            <div class="wrapper  <?php echo esc_attr( 'col ps-md-2' ); ?>" id="page-wrapper">

                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>" id="content"
                     tabindex="-1">

                    <div class="row">

                        <!-- Start Main -->
                        <main id="primary"
                              class="site-main content-area col-md-12">
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                    <div class="entry-content">
										<?php
										the_content(
											sprintf(
												wp_kses(
												/* translators: %s: Name of current post. Only visible to screen readers */
													__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'laveria' ),
													array(
														'span' => array(
															'class' => array(),
														),
													)
												),
												wp_kses_post( get_the_title() )
											)
										);

										wp_link_pages(
											array(
												'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'laveria' ),
												'after'  => '</div>',
											)
										);
										?>
                                    </div><!-- .entry-content -->
                                </article><!-- #post-<?php the_ID(); ?> -->
                        </main><!-- #main -->
                        <!-- End Main -->

                    </div><!-- .row -->

                </div><!-- #content -->

            </div><!-- #page-wrapper -->
            <!-- End Content -->
		<?php
		endwhile; // End of the loop.
		get_footer();
	}

}
