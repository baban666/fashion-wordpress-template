<?php


namespace classes\components\singles;


use classes\abstracts\LavBaseComponent;


class LavSingleDefault extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		while ( have_posts() ) :
			the_post();
			$this->components->getComponent( 'single-default-header' )->render();
			?>

            <!-- Start Content -->
            <div class="wrapper  <?php echo esc_attr( 'col ps-md-2' ); ?>" id="page-wrapper">

                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>" id="content"
                     tabindex="-1">

                    <div class="row">

                        <!-- Start Main -->
                        <main id="primary"
                              class="site-main content-area <?php echo esc_attr( $this->helper->getPageColumn( $this->settings ) ); ?>">
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                                    <div class="entry-content">
										<?php
										the_content(
											sprintf(
												wp_kses(
												/* translators: %s: Name of current post. Only visible to screen readers */
													__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'laveria' ),
													array(
														'span' => array(
															'class' => array(),
														),
													)
												),
												wp_kses_post( get_the_title() )
											)
										);

										wp_link_pages(
											array(
												'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'laveria' ),
												'after'  => '</div>',
											)
										);
										?>
                                    </div><!-- .entry-content -->
									<?php if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-tag' ), $this->getValue( 'global-single-show-tag' ) ) ): ?>
                                        <footer class="entry-footer post-footer">
											<?php lav_entry_footer(); ?>
                                        </footer><!-- .entry-footer -->
									<?php endif; ?>
                                </article><!-- #post-<?php the_ID(); ?> -->

								<?php

								if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author-section' ), $this->getValue( 'global-single-show-author-section' ) )) {
									$this->components->getComponent( 'single-author-info' )->render();
								}

								if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-related' ), $this->getValue( 'global-single-show-related' ) ) ) {
									$this->components->getComponent( 'related' )->render( get_the_ID() );
								}

								if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-nav' ), $this->getValue( 'global-single-show-nav' ) )) {
									$this->components->getComponent( 'post-nav' )->render();
								}

								// If comments are open or we have at least one comment, load up the comment template.
								if ( comments_open() || get_comments_number() ) :
									comments_template();
								endif;


								?>

                        </main><!-- #main -->
                        <!-- End Main -->

                        <!-- Start Sidebar -->
						<?php get_sidebar(); ?>
                        <!-- End Sidebar -->
                    </div><!-- .row -->

                </div><!-- #content -->

            </div><!-- #page-wrapper -->
            <!-- End Content -->
		<?php
		endwhile; // End of the loop.
		get_footer();
	}

}
