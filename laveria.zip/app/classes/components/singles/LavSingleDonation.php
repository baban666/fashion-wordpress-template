<?php


namespace classes\components\singles;


use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;


class LavSingleDonation extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		while ( have_posts() ) :
			the_post();

			$cover = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-donation-cover' );
			$shortcode = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-shortcode' );

			$this->components->getComponent( 'single-review-header' )->render();

			?>
            <!-- Start Content -->
            <div class="wrapper single-donation <?php echo esc_attr( 'col ps-md-2' ); ?>" data-sticky-container id="page-wrapper">
                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>" id="content"
                     tabindex="-1">
                    <div class="row">
                        <div class="col-md-12 col-lg-3 book-rating">
                            <div class="donation-info">
		                        <?php if ( !empty($cover['url']) ): ?>
                                    <div class="rating-image">
                                        <img src="<?php echo esc_url($cover['url']); ?>" alt="<?php echo esc_attr($cover['alt']); ?>" class="book-image">
                                    </div>
		                        <?php endif; ?>
                                <div id="sticky-section" data-sticky-for="992" data-margin-top="85" class="donation-box">
                                <?php if ( !empty($shortcode) ): ?>
                                    <?php echo  do_shortcode($shortcode); ?>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <!-- Start Main -->
                        <main id="primary" class="site-main content-area col-md-12 col-lg-9">
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                    <div class="entry-content">
					                    <?php
					                    the_content(
						                    sprintf(
							                    wp_kses(
							                    /* translators: %s: Name of current post. Only visible to screen readers */
								                    __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'laveria' ),
								                    array(
									                    'span' => array(
										                    'class' => array(),
									                    ),
								                    )
							                    ),
							                    wp_kses_post( get_the_title() )
						                    )
					                    );

					                    wp_link_pages(
						                    array(
							                    'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'laveria' ),
							                    'after'  => '</div>',
						                    )
					                    );
					                    ?>
                                    </div><!-- .entry-content -->
				                    <?php if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-tag' ), $this->getValue( 'global-single-show-tag' ) ) ): ?>
                                        <footer class="entry-footer post-footer">
						                    <?php lav_entry_footer(); ?>
                                        </footer><!-- .entry-footer -->
				                    <?php endif; ?>
                                </article><!-- #post-<?php the_ID(); ?> -->
			                    <?php

			                    if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author-section' ), $this->getValue( 'global-single-show-author-section' ) )) {
				                    $this->components->getComponent( 'single-author-info' )->render();
			                    }

			                    if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-related' ), $this->getValue( 'global-single-show-related' ) )) {
				                    $this->components->getComponent( 'related' )->render( get_the_ID() );
			                    }

			                    if ( $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-nav' ), $this->getValue( 'global-single-show-nav' ) )) {
				                    $this->components->getComponent( 'post-nav' )->render();
			                    }

			                    // If comments are open or we have at least one comment, load up the comment template.
			                    if ( comments_open() || get_comments_number() ) :
				                    comments_template();
			                    endif;
			                    ?>
                        </main><!-- #main -->
                        <!-- End Main -->
                    </div><!-- .row -->
                </div><!-- #content -->
            </div><!-- #page-wrapper -->
            <!-- End Content -->
		<?php
		endwhile; // End of the loop.
		get_footer();
	}

}
