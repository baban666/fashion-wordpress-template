<?php


namespace classes\components\singles;

use classes\abstracts\LavBaseComponent;
use classes\providers\LavHelpersProvider;


class LavSingleReading extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		while ( have_posts() ) :
			the_post();
			$toc         = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-reading-toc' );
			$showRelated = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-related' ), $this->getValue( 'global-single-show-related' ) );
			$showNav = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-nav' ), $this->getValue( 'global-single-show-nav' ) );
			$showTag = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-tag' ), $this->getValue( 'global-single-show-tag' ) );
			$showAuthorSection = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author-section' ), $this->getValue( 'global-single-show-author-section' ) );

			$this->components->getComponent( 'single-reading-header' )->render();



			$showCat = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-category' ), $this->getValue( 'global-single-show-category' ) );
			$showDate = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-date' ), $this->getValue( 'global-single-show-date' ) );
			$showAuthor = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-author' ), $this->getValue( 'global-single-show-author' ) );
			$showComments = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-comment' ), $this->getValue( 'global-single-show-comment' ) );
			$showCrumbs = $this->helper->isActiveMeta( $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-show-crumbs' ), $this->getValue( 'global-single-show-crumbs' ) );

			$actionText = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-reading-action-text' );
			$actionLink = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-reading-action-link' );
			$desc = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-reading-description' );
			$target = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-reading-action-new-window' ) ? '_blank' : '_self';
			$share = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-reading-share' );

			?>
            <!-- Start Content -->
            <div class="wrapper single-reading <?php echo esc_attr( 'col ps-md-2' ); ?>" data-sticky-container
                 id="page-wrapper">
                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>" id="content"
                     tabindex="-1">
                    <div class="row">
                        <div class="col-md-12 col-lg-1 pt-3">
                            <div id="sticky-section" data-sticky-for="992" data-margin-top="85" class="content-box">
                            <?php if ( $showComments ): ?>
                                <div class="comments">
                                    <a href="<?php echo esc_url( get_comments_link() ); ?>">
                                        <i class="las la-comment"></i>
                                        <?php echo get_comments_number(); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $share ) ): ?>
	                            <?php $this->components->getComponent( 'share-buttons' )->render(); ?>
                            <?php endif; ?>
                            </div>
                        </div>
                        <!-- Start Main -->
                        <main id="primary" class="site-main content-area col-md-12 col-lg-9">
                            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                <div class="post-hero">
                                    <div class="hero-text">
	                                    <?php if ( $showCrumbs ): ?>
                                            <div class="d-flex justify-content-start align-items-start">
			                                    <?php $this->components->getComponent( 'breadcrumbs' )->render( array( 'blog' => esc_html__('Blog', 'laveria') , 'home' => esc_html__('Home', 'laveria') ) ); ?>
                                            </div>
	                                    <?php endif; ?>
                                        <div class="entry-header">
			                                <?php the_title( '<h1 class="entry-title text-start">', '</h1>' ); ?>
                                        </div><!-- .entry-header -->
		                                <?php if ( $showCat ): ?>
			                                <?php the_category(); ?>
		                                <?php endif; ?>
		                                <?php if($desc): ?>
                                            <div class="single-desc">
				                                <?php echo esc_html($desc); ?>
                                            </div>
		                                <?php endif; ?>
		                                <?php if($actionText && $actionLink): ?>
                                            <div class="single-action">
                                                <a  class="lav-btn-default" href="<?php echo esc_url($actionLink) ?>" target="<?php echo esc_attr($target);?>">
					                                <?php echo esc_html($actionText); ?>
                                                </a>
                                            </div>
		                                <?php endif; ?>
                                        <div class="entry-meta">
	                                        <?php if ( $showAuthor): ?>
		                                        <?php $this->components->getComponent( 'author-avatar' )->render(); ?>
	                                        <?php endif; ?>
			                                <?php if ( $showDate ): ?>
				                                <?php lav_posted_on(); ?>
			                                <?php endif; ?>
                                        </div><!-- .entry-meta -->
                                    </div>
                                </div>

                                <div class="entry-content">
                                    <?php
									the_content(
										sprintf(
											wp_kses(
											/* translators: %s: Name of current post. Only visible to screen readers */
												__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'laveria' ),
												array(
													'span' => array(
														'class' => array(),
													),
												)
											),
											wp_kses_post( get_the_title() )
										)
									);

									wp_link_pages(
										array(
											'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'laveria' ),
											'after'  => '</div>',
										)
									);
									?>
                                </div><!-- .entry-content -->
								<?php if ( $showTag ): ?>
                                    <footer class="entry-footer post-footer">
										<?php lav_entry_footer(); ?>
                                    </footer><!-- .entry-footer -->
								<?php endif; ?>
                            </article><!-- #post-<?php the_ID(); ?> -->
							<?php

							if ( $showAuthorSection ) {
								$this->components->getComponent( 'single-author-info' )->render();
							}

							if ( $showRelated ) {
								$this->components->getComponent( 'related' )->render( get_the_ID() );
							}

							if ( $showNav ) {
								$this->components->getComponent( 'post-nav' )->render();
							}

							// If comments are open or we have at least one comment, load up the comment template.
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
							?>
                        </main><!-- #main -->
                        <!-- End Main -->
                        <div class="col-md-12 col-lg-2 pt-3">
                            <div id="sticky-section" data-sticky-for="992" data-margin-top="85" class="content-box">
                            <?php if ( ! empty( $toc ) ): ?>
                                <?php $this->helper->getReadingToc( $toc ) ?>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div><!-- .row -->
                </div><!-- #content -->
            </div><!-- #page-wrapper -->
            <!-- End Content -->
		<?php
		endwhile; // End of the loop.
		get_footer();
	}

}
