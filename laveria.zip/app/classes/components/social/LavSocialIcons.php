<?php


namespace classes\components\social;


use classes\abstracts\LavBaseComponent;

class LavSocialIcons extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		$blank = $this->getValue('social-target') == '1' ? 'target=_blank' : 'target=_self';
		?>
        <div class="social-icons-widget py-1">
            <div class="effect <?php echo esc_attr( $this->getValue('social-effects') ); ?> <?php echo esc_attr( $this->getValue('social-color') ); ?>">
                <div class="buttons">
	                <?php if ( $this->getValue('social-desc') ) : ?>
                        <span class="social-desc"><?php echo esc_html( $this->getValue('social-desc') ); ?></span>
	                <?php endif; ?>
					<?php if ( $this->getValue('social-facebook') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-facebook') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="fb" title="Facebook">
                            <i class="lab la-facebook-f"></i>
                        </a>
					<?php endif; ?>

					<?php if ( $this->getValue('social-twitter') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-twitter') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="tw" title="Twitter">
                            <i class="lab la-twitter"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-instagram') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-instagram') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="insta" title="Instagram">
                            <i class="lab la-instagram"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-good') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-good')); ?>" <?php echo esc_attr( $blank ); ?>
                           class="goodreads" title="Goodreads">
                            <i class="lab la-goodreads-g"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-wa') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-wa') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="whatsapp" title="WhatsApp">
                            <i class="lab la-whatsapp"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-youtube') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-youtube') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="youtube" title="Youtube">
                            <i class="lab la-youtube"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-vimeo') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-vimeo')); ?>" <?php echo esc_attr( $blank ); ?>
                           class="vimeo" title="Vimeo">
                            <i class="lab la-vimeo"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-pinterest') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-pinterest') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="pinterest" title="Pinterest">
                            <i class="lab la-pinterest-p"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-linkedin') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-linkedin') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="in" title="Linked">
                            <i class="lab la-linkedin-in"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-soundcloud') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-soundcloud')); ?>" <?php echo esc_attr( $blank ); ?>
                           class="soundcloud" title="Soundcloud">
                            <i class="lab la-soundcloud"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-vk') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-vk') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="vk" title="VK">
                            <i class="lab la-vk"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-telegram') ) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-telegram') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="telegram" title="Telegram">
                            <i class="lab la-telegram-plane"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-ok')) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-ok') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="ok" title="Odnoklassniki">
                            <i class="lab la-odnoklassniki"></i>
                        </a>
					<?php endif; ?>
					<?php if ( $this->getValue('social-google')) : ?>
                        <a href="<?php echo esc_url( $this->getValue('social-google') ); ?>" <?php echo esc_attr( $blank ); ?>
                           class="google-b" title="google My Business">
                            <i class="lab la-google"></i>
                        </a>
					<?php endif; ?>
                </div>
            </div>
        </div>
		<?php

	}
}
