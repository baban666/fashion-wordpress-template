<?php


namespace classes\components\spinner;


use classes\abstracts\LavBaseComponent;



class LavSpinner extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Spinner Start -->
        <div class="alice-spinner">
            <div id="alice-spinner-preloader">
                <div id="alice-spinner-status">
                    <div class="spinner">
                        <div class="rect1"></div>
                        <div class="rect2"></div>
                        <div class="rect3"></div>
                        <div class="rect4"></div>
                        <div class="rect5"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Spinner End -->
        <?php

	}

}
