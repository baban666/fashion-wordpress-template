<?php


namespace classes\components\top;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavTopLine extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
        <!-- Topbar Start -->
        <div class="top-bar d-none d-xxl-block d-xl-block d-lg-block">
            <div class="<?php echo esc_attr( $this->helper->getContainer($this->settings) ); ?> top-line d-none d-lg-block">
                <div class="row">
                    <div class="col-md-9 text-lg-start well-contacts">
	                    <?php if($this->getValue('header-address-top') === '1' || $this->getValue('header-email-top') === '1' || $this->getValue('header-top-menu') === '1'): ?>
                            <div class="position-relative d-inline-flex align-items-center">
	                            <?php if($this->getValue('header-top-menu') === '1'): ?>
		                            <?php $this->components->getComponent( 'top-menu' )->render(); ?>
	                            <?php endif; ?>
	                            <?php if($this->getValue('header-email-top') === '1'): ?>
		                            <?php $this->components->getComponent( 'mail-top' )->render(); ?>
	                            <?php endif; ?>
	                            <?php if($this->getValue('header-address-top') === '1'): ?>
		                            <?php $this->components->getComponent( 'address-top' )->render(); ?>
	                            <?php endif; ?>
                            </div>
	                    <?php endif; ?>
                    </div>
                    <div class="col-md-3 text-lg-end">
	                    <?php if($this->getValue('header-phone-top') === '1'): ?>
		                    <?php $this->components->getComponent( 'phone-top' )->render(); ?>
	                    <?php endif; ?>
	                    <?php if($this->getValue('header-social-top')): ?>
                            <div class="d-inline-flex">
			                    <?php $this->components->getComponent( 'social' )->render(); ?>
                            </div>
	                    <?php endif; ?>
                    </div>
                </div>
            </div><!-- .container(-fluid) -->
        </div>
        <!-- Topbar End -->
        <?php

	}

}
