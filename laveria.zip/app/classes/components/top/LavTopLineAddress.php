<?php


namespace classes\components\top;


use classes\abstracts\LavBaseComponent;



class LavTopLineAddress extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		?>
		<?php if($this->getValue('header-address')): ?>
            <div class="py-1 phone-info">
                <p class="m-0">
                    <i class="las la-map-marker"></i><?php echo esc_html($this->getValue('header-address')) ?>
                </p>
            </div>
		<?php endif; ?>
        <?php

	}

}
