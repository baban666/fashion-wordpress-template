<?php


namespace classes\components\top;


use classes\abstracts\LavBaseComponent;



class LavTopLineEAddress extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$blank = $this->getValue('header-email-target') == '1' ? 'target=_blank' : 'target=_self';
		?>
		<?php if($this->getValue('header-email')): ?>
            <div class="py-1 email-info">
                <a class="top-info" href="mailto:<?php echo esc_html($this->getValue('header-email')) ?>" <?php echo esc_attr( $blank ); ?>>
                    <i class="las la-envelope-open"></i><?php echo esc_html($this->getValue('header-email')) ?>
                </a>
            </div>
		<?php endif; ?>
        <?php

	}

}
