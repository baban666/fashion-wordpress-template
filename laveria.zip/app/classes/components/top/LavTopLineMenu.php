<?php


namespace classes\components\top;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavTopLineMenu extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

		?>
            <div class="py-1 top-menu">
                <nav class="navbar" role="navigation">
		            <?php
		            wp_nav_menu( array(
			            'theme_location'  => 'menu-4',
			            'depth'           => 2,
			            'container'       => 'div',
			            'container_class' => 'top-nav',
			            'container_id'    => 'top-nav-menu',
			            'menu_class'      => 'nav',
			            'fallback_cb'     => 'LavNavWalker::fallback',
			            'walker'          => new LavNavWalker( '' ),
		            ) );
		            ?>
                </nav>
            </div>
		<?php

	}

}
