<?php


namespace classes\components\top;


use classes\abstracts\LavBaseComponent;
use classes\components\walkers\LavNavWalker;


class LavTopLinePhone extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = '' ) {
		$iconPhone = $this->getValue( 'icons-phone' );
		$text = $this->getValue( 'header-phone' );
		$link = $this->getValue( 'header-phone-link' );

		?>
		<?php if ( !empty($text) ): ?>
            <div class="py-1 phone-info">
                <p class="m-0">
					<?php if ( ! empty( $iconPhone['url'] ) ): ?>
                        <img src="<?php echo esc_url( $iconPhone['url'] ) ?>" class="custom-phone"
                             alt="<?php echo esc_attr( $iconPhone['alt'] ) ?>">
					<?php else: ?>
                        <i class="las la-phone"></i>
					<?php endif; ?>
	                <?php if ( ! empty( $link ) ): ?>
                        <a class="top-info" href="tel:<?php echo esc_html($link) ?>" target="_blank">
			                <?php echo esc_html( $text); ?>
                        </a>
	                <?php else: ?>
		                <?php echo esc_html( $text ); ?>
	                <?php endif; ?>
                </p>
            </div>
		<?php endif; ?>
		<?php

	}

}
