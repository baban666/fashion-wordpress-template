<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavProductCountDown extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( $this->getValue( 'shop-single-countdown-enable' ) ) {
			add_action( 'woocommerce_single_product_summary', array( $this, 'renderTimer' ), 15 );
		}
	}

	public function render( $args = array() ) {
	    if($this->getValue( 'shop-archive-countdown-enable' )){
		    $this->renderTimer();
        }
	}

	public function renderTimer() {
		global $product;
		// Get the product sale end date
		$sale_end = $product->get_date_on_sale_to();
		$due_date = $sale_end ? $sale_end->getTimestamp() : null;
		$class  = 'countdown-single';
		$title = $this->getValue( 'shop-single-countdown-text' );
		if ( empty( $due_date ) ) {
			return;
		}
		if ( is_archive() ) {
			$title = $this->getValue( 'shop-archive-countdown-text' );
		}
		// Set labels for the countdown timer
		$labels = sprintf( '%1$s|%2$s|%3$s|%4$s',
			esc_html__( 'Days', 'alice-core' ),
			esc_html__( 'Hours', 'alice-core' ),
			esc_html__( 'Minutes', 'alice-core' ),
			esc_html__( 'Seconds', 'alice-core' )
		);

		?>
		<?php if ( $product->is_on_sale() ) : ?>
            <div class="alice-countdown alice-product-countdown <?php echo esc_attr( $class ); ?>">
                <div class="countdown-wrapper">
	                <?php if ( true ) : ?>
                        <!-- Display Discount -->
                        <div class="product-discount">
			                <?php echo esc_html($title ); ?>
                        </div>
	                <?php endif; ?>
                    <!-- Countdown Timer -->
	                <?php if ( date( "Y-m-d H:i:s" ) < date( "Y-m-d H:i:s", $due_date ) ) : ?>
                        <div class="flipper single-product flipper-<?php echo esc_attr( $class ); ?>"
                             data-datetime="<?php echo esc_html( date( "Y-m-d H:i:s", $due_date ) ); ?>"
                             data-template="ddd|HH|ii|ss"
                             data-labels="<?php echo esc_html( $labels ); ?>"
                             data-reverse="true">
                        </div>
	                <?php endif; ?>
                </div>

            </div>
		<?php endif; ?>
		<?php
	}
}
