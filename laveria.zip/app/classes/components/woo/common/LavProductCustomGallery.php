<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavProductCustomGallery extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		add_filter( 'woocommerce_product_tabs', array($this, 'render') );
	}

	public function render( $tabs = null ) {
		if(empty($this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-custom-gallery-enable'))){
			return $tabs;
		}

		$gallery = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-custom-gallery');

		if( empty($gallery)){
	        return $tabs;
        }

		$title = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-custom-gallery-title');
		$subTitle = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-custom-gallery-sub-title');

		if ( isset( $tabs['description'] ) ) {
			$original_description = $tabs['description']['callback'];
			// Override the callback function to append the custom text
			$tabs['description']['callback'] = function() use ( $original_description, $gallery, $title, $subTitle ) {
				// Call the original description callback
				if ( is_callable( $original_description ) ) {
					call_user_func( $original_description );
				}
				wp_enqueue_script('macy');
				// Add your custom info after the product description
				echo '<div class="alice-masonry-grid-section">';
				if ( !empty($subTitle) ) {
					echo '<p class="custom-product-masonry-sub-title">'. esc_html__($subTitle).'</p>';
				}
				if ( !empty($title) ) {
					echo '<h2 class="custom-product-masonry-title">'. esc_html__($title).'</h2>';
				}
				echo '<div id="custom-product-masonry-grid" class="alice-masonry-grid">'. $this->renderGallery($gallery) .'</div>';
				echo '</div>';
			};
		}
		return $tabs;
	}

	public function renderGallery($gallery = null) {
		$attachment_ids = explode( ',', $gallery );
		$html = '';

		foreach ( $attachment_ids as $attachment_id ) {
			$image_url           = wp_get_attachment_url( $attachment_id );
			$image_alt           = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			$image_full_size_url = wp_get_attachment_image_url( $attachment_id, 'full' );
			$image_title  = get_the_title( $attachment_id );
			$title = '<h6 class="custom-gallery-img-holder invisible">' . esc_html__( 'Image', 'laveria'  ) . '</h6>';
			// If the alt text is empty, get the product title
			if ( empty( $image_alt ) ) {
				$product_title = get_the_title(); // Assuming this is within a product loop
				$image_alt = $product_title; // Use product title if alt is empty
			}
			if ( !empty( $image_title  ) ) {
				$title = '<h6 class="custom-gallery-img-title">' . esc_html( $image_title) . '</h6>';
			}

			$html .= '<div class="custom-gallery-item-wrapper">'. $title  .'<div class="alice-masonry-grid-item fancybox" data-fancybox="gallery"  data-fancybox data-src="' . esc_url( $image_full_size_url ) . '"><img class="demo-image" src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $image_alt ) . '"></div></div>';
		}
		return $html;
	}
}
