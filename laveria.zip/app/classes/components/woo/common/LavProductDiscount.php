<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavProductDiscount extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = array( 'echo' => true, 'style' => true, 'pid' => null ) ) {

		$echo  = $args['echo'];
		$style = $args['style'];
		$pid   = $args['pid'];

		if ( $pid ) {
			$product = wc_get_product( $pid );
		} else {
			global $product;
		}

		$style    = $style ? ' label-red' : '';
		if ( $product->is_type( 'variable' ) ) {
			$productt   = wc_get_product( $product->get_id() );
			$variations = $productt->get_available_variations();
			$saving     = '';

			foreach ( $variations as $variation ) {
				$regular = $variation['display_regular_price'];
				$sale    = $variation['display_price'];

				if ( $regular > 0 ) {
					$saving = $regular && $sale ? round( ( ( ( $regular - $sale ) / $regular ) * 100 ), 0 ) : '';
					$saving = $saving > 0 ? $saving . '%' : '';
				}
			}
			if ( $echo == true ) {
				echo ! empty( $saving ) && $saving > 0 ? '<span class="alice-discount' . $style . '">' . $saving . '</span>' : '';
			} else {
				return ! empty( $saving ) && $saving > 0 ? '<span class="alice-discount' . $style . '">' . $saving . '</span>' : '';
			}

		} else {

			if ( $product->is_on_sale() ) {
				$regular = (float) $product->get_regular_price();
				$sale    = (float) $product->get_sale_price();
				$saving  = $sale && $regular ? round( 100 - ( $sale / $regular * 100 ), 0 ) . '%' : '';

				if ( $echo == true ) {
					echo ! empty( $saving ) ? '<span class="alice-discount' . $style . '">' . $saving . '</span>' : '';
				} else {
					return ! empty( $saving ) ? '<span class="alice-discount' . $style . '">' . $saving . '</span>' : '';
				}
			}
		}
	}

}
