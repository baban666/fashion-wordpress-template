<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavProductFeatures extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $featuresEnable = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-features-enable');
		$globalFeaturesEnable = $this->getValue('shop-features-enable');
		if(empty( $featuresEnable) && empty($globalFeaturesEnable)){
		    return;
        }
		$features = $this->getValue('shop-features-messages');


		if($featuresEnable){
		    $features = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-features-messages')
			    ? $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-features-messages')
			    : array();
        }

		if (empty($features)){
		   return;
        }

	    ?>
		<?php if(!empty($features)): ?>
           <div class="product-features">
            <?php foreach ($features as $key => $feature): ?>
	            <?php echo '<div class="feature-text">' . $this->getFeature($feature) . '</div>'; ?>
            <?php endforeach; ?>
           </div>
		<?php endif; ?>
        <?php

	}

	public function getFeature($feature){

	    $html = '';
	    if(!empty($feature['feature-icon']['thumbnail'])){
		    $html .= $this->getThumbnail($feature['feature-icon']);
	    }else{
		    $html .=' <i class="las la-check"></i>';
	    }

	    if(!empty($feature['feature-text'])){
		    $html .= wp_kses_post($feature['feature-text']);
	    }

	   return $html;
    }
	public function getThumbnail( $icon ) {
		if ( empty( $icon ) ) {
			return '';
		}
		$image     = ! empty( $icon['thumbnail'] ) ? $icon['thumbnail'] : '';
		$image_alt = ! empty( $icon['alt'] ) ? $icon['alt'] : '';
		if ( empty( $image ) && ! empty( $icon ['url'] ) ) {
			$image = $icon ['url'];
		}
		if ( empty( $image ) ) {
			return '';
		}

		return '<img src=' . esc_url( $image ) . ' alt="' . esc_html( $image_alt ) . '" width="20" height="20" />';
	}
}
