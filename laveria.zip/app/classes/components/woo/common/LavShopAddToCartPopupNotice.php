<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopAddToCartPopupNotice extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		if ( ! empty(  $this->getValue( 'shop-single-add-to-cart-pop-up-enable' ) ) || !empty($this->getValue( 'shop-archive-add-to-cart-pop-up-enable' )) ) {
			add_action( 'wp_footer', array( $this, 'render' ) );
		}
	}

	public function render( $args = null ) {
		if ( !empty(  $this->getValue( 'shop-single-add-to-cart-pop-up-enable' ) ) && is_product() ) {
			$this->renderPopUp();
		}
		if ( !empty($this->getValue( 'shop-archive-add-to-cart-pop-up-enable' )) && is_shop() ) {
			$this->renderPopUp();
		}
	}

	public function renderPopUp() {
		?>
        <div id="alice-add-to-cart-popup-notice" class="alice-add-to-cart-popup-notice">
            <div class="popup-content">
                <h3><?php echo esc_html__('Product added to your cart!', 'laveria')?></h3>
                <p><?php echo esc_html__('Your product ', 'laveria') . '"<span class="product-title-text"></span>"' . esc_html__(' has been successfully added to your cart.', 'laveria'); ?></p>
                <a href="<?php echo wc_get_checkout_url(); ?>" class="lav-btn-default"><?php echo esc_html__('Proceed to Checkout', 'laveria')?></a>
                <a href="<?php echo wc_get_cart_url(); ?>" class="lav-btn-outline"><?php echo esc_html__('View Cart', 'laveria')?></a>
                <button class="close-popup"><?php echo esc_html__('Continue Shopping', 'laveria')?></button>
            </div>
        </div>
		<?php
	}

}


