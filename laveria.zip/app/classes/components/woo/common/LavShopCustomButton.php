<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopCustomButton extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $target = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-button-new-window') ? '_blank' : '_self';
        $buttonText = $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-text' );
		if ( !empty($this->getValue('shop-layout')) && ($this->getValue('shop-layout') == 'type-3'  || $this->getValue('shop-layout') == 'type-4' )  ){
			$buttonText = '<i class="las la-money-check-alt"></i>';
		}
	    ?>
		<?php if($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-text' ) && $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-link' )): ?>
            <a  class="d-block text-center product-custom-button" href="<?php echo esc_url($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-link' )) ?>" target="<?php echo esc_attr($target);?>">
		        <?php echo wp_kses_post($buttonText) ?>
            </a>
		<?php endif; ?>
        <?php

	}

}
