<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopCustomLink extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$linkName = $args == 'two' ? 'shop-product-custom-link' . '-' . 'two' : 'shop-product-custom-link';
		$linkIcon = $args == 'two' ? 'shop-product-custom-link-icon' . '-' . 'two' : 'shop-product-custom-link-icon';

		$link = ! empty( $this->getValue( $linkName ) )
			? $this->getValue( $linkName )
			: null;
		$icon = ! empty( $this->getValue( $linkIcon ) )
			? $this->getValue( $linkIcon )
			: null;

		if ( $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-custom-link-two-enable' ) ) {
			$link = ! empty( $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-custom-link-two' ) )
				? $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-custom-link-two' )
				: null;
			$icon = ! empty( $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-custom-link-icon-two' ) )
				? $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-custom-link-icon-two' )
				: null;
		}

		if ( empty( $link['url'] ) ) {
			return;
		}

		$url = '';
		if ( ! empty( $link ) && ! empty( $link['url'] ) ) {
			$url = $link['url'];
		}
		$target = '_self';
		if ( ! empty( $link ) && ! empty( $link['target'] ) ) {
			$target = $link['target'];
		}
		$buttonText = '';
		if ( ! empty( $link ) && ! empty( $link['text'] ) ) {
			$buttonText = $link['text'];
		}

		?>
		<?php if ( ! empty( $link ) ): ?>
            <a class="lav-btn-outline lav-btn-product-custom-link <?php echo esc_attr( $args ); ?>" href="<?php echo esc_url( $url ); ?>"
               target="<?php echo esc_attr( $target ); ?>">
				<?php if ( $icon ): ?>
					<?php echo $this->getThumbnail( $icon ) ?>
				<?php endif; ?>
				<?php echo wp_kses_post( $buttonText ) ?>
            </a>
		<?php endif; ?>
		<?php

	}

	public function getThumbnail( $icon ) {
		if ( empty( $icon ) ) {
			return '';
		}
		$image     = ! empty( $icon['thumbnail'] ) ? $icon['thumbnail'] : '';
		$image_alt = ! empty( $icon['alt'] ) ? $icon['alt'] : '';
		if ( empty( $image ) && ! empty( $icon ['url'] ) ) {
			$image = $icon ['url'];
		}
		if ( empty( $image ) ) {
			return '';
		}

		return '<img src=' . esc_url( $image ) . ' alt="' . esc_html( $image_alt ) . '" width="20" height="20" />';
	}
}
