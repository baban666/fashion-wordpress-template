<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopDeliveryPopup extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( ! empty(  $this->getValue( 'shop-delivery-popup-enable' ) ) && $this->getValue( 'shop-delivery-popup-enable' ) != 'disable'  ) {
			add_action( 'wp_footer', array( $this, 'renderPopup' ) );
		}
	}

	public function render( $args = null ) {
		$button    = !empty($this->getValue( 'shop-delivery-popup-button' ))
            ? $this->getValue( 'shop-delivery-popup-button' )
            : esc_html__( 'Delivery & Return', 'alice-core' );
		?>
		<?php if ( ! empty(  $this->getValue( 'shop-delivery-popup-enable' ) ) && $this->getValue( 'shop-delivery-popup-enable' ) != 'disable' ) : ?>
            <!-- Button trigger modal -->
            <button type="button" class="btn lav-btn-default" data-bs-toggle="modal"
                    data-bs-target="#staticBackdropDeliveryPopup">
                <i class="las la-truck"></i>
				<?php if ( ! empty(  $button )) : ?>
					<?php echo esc_html( $button ); ?>
				<?php endif; ?>
            </button>
		<?php endif; ?>
		<?php
	}

	public function renderPopup( $args = null ) {
		$elementor = $this->getValue( 'shop-delivery-popup-elementor' );
		$title     = $this->getValue( 'shop-delivery-popup-title' );
		$text      = $this->getValue( 'shop-delivery-popup-text' );
		$type      = $this->getValue( 'shop-delivery-popup-enable' );
		?>
        <!-- Modal -->
        <div class="modal modal-dialog-scrollable fade" id="staticBackdropDeliveryPopup" data-bs-keyboard="false"
             tabindex="-1" aria-labelledby="staticBackdropDeliveryPopupLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
	                    <?php if ( ! empty( $title )) : ?>
                            <h5 class="modal-title" id="staticBackdropDeliveryPopupLabel">
	                            <?php echo esc_html( $title); ?>
                            </h5>
	                    <?php endif; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                        </button>
                    </div>
                    <div class="modal-body">
						<?php if ( ! empty( $elementor ) && $type == 'elementor' ) : ?>
							<?php $this->components->getComponent( 'before-content-elementor' )->render( array( 'id' => $elementor ) ); ?>
						<?php endif; ?>
						<?php if ( ! empty( $text ) && $type == 'text' ) : ?>
							<?php echo do_shortcode( $text ); ?>
						<?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="lav-btn-outline" data-bs-dismiss="modal">
	                        <?php echo esc_html__('Close', 'laveria'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}


