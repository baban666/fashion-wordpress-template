<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopDemoButton extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $target = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-demo-new-window') ? '_blank' : '_self';
	    ?>
		<?php if($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-text' ) && $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-link' )): ?>
            <a  class="demo-button" href="<?php echo esc_url($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-link' )) ?>" target="<?php echo esc_attr($target);?>">
		        <?php echo esc_html($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-text' )) ?>
            </a>
		<?php endif; ?>
        <?php

	}

}
