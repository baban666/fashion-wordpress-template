<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopDemoIcon extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
	    $target = $this->metaBoxes->getProductMeta(get_the_ID(), 'meta-product-demo-new-window') ? '_blank' : '_self';
	    ?>
		<?php if($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-text' ) && $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-link' )): ?>
           <div class="preview">
               <a  class="demo-icon" data-toggle="tooltip" data-placement="top" title="<?php echo esc_attr($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-text' )) ?>" href="<?php echo esc_url($this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-demo-link' )) ?>" target="<?php echo esc_attr($target);?>">
                   <i class="las la-external-link-alt"></i>
               </a>
           </div>
		<?php endif; ?>
        <?php

	}

}
