<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopFakeSales extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$data = get_post_meta( get_the_ID(), 'lav_boost_fake_sales_count', true );

		$isCounterEnabled = $this->getValue('shop-sales-count')
		?>
		<?php if ( ! empty( $data ) && ! empty( $isCounterEnabled )  ) : ?>
            <div class="sales-count">
                <span class="sales-text"><?php echo esc_html__( 'Sales:', 'laveria' ) ?></span>
                <span class="sales-count-number"><?php echo esc_html( $data ) ?></span>
            </div>
		<?php endif; ?>
		<?php

	}

}
