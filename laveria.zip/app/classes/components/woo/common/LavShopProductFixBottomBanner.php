<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopProductFixBottomBanner extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $id = null ) {
		$product = wc_get_product( $id );
		if (!$this->getValue('shop-bottom-sticky-enable')){
		   return;
        }

		$imagePlaceholder = sprintf( '<img src="%s" alt="%s" class="wp-post-image img-fluid" width="50" height="50"/>', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'laveria' ) );
		$html             = '';

		if ( has_post_thumbnail( $id ) ) {
			$post_thumbnail_id  = $product->get_image_id();
			$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
			$html               .= '<img class="img-fluid" src="' . esc_url( $post_thumbnail_url ) . '" width="50" height="50">';
		} else {
			$html .= $imagePlaceholder;
		}

		?>
		<?php if ( $this->getValue('shop-bottom-sticky-enable') ): ?>
            <div class="navbar alice-bottom-mobile-nav navbar-light bg-light">
                <div class="<?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
                    <div class="alice-bottom-row">
                        <div class="row-body d-none d-sm-flex">
	                        <?php echo sprintf( '<div class="product-row-image d-none d-md-block">%s</div>', $html ); ?>
                            <div class="product-details">
                                <h6 class="card-title"><?php echo wp_kses_post( $product->get_name() ); ?></h6>
	                            <p class="price">
		                            <?php echo $product->get_price_html(); ?>
                                </p>
                            </div>
                        </div>
                        <div class="row-button">
	                        <?php $this->renderAddToCart(); ?>
                        </div>
                    </div>
                </div>
            </div>
		<?php endif; ?>
		<?php

	}

	public function renderAddToCart( $args = null ) {
		global $product;
		$buttonType = $product->add_to_cart_text();
		$button = 'text';
		$args['class'] = 'button text-center';
		if ( ! empty( $args['button-type']) && $args['button-type'] === 'type-3' ) {
			$button = 'icon';
		}

		if ( ! empty( $button)  && $button !== 'text') {
			$buttonType = '<i class="las la-shopping-cart"></i>';
		}

		if ( ! empty( $button)  && $button == 'text') {
			$args['class'] .= ' type-text';
		}

		echo apply_filters(
			'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
			sprintf(
				'<a href="%s" data-quantity="%s" class="%s" %s>%s</a>',
				esc_url( $product->add_to_cart_url() ),
				esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
				esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
				isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
				wp_kses_post($buttonType)
			),
			$product,
			$args
		);
		?>
        <span id="woocommerce_loop_add_to_cart_link_describedby_<?php echo esc_attr( $product->get_id() ); ?>" class="screen-reader-text">
	     <?php echo esc_html( $product->add_to_cart_text() ); ?>
        </span>
		<?php
	}

}
