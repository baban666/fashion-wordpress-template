<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopQuickView extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( $this->getValue('shop-quick-view-enable')) {
			add_action( 'wp_footer', array( $this, 'renderDrawer' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'localizeScripts' ) );
			add_action('wp_ajax_load_quick_view', array($this, 'load_quick_view_content'));
			add_action('wp_ajax_nopriv_load_quick_view',  array($this, 'load_quick_view_content'));
		}
	}

	public function render( $id = null ) {

	    ?>
		<?php if ( $this->getValue('shop-quick-view-enable') ): ?>
        <a href="#" class="quick-view-btn" data-product_id="<?php echo esc_attr($id); ?>" data-label="Quick View">
            <i class="lar la-eye"></i>
        </a>
		<?php endif; ?>
		<?php
	}

	public function renderDrawer( $args = null ) {
		?>
		<?php if (true ): ?>
        <!-- Quick View Modal -->
        <div class="offcanvas fade offcanvas-end" tabindex="-1" id="quickViewModal" aria-labelledby="quickViewModalLabel" aria-hidden="true">
            <div class="offcanvas-header">
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body modal-body"></div>
        </div>
		<?php endif; ?>
		<?php
	}

	public function localizeScripts() {
		wp_localize_script( 'main', 'quickViewParams', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'lav-quick-view' ),
			)
		);
	}

	public function load_quick_view_content() {
		if ( empty( $_POST['nonce'] ) || empty( $_POST['product_id'] ) ) {
			wp_die( '0' );
		}
		if ( check_ajax_referer( 'lav-quick-view', 'nonce', false ) ){
			$product_id = absint( wc_clean( $_POST['product_id'] ) );
			$data = $this->getQuickViewDate($product_id);
			wp_send_json( [
				'title'    => esc_html__( 'Quick View Loaded', 'alice-core' ),
				'data' => $data,
			] );
			wp_die();
        }{
			wp_die( esc_html__( 'Access denied', 'alice-core' ), esc_html__( 'Denied', 'alice-core' ), 403 );
		}

	}

	public function getQuickViewDate($id) {
		global $product;
		// Check if the product is password protected
		if (post_password_required($id)) {
			return '<p>'. esc_html__( 'This product is protected. Please enter the password to view the product details.', 'alice-core') . '</p>
                     <a class="lav-btn-default" href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html__( 'Check Product', 'alice-core') . '</a>';
		}
		$product = wc_get_product($id);
		$name          = $product->get_name();
		$description   = $product->get_description();
		$add_to_cart_button = do_shortcode('[add_to_cart id="' . $id . '"]');
		// Retrieve categories
		$category_list = wc_get_product_category_list($id);
        // Retrieve tags
		$tag_list = wc_get_product_tag_list($id);

        // Retrieve SKU
		$sku = $product->get_sku();

		$imagePlaceholder = sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src('woocommerce_single')), esc_html__('Awaiting product image', 'laveria'));
		$attachment_ids = $product->get_gallery_image_ids();
		$html = '<div id="alice-gallery-wrap-a" class="woocommerce-product-gallery__wrapper ">';
		$html .= '<div class="swiper-container quick-view alice-swiper-container">';
		$html .= '<div class="swiper-wrapper">';

		if (has_post_thumbnail($id)) {
			$post_thumbnail_id = $product->get_image_id();
			$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			$image_full_size_url = wp_get_attachment_image_url($post_thumbnail_id, 'full');
			$html .= '<div class="swiper-slide"><a class="popup-image fancybox" data-fancybox="gallery" href="' . esc_url($image_full_size_url) . '"><img src="' . esc_url($post_thumbnail_url) . '"></a></div>';
		} else {
			$html .= '<div class="swiper-slide"><a class="popup-image fancybox" data-fancybox="gallery" href="' . esc_url(wc_placeholder_img_src('woocommerce_single')) . '">' . $imagePlaceholder . '</a></div>';
		}

		foreach ($attachment_ids as $attachment_id) {
			$image_url = wp_get_attachment_url($attachment_id);
			$image_full_size_url = wp_get_attachment_image_url($attachment_id, 'full');
			$html .= '<div class="swiper-slide"><a class="popup-image fancybox" data-fancybox="gallery" href="' . esc_url($image_full_size_url) . '"><img src="' . esc_url($image_url) . '"></a></div>';
		}

		$html .= '</div>'; // Close swiper-wrapper
		$html .= '<div class="swiper-pagination"></div>'; // Add pagination for swiper
		$html .= '</div>'; // Close swiper-container

// Add swiper thumbs below
		$html .= '<div class="swiper-container gallery-thumbs alice-swiper-container"><div class="swiper-wrapper">';

		if (has_post_thumbnail($id)) {
			$post_thumbnail_url = wp_get_attachment_url($product->get_image_id());
			$html .= '<div class="swiper-slide"><img src="' . esc_url($post_thumbnail_url) . '"></div>';
		} else {
			$html .= '<div class="swiper-slide">' . $imagePlaceholder . '</div>';
		}

		foreach ($attachment_ids as $attachment_id) {
			$image_url = wp_get_attachment_url($attachment_id);
			$html .= '<div class="swiper-slide"><img src="' . esc_url($image_url) . '"></div>';
		}

		$html .= '</div></div>'; // Close swiper-container for thumbs

		$html .= '<h5 class="product-title">' . esc_html($name) . '</h5>';
		$html .= '<div>' . $description . '</div>';
		$html .= '<div class="product-meta">';
		$html .= '<strong>SKU:</strong> ' . esc_html($sku) . '<br>';
		$html .= '<strong>Categories:</strong> ' . $category_list . '<br>';
		$html .= '<strong>Tags:</strong> ' . $tag_list;
		$html .= '</div>'; // Close product-meta
		$html .= $add_to_cart_button; // Include the Add to Cart button
		$html .= '</div>'; // Close product-details
		return $html;
	}


}


