<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopReturnPopup extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( $this->getValue( 'shop-return-popup-enable' ) ) {
			add_action( 'wp_footer', array( $this, 'renderPopup' ) );
		}
	}

	public function render( $args = null ) {
		$button    = !empty($this->getValue( 'shop-return-popup-button' ))
            ? $this->getValue( 'shop-return-popup-button' )
            : esc_html__( 'Shipping & Returns', 'alice-core' );
		?>
		<?php if ( ! empty(  $this->getValue( 'shop-return-popup-enable' ) ) && $this->getValue( 'shop-return-popup-enable' ) != 'disable' ) : ?>
            <!-- Button trigger modal -->
            <button type="button" class="btn lav-btn-default" data-bs-toggle="modal"
                    data-bs-target="#staticBackdropReturnPopup">
                <i class="las la-undo-alt"></i>
				<?php if ( ! empty(  $button )) : ?>
					<?php echo esc_html( $button ); ?>
				<?php endif; ?>
            </button>
		<?php endif; ?>
		<?php
	}

	public function renderPopup( $args = null ) {
		$elementor = $this->getValue( 'shop-return-popup-elementor' );
		$title     = $this->getValue( 'shop-return-popup-title' );
		$text      = $this->getValue( 'shop-return-popup-text' );
		$type      = $this->getValue( 'shop-return-popup-enable' );
		?>
        <!-- Modal -->
        <div class="modal modal-dialog-scrollable fade" id="staticBackdropReturnPopup" data-bs-keyboard="false"
             tabindex="-1" aria-labelledby="staticBackdropReturnPopupLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
	                    <?php if ( ! empty( $title )) : ?>
                            <h5 class="modal-title" id="staticBackdropReturnPopupLabel">
	                            <?php echo esc_html( $title); ?>
                            </h5>
	                    <?php endif; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">

                        </button>
                    </div>
                    <div class="modal-body">
						<?php if ( ! empty( $elementor ) && $type == 'elementor' ) : ?>
							<?php $this->components->getComponent( 'before-content-elementor' )->render( array( 'id' => $elementor ) ); ?>
						<?php endif; ?>
						<?php if ( ! empty( $text ) && $type == 'text' ) : ?>
							<?php echo do_shortcode( $text ); ?>
						<?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="lav-btn-outline" data-bs-dismiss="modal">
	                        <?php echo esc_html__('Close', 'laveria'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}


