<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopSearchForm extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		?>
		<?php if ( function_exists( 'get_product_search_form' ) ): ?>
            <form role="search" method="get" class="woocommerce-product-search search-form"
                  action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <label class="screen-reader-text"
                       for="woocommerce-product-search-field"><?php echo esc_html_x( 'Search for:', 'label', 'laveria' ); ?></label>
                <div class="input-group">
                    <input type="search" id="woocommerce-product-search-field"
                           class="field search-field form-control search-field"
                           placeholder="<?php echo esc_attr_x( 'Search products&hellip;', 'placeholder', 'laveria' ); ?>"
                           value="<?php echo get_search_query(); ?>" name="s"/>
                    <button class="wp-block-search__button has-icon" type="submit"
                            value="<?php echo esc_attr_x( 'Search', 'submit button', 'laveria' ); ?>"><i
                                class="las la-search"></i></button>
                    <input type="hidden" name="post_type" value="product"/>
                </div>
            </form>
		<?php endif; ?>
		<?php
	}

}
