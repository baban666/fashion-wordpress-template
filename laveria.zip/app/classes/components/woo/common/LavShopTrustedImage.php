<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopTrustedImage extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$imageEnable = ! empty( $this->getValue( 'shop-product-trusted-enable' ) );

		$icon = ! empty( $this->getValue( 'shop-product-trusted-image' ) )
			? $this->getValue( 'shop-product-trusted-image' )
			: null;

		$image     = ! empty( $icon['thumbnail'] ) ? $icon['thumbnail'] : '';
		$image_alt = ! empty( $icon['alt'] ) ? $icon['alt'] : '';
		$text = ! empty( $this->getValue( 'shop-product-trusted-title' ) )
			? $this->getValue( 'shop-product-trusted-title' )
			: null;
		$width = 250;
		$height = 50;
		$dem = ! empty( $this->getValue( 'shop-product-trusted-image-w' ) )
			? $this->getValue( 'shop-product-trusted-image-w' )
			: null;
		if ( empty( $image ) && ! empty( $icon ['url'] ) ) {
			$image = $icon ['url'];
		}

		if ( !empty( $dem['width'] ) && !empty( $dem['height'] ) ) {
			$width = $dem['width'];
			$height = $dem['height'];
		}

		if ( empty( $image ) ) {
			return '';
		}

		?>
		<?php if ( ! empty( $imageEnable ) ): ?>
			<?php echo '<img src=' . esc_url( $image ) . ' alt="' . esc_html( $image_alt ) . '" width="' . esc_attr($width) . '" height="'. esc_attr($height) . '" />'; ?>
			<?php if ( !empty($text) ): ?>
                <div class="trusted-title"><?php echo wp_kses_post( $text ) ?></div>
			<?php endif; ?>
        <?php endif; ?>
		<?php

	}

}
