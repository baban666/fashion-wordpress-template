<?php


namespace classes\components\woo\common;


use classes\abstracts\LavBaseComponent;


class LavShopVideoIcon extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$isVideo     = $this->getValue( 'shop-video-enable' );
		$iframeVideo = $this->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-youtube-pop' );
		if (empty(	$isVideo ) || empty($iframeVideo )){
			return;
		}
		if ( !empty(	$isVideo ) && !empty($iframeVideo ) ) {
			echo   '<a class="product-video-popup fancybox" data-fancybox href="http://www.youtube.com/watch?v=' . $iframeVideo . '"><i class="lar la-play-circle"></i></a>';
		}
	}

}
