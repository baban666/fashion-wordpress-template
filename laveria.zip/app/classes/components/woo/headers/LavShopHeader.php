<?php


namespace classes\components\woo\headers;


use classes\abstracts\LavBaseComponent;


class LavShopHeader extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {

	    $bannerDetails = $this->helper->getBannerDetails( $this->getValue('shop-hero-header-background') );


        $bgColor = $bannerDetails['bg-color'];
        $gradientColor = $bannerDetails['gradient-color'];
        $imageUrl =  $bannerDetails['image-url'];
        $imageAlt =  $bannerDetails['image-alt'];
		$direction     = $bannerDetails['direction'];
		?>
        <header class="lav-hero page-header woocommerce-products-header" <?php echo sprintf( 'style="background: linear-gradient(155deg, %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>>
            <div class="hero-text container">
	            <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
                    <h1 class="woocommerce-products-header__title text-start page-title"><?php woocommerce_page_title(); ?></h1>
	            <?php endif; ?>

                <?php
				if($this->getValue('global-loop-show-description')){
					/**
					 * Hook: woocommerce_archive_description.
					 *
					 * @hooked woocommerce_taxonomy_archive_description - 10
					 * @hooked woocommerce_product_archive_description - 10
					 */
					do_action( 'woocommerce_archive_description' );
                }
				?>
                <div class="d-flex justify-content-start align-items-center">
		            <?php $this->components->getComponent( 'breadcrumbs' )->render( array( 'blog' => esc_html__('Blog', 'laveria') , 'home' => esc_html__('Home', 'laveria') ) ); ?>
                </div>
            </div>
	        <?php if ( ! empty( $imageUrl ) ): ?>
                <img src="<?php echo esc_url( $imageUrl ) ?>" class="lav-hero-image" alt="<?php echo esc_attr($imageAlt)?>">
                <div class="overlay" <?php echo sprintf( 'style="background: linear-gradient('.esc_attr( $direction ).', %1$s %2$s, %3$s %4$s);"', esc_attr($bgColor), '50%', esc_attr($gradientColor), '100%' ); ?>></div>
	        <?php endif; ?>
        </header>
		<?php

	}

}
