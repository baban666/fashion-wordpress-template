<?php


namespace classes\components\woo\loop;


use classes\abstracts\LavBaseComponent;

class LavAddToCart extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		global $product;
		$buttonType = $product->add_to_cart_text();
		$button = !empty($this->getValue('shop-cart-button-style'))
			? $this->getValue('shop-cart-button-style')
			: 'text';

		if ( ! empty( $args['button-type']) && $args['button-type'] === 'type-3' ) {
			$button = 'icon';
		}

		if ( ! empty( $button)  && $button !== 'text') {
			$buttonType = '<i class="las la-shopping-cart"></i>';
		}

		if ( ! empty( $button)  && $button == 'text') {
			$args['class'] .= ' type-text';
		}

		if ( ! empty( wc_get_cart_url())) {
			$args['cart-url'] = wc_get_cart_url();
		}


		echo apply_filters(
			'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
			sprintf(
				'<a href="%s"  data-quantity="%s" class="%s" data-cart-url="%s" data-cart-text="%s" %s>%s</a>',
				esc_url( $product->add_to_cart_url() ),
				esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
				esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
				esc_attr( isset( $args['cart-url'] ) ? $args['cart-url'] : '/cart' ),
				esc_attr( esc_html__('View Cart', 'laveria') ),
				isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
				wp_kses_post($buttonType)
			),
			$product,
			$args
		);
		 ?>
		<span id="woocommerce_loop_add_to_cart_link_describedby_<?php echo esc_attr( $product->get_id() ); ?>" class="screen-reader-text">
	     <?php echo esc_html( $product->add_to_cart_text() ); ?>
        </span>
		<?php
	}
}
