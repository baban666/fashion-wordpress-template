<?php


namespace classes\components\woo\loop;


use classes\abstracts\LavBaseComponent;

class LavBeforeContentElementor extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = array('id'=>null, 'css'=>false) ) {
		$css  = !empty($args['css']) ? $args['css'] : false;
		$tempId = !empty($args['id']) ? $args['id'] : null;


		if ( class_exists( '\Elementor\Frontend' ) && !empty($tempId ) ) {
			$frontend = new \Elementor\Frontend;
			echo $frontend->get_builder_content_for_display( $tempId, $css );
		}
	}
}
