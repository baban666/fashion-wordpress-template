<?php


namespace classes\components\woo\loop;


use classes\abstracts\LavBaseComponent;

class LavRatingCount extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}


	public function render( $args = array('type'=>1,'rating'=>0,'count'=>0,'review'=>0) ) {
		$type = !empty($args['type']) ? $args['type'] : 1;
		$rating = !empty($args['rating']) ? $args['rating'] : 0;
		$count = !empty($args['count']) ? $args['count'] : 0;
		$review = !empty($args['review']) ? $args['review'] : 0;


		if ( 0 < $count ) {
			if ( $type == 1 ) {
				echo '<span class="star-rating"><span class="rating" style="width:'.(($rating / 5 ) * 100).'%">'.esc_html( $count ).'</span></span>';
			} else {
				$review = $review >= 1000 ? ($review/1000).'k' : $review;
				echo '<span class="rating-review"><span class="rating">'.esc_html( $rating ).'</span><i class="lar la-star"></i><span class="review">'.esc_html( $review ).'</span></span>';
			}
		}
	}
}
