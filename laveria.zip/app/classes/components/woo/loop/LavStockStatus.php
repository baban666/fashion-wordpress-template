<?php


namespace classes\components\woo\loop;


use classes\abstracts\LavBaseComponent;

class LavStockStatus extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}


	public function render( $args = array('status'=>null,'stock'=>null,'show_stock'=>true) ) {
		$globalStockEnable = $this->getValue('shop-stock-enable');
		if(empty( $globalStockEnable)){
			return;
		}
		global $product;

		$status = !empty($args['status']) ? $args['status'] : $product->get_stock_status();
		$stock  = !empty($args['stock']) ? $args['stock'] : $product->get_stock_quantity();
		$show  =  !empty($args['show_stock']) ? 'show' : 'hide';

		$text = $status == 'instock' ? esc_html__('In stock', 'laveria') : esc_html__('Out of stock', 'laveria');

		if ( $show != 'hide' && $stock > 0 ) {
			$text .= $stock > 0 ? ':<span class="stock-value"> '.wc_trim_zeros($stock).'</span>' : '';
		}

		echo '<span class="alice-stock-status '. esc_attr($status) .'">'. $text .'</span>';
	}
}
