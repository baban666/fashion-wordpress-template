<?php


namespace classes\components\woo\mini;


use classes\abstracts\LavBaseComponent;


class LavShopMiniCart extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
	}

	public function render( $args = null ) {
		$cart = $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-cart' );
		$type = ! empty( $this->getValue( 'shop-mini-cart-type' ) )
			? $this->getValue( 'shop-mini-cart-type' )
			: 'mini-cart-default';
		?>
		<?php if ( function_exists( 'wc_get_cart_url' ) && ! $cart ): ?>
			<?php $this->components->getComponent( $type )->render(); ?>
		<?php endif; ?>

		<?php

	}

}
