<?php


namespace classes\components\woo\mini;


use classes\abstracts\LavBaseComponent;


class LavShopMiniCartDefault extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );
		if ( $this->getValue( 'shop-mini-cart-type' ) == 'mini-cart-default' ) {
			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'updateFragment' ) );
		}
	}

	public function render( $args = null ) {
		?>
        <a href="<?php echo wc_get_cart_url() ?>" class="curie-mini-cart">
            <i class="las la-shopping-bag"></i>
            <span class="curie-mini-cart-count">
                <?php echo WC()->cart->get_cart_contents_count() ?>
            </span>
        </a>
		<?php

	}

	public function updateFragment( $fragments ) {

		$fragments['.curie-mini-cart'] = '<a href="' . esc_url( wc_get_cart_url() ) . '" class="curie-mini-cart"> <i class="las la-shopping-bag"></i> <span  class="curie-mini-cart-count">' . WC()->cart->get_cart_contents_count() . '</span></a>';

		return $fragments;

	}
}
