<?php


namespace classes\components\woo\mini;


use classes\abstracts\LavBaseComponent;


class LavShopMiniCartDrawer extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( $this->getValue( 'shop-mini-cart-type' ) == 'mini-cart-drawer') {
			// Here is the AJAX call
			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'updateFragment' ) );
			add_action( 'wp_footer', array( $this, 'renderDrawer' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'localizeScripts' ) );
			add_action( 'wp_ajax_lav_qty_update', array( $this, 'lavQtyUpdate' ) );
			add_action( 'wp_ajax_nopriv_lav_qty_update', array( $this, 'lavQtyUpdate' ) );
		}
	}

	public function render( $args = null ) {
		?>
		<?php if ( function_exists( 'woocommerce_mini_cart' ) ): ?>
            <a href="<?php echo wc_get_cart_url() ?>" class="curie-mini-cart" data-bs-toggle="offcanvas"
               data-bs-target="#offcanvasRightDrawer" aria-controls="offcanvasRight">
                <i class="las la-shopping-bag"></i>
                <span class="curie-mini-cart-count">
                <?php echo WC()->cart->get_cart_contents_count() ?>
                </span>
            </a>
		<?php endif; ?>
		<?php
	}

	public function renderDrawer( $args = null ) {
		?>
		<?php if ( function_exists( 'woocommerce_mini_cart' ) ): ?>
            <div class="offcanvas offcanvas-end ic-cart-sidebar-wrapper" tabindex="-1" id="offcanvasRightDrawer"
                 aria-labelledby="offcanvasRightLabel">
                <div class="offcanvas-header">
                    <h5 id="offcanvasRightLabel"><?php _e( 'Your Cart', 'laveria' ); ?></h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close">
                        <i class="las la-times"></i>
                    </button>
                </div>
                <div class="offcanvas-body">
                    <div class="widget_shopping_cart_content">
		                <?php woocommerce_mini_cart( [ 'list_class' => 'alice-mini-cart-drawer' ] ); ?>
                    </div>
                </div>
            </div>
		<?php endif; ?>
		<?php
	}

	public function updateFragment( $fragments ) {
		$fragments['.curie-mini-cart'] = '<a href="' . esc_url( wc_get_cart_url() ) . '" class="curie-mini-cart"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasRightDrawer" aria-controls="offcanvasRight"> <i class="las la-shopping-bag"></i> <span  class="curie-mini-cart-count">' . WC()->cart->get_cart_contents_count() . '</span></a>';

		return $fragments;
	}

	public function localizeScripts() {
		wp_localize_script( 'main', 'lav_mini_cart_drawer', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'lav-mini-cart-nc' ),
			)
		);
	}

	public function lavQtyUpdate() {
		if ( empty( $_POST['security'] ) || ! wp_verify_nonce( $_POST['security'], 'lav-mini-cart-nc' ) ) {
			wp_die( '0' );
		}

		$key    = sanitize_text_field( $_POST['key'] );
		$number = intval( sanitize_text_field( $_POST['number'] ) );

		$cart = [
			'count'      => 0,
			'total'      => 0,
			'item_price' => 0,
		];

		if ( $key && $number > 0 ) {
			WC()->cart->set_quantity( $key, $number );
			$items              = WC()->cart->get_cart();
			$cart               = [];
			$cart['count']      = WC()->cart->cart_contents_count;
			$cart['total']      = WC()->cart->get_cart_total();
			$cart['item_price'] = wc_price( $items[ $key ]['line_total'] );
		}
		echo json_encode( $cart );
		wp_die();
	}
}


