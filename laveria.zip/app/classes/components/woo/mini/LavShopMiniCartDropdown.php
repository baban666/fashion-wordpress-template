<?php


namespace classes\components\woo\mini;


use classes\abstracts\LavBaseComponent;


class LavShopMiniCartDropdown extends LavBaseComponent {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaBoxesProvider );

		if ( $this->getValue( 'shop-mini-cart-type' ) == 'mini-cart-dropdown' ) {
			add_filter( 'woocommerce_add_to_cart_fragments', array( $this, 'updateFragment' ) );
		}
	}

	public function render( $args = null ) {
		if ( null === WC()->cart ) {
			return;
		}
		$widget_cart_is_hidden = apply_filters( 'woocommerce_widget_cart_is_hidden', false );
		$product_count         = WC()->cart->get_cart_contents_count();
		$sub_total             = WC()->cart->get_cart_subtotal();
		$cart_items = WC()->cart->get_cart();
		?>
        <div class="wc-toggle-button-wrapper">
		<?php if ( ! $widget_cart_is_hidden ): ?>
            <div class="wc-menu-cart__container">
                <div class="wc-menu-cart__main">
                    <div class="widget_shopping_cart_content-custom">
                    <?php if ( empty( $cart_items ) ): ?>
                        <div class="woocommerce-mini-cart__empty-message"> <?php esc_html_e( 'No products in the cart.', 'laveria' ); ?> </div>
				    <?php else: ?>
                        <div class="wc-menu-cart__products woocommerce-mini-cart cart woocommerce-cart-form__contents">
	                        <?php
	                        do_action( 'woocommerce_before_mini_cart_contents' );
	                        foreach ( $cart_items as $cart_item_key => $cart_item ) {
		                        echo $this->getCartItems( $cart_item_key, $cart_item );
	                        }
	                        do_action( 'woocommerce_mini_cart_contents' );
                            ?>
                        </div>
                        <div class="woocommerce-mini-cart__total total">
                            <strong><?php esc_html_e( 'Subtotal:', 'laveria' ); ?></strong>
		                    <?php echo WC()->cart->get_cart_subtotal() ; ?>
                        </div>
                        <div class="wc-menu-cart__footer-buttons  woocommerce-mini-cart__buttons buttons">
                            <a href="<?php echo esc_url( wc_get_cart_url() );?>" class="button lav-btn-outline wc-forward">
			                    <?php esc_html_e( 'View cart', 'laveria' ); ?>
                            </a>
                            <a href="<?php echo esc_url( wc_get_checkout_url() );?>" class="button checkout wc-forward">
			                    <?php esc_html_e( 'Checkout', 'laveria' ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <a class="wc-menu-cart__toggle-button" href="<?php echo esc_url( wc_get_cart_url() );?>">
            <span class="item-count cart-button-icon" data-counter=<?php echo esc_attr($product_count); ?>>
            <i class="las la-shopping-bag"></i>
            </span>
            </a>
		<?php endif; ?>
        </div>
		<?php

	}

	public function updateFragment( $fragments ) {
		ob_start();
		$this->render();
		$fragments['div.wc-toggle-button-wrapper'] = ob_get_clean();
		return $fragments;
	}



	public function getCartItems( $cart_item_key, $cart_item ) {
		$_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
		$is_product_visible = ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) );

		if ( ! $is_product_visible ) {
			return;
		}

		$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
		$product_price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
		$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );

		$class = '';

		//remove_action('woocommerce_after_cart_item_name', 20, 1);

		$cart_items_output = '';

		$cart_items_output =
			'<div class="wc-menu-cart__product woocommerce-cart-form__cart-item '. esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ) .'">
 
        <div class="wc-menu-cart__product-image product-thumbnail">';

		$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

		if ( ! $product_permalink ) :
			$cart_items_output .=  wp_kses_post( $thumbnail );
		else :
			$cart_items_output .= sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), wp_kses_post( $thumbnail ) );
		endif;

		$cart_items_output .= '</div><div class="wc-menu-cart__product-name-wrapper">
        <div class="wc-menu-cart__product-name product-name" data-title="'. esc_attr__( 'Product', 'woocommerce' ).' ">';

		if ( ! $product_permalink ) :
			$cart_items_output .= wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );
		else :
			$cart_items_output .= wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() ), $cart_item, $cart_item_key ) );
		endif;

		$cart_items_output .= do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

		// Meta data.
		$cart_items_output .= wc_get_formatted_cart_item_data( $cart_item );
		$cart_items_output .= '</div>';

		$cart_items_output .= '<div class="wc-menu-cart__product-price product-price" data-title="'. esc_attr__( 'Price', 'woocommerce' ) .'">';
		$cart_items_output .= apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="quantity">' . sprintf( '<span class="product-quantity">%s &times;</span> %s', $cart_item['quantity'], $product_price ) . '</span>', $cart_item, $cart_item_key );
		$cart_items_output .= '</div>';
		$cart_items_output .= '</div>';

		$cart_items_output .= '<div class="wc-menu-cart__product-remove product-remove">';
		$cart_items_output .= apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
			'<a href="%s" class="%s" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">
       					x
					</a>',
			esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
			'remove remove_from_cart_button',
			__( 'Remove this item', 'woocommerce' ),
			esc_attr( $product_id ),
			esc_attr( $cart_item_key ),
			esc_attr( $_product->get_sku() )
		), $cart_item_key );

		$cart_items_output .= '</div>
    </div>';

		return $cart_items_output;
	}
}

