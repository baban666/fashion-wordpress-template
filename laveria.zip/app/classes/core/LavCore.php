<?php


namespace classes\core;


use classes\providers\LavComponentsProvider;
use classes\providers\LavHelpersProvider;
use classes\providers\LavLayoutsProvider;
use classes\providers\LavMetaBoxesProvider;
use classes\providers\LavSettingsProvider;
use classes\providers\LavWooSupportProvider;
use traits\TLavSingleton;

class LavCore {
	use TLavSingleton;

	public function run(){
		LavSetupTheme::getInstance();
		LavWidgetsInit::getInstance();
		LavEnqueue::getInstance();
		LavRequire::getInstance();
		LavHooksAndFilters::getInstance();

		$lavSettings = new LavSettingsProvider();
		$lavMeta = new LavMetaBoxesProvider();
		$lavHelper = new LavHelpersProvider();

		$lavComponents = LavComponentsProvider::getInstance();
		$lavComponents->setSettings($lavSettings);
		$lavComponents->setHelper($lavHelper);
		$lavComponents->setMetaBoxes($lavMeta);
		$lavComponents->run();


		$lavLayouts = LavLayoutsProvider::getInstance();
		$lavLayouts->setSettings($lavSettings);
		$lavLayouts->setHelper($lavHelper);
		$lavLayouts->setMetaBoxes($lavMeta);
		$lavLayouts->setComponents($lavComponents);
		$lavLayouts->run();

		$lavWooSupport = LavWooSupportProvider::getInstance();
		$lavWooSupport->setSettings($lavSettings);
		$lavWooSupport->setHelper($lavHelper);
		$lavWooSupport->setMetaBoxes($lavMeta);
		$lavWooSupport->setComponents($lavComponents);
		$lavWooSupport->run();

	}

}
