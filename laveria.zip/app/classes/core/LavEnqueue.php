<?php


namespace classes\core;


use traits\TLavSingleton;

class LavEnqueue {
	use TLavSingleton;

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array($this, 'run') );
	}

	/**
	 * Enqueue scripts and styles.
	 */
	function run() {
		wp_enqueue_style( 'awesome', get_template_directory_uri() . '/css/all.min.css', array(), '5.15.4', 'all' );
		wp_enqueue_style( 'line-awesome', get_template_directory_uri() . '/css/line-awesome.min.css', array(), '5.15.4', 'all' );
		wp_enqueue_style( 'lav-style', get_stylesheet_uri(), array('awesome'), LAV_VERSION );
		wp_style_add_data( 'lav-style', 'rtl', 'replace' );

		wp_enqueue_script( 'lav-navigation', get_template_directory_uri() . '/js/navigation.js', array(), LAV_VERSION, true );
		wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.bundle.min.js', array(), '5.1.3', true );
		wp_enqueue_script( 'sticky-scroll', get_template_directory_uri() . '/js/sticky.min.js', array(), '1.3.0', true );

		wp_enqueue_script( 'main', get_template_directory_uri() . '/js/main.js', array('jquery','bootstrap'), LAV_VERSION, true );

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}


}
