<?php


namespace classes\core;


use traits\TLavSingleton;

class LavHooksAndFilters {
	use TLavSingleton;

	public function __construct() {
		add_filter( 'wp_list_categories', array($this, 'addCatCountSpan') );
		add_filter( 'get_archives_link', array($this, 'addArchiveCountSpan')  );
		add_filter( 'comment_form_defaults', array($this, 'textareaPlaceholder') );
		add_filter( 'comment_form_default_fields', array($this, 'formFieldsPlaceholder') );
		add_filter( 'get_the_archive_title', array($this, 'changeArchiveTitle') );
		add_filter( 'wp_footer', array($this, 'addIconsStyles') );
		add_filter( 'upload_mimes', array($this, 'enableSVG') );
		add_filter( 'get_demo_import_config', array($this, 'availableDemos'), 20 );
	}

	function enableSVG($mimes) {
		$mimes['svg'] = 'image/svg+xml';
		return $mimes;
	}

	function availableDemos( $args ) {
		return array();
	}

	function addIconsStyles() {

		$settings = get_option( 'alice-core' );

		if(empty($settings)){
			return;
		}

		if(empty($settings['icons-list']['url']) && empty($settings['icons-calendar']['url']) && empty($settings['icons-comment']['url']) && empty($settings['font-body']['font-family']) && empty($settings['font-headings']['font-family']) ){
			return;
		}

		// Icons
		$style = '';
		$style .= !empty($settings['icons-list']['url']) ? '--list-icon: url('. esc_url($settings['icons-list']['url'])  .'); '  : ' ' ;
		$style .= !empty($settings['icons-calendar']['url']) ? '--calendar-icon: url('. esc_url($settings['icons-calendar']['url'] ) .'); '  : ' ' ;
		$style .= !empty($settings['icons-comment']['url']) ? '--reply-icon: url('. esc_url($settings['icons-comment']['url'])  .'); '  : ' ' ;

		// Fonts
		$style .= !empty($settings['font-body']['font-family']) ? '--font__main: "'. esc_attr($settings['font-body']['font-family'])  .'"; '  : ' ' ;
		$style .= !empty($settings['font-headings']['font-family']) ? '--font__headings: "'. esc_attr($settings['font-headings']['font-family'])  .'"; '  : ' ' ;

		echo '<style type="text/css">body {' . $style  . ' }</style>';
	}

	public function addCatCountSpan( $links ) {
		$links = str_replace( '</a> (', '</a><span class="post-count"><span class="bracket-open">(</span>', $links );
		$links = str_replace( ')', '<span class="bracket-close">)</span></span>', $links );
		return $links;
	}

	public function addArchiveCountSpan( $links ) {
		$links = str_replace( '</a>&nbsp;(', '</a><span class="post-count">', $links );
		$links = str_replace( ')', '</span>', $links );
		$links = str_replace( '</option>', ')</option>', $links );
		return $links;
	}

	public function textareaPlaceholder( $args ) {
		$args['comment_field']        = str_replace( 'textarea', 'textarea placeholder="Comment*"', $args['comment_field'] );
		return $args;
	}

	public function formFieldsPlaceholder( $fields ) {
		foreach( $fields as &$field ) {
			$field = str_replace( 'id="author"', 'id="author" placeholder="Name*"', $field );
			$field = str_replace( 'id="email"', 'id="email" placeholder="Email*"', $field );
			$field = str_replace( 'id="url"', 'id="url" placeholder="Website"', $field );
		}
		return $fields;
	}

	public function changeArchiveTitle($title) {
		if ( is_home() ) {
			$title = esc_html__('Blog', 'laveria');
		}
		return $title;
	}
}
