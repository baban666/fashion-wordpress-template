<?php


namespace classes\core;


use traits\TLavSingleton;

class LavRequire {
	use TLavSingleton;

	public function __construct() {
		$this->run();
	}

	public function run() {

		/**
		 * Implement the Custom Header feature.
		 */
		require get_template_directory() . '/inc/custom-header.php';

		/**
		 * Custom template tags for this theme.
		 */
		require get_template_directory() . '/inc/template-tags.php';

		/**
		 * Functions which enhance the theme by hooking into WordPress.
		 */
		require get_template_directory() . '/inc/template-functions.php';

		/**
		 * Customizer additions.
		 */
		require get_template_directory() . '/inc/customizer.php';

		/**
		 * Load WooCommerce compatibility file.
		 */
		if ( class_exists( 'WooCommerce' ) ) {
			require get_template_directory() . '/inc/woocommerce.php';
		}

		/**
		 * TGM.
		 */
		require get_template_directory() . '/libs/tgm/activation.php';

	}

}
