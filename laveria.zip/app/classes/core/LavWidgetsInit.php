<?php


namespace classes\core;


use traits\TLavSingleton;

class LavWidgetsInit {
	use TLavSingleton;

	public function __construct() {
		add_action( 'widgets_init', array($this, 'run') );
	}

	public function run() {
		/**
		 * Register widget area.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
		 */

		register_sidebar(
			array(
				'name'          => esc_html__( 'Sidebar', 'laveria' ),
				'id'            => 'sidebar-1',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Shop Sidebar', 'laveria' ),
				'id'            => 'lav-woo-1',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Burger Sidebar', 'laveria' ),
				'id'            => 'lav-burger-1',
				'description'   => esc_html__( 'Add widgets here.', 'laveria' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}

}
