<?php


namespace classes\layouts;


class LavBoxedLayout extends LavTopMenuLayout {


	public function __construct( $name, $settingsProvider, $helpersProvider, $metaboxesProvider, $componentsProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaboxesProvider, $componentsProvider );
	}

	public function renderHeader() {
		$this->renderBodyHead();
		?>
    <body <?php body_class( array($this->getValue('general-layout'), $this->getValue('general-style')) ); ?>>
		<?php wp_body_open(); ?>
    <div id="page" class="site <?php echo esc_attr( $this->helper->getContainer( $this->settings ) ); ?>">
        <a class="skip-link screen-reader-text"
           href="#primary"><?php esc_html_e( 'Skip to content', 'laveria' ); ?></a>
        <header id="masthead" class="site-header">
			<?php
			if ( $this->helper->hasTopLine( $this->settings ) ) {
				$this->components->getComponent( 'top-line' )->render();
			}
			$this->components->getComponent( 'nav' )->render( $this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu' ) );
			?>
        </header><!-- #masthead -->
		<?php
	}


}
