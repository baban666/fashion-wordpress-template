<?php


namespace classes\layouts;


class LavTwoRowsMenuLayout extends LavTopMenuLayout {

	public function __construct( $name, $settingsProvider, $helpersProvider, $metaboxesProvider, $componentsProvider ) {
		parent::__construct( $name, $settingsProvider, $helpersProvider, $metaboxesProvider, $componentsProvider );
	}

	public function renderHeader() {
		$this->renderBodyHead();


		?>
    <body <?php body_class(array($this->getValue('general-layout'), $this->getValue('general-style'))); ?>>
		<?php wp_body_open(); ?>
    <div id="page" class="site">
        <a class="skip-link screen-reader-text" href="#primary">
            <?php esc_html_e( 'Skip to content', 'laveria' ); ?>
        </a>
        <header id="masthead" class="site-header">
			<?php
			if($this->settings['global-loader']){
				$this->components->getComponent('spinner')->render();
			}
			if($this->helper->hasTopLine($this->settings)){
				$this->components->getComponent('top-line')->render();
			}
			$this->components->getComponent('two-rows-nav')->render($this->metaBoxes->getPageMeta( get_the_ID(), 'meta-page-menu' ));
			?>
        </header><!-- #masthead -->
		<?php
	}
}
