<?php


namespace classes\providers;


use classes\abstracts\LavBaseComponent;
use classes\components\author\LavArchiveAuthorInfo;
use classes\components\author\LavSingleAuthorInfo;
use classes\components\archives\LavArchive;
use classes\components\archives\LavIndex;
use classes\components\banners\LavNavHeroBanner;
use classes\components\breadcrumbs\LavBreadcrumbs;
use classes\components\burger\LavBurger;
use classes\components\burger\LavBurgerSidebar;
use classes\components\common\LavAdBanner;
use classes\components\common\LavAuthorAvatar;
use classes\components\common\LavAuthorRating;
use classes\components\common\LavAuthorSectionAvatar;
use classes\components\common\LavBookMeta;
use classes\components\common\LavContentNone;
use classes\components\common\LavIrRating;
use classes\components\common\LavPostNav;
use classes\components\common\LavProsCons;
use classes\components\common\LavReviewStars;
use classes\components\common\LavShareButtons;
use classes\components\common\LavUserAvatar;
use classes\components\footers\LavFooter;
use classes\components\footers\LavFooterCopyright;
use classes\components\footers\LavFooterTopLine;
use classes\components\footers\LavScrollTop;
use classes\components\headers\Lav404Header;
use classes\components\headers\LavIndexHeader;
use classes\components\headers\LavPageHeader;
use classes\components\headers\LavSearchHeader;
use classes\components\headers\LavSidebarMenuHeader;
use classes\components\headers\LavSingleDefaultHeader;
use classes\components\headers\LavSingleReadingHeader;
use classes\components\headers\LavSingleReviewHeader;
use classes\components\headers\LavSingleServiceHeader;
use classes\components\headers\LavSingleSimpleHeader;
use classes\components\logo\LavLogo;
use classes\components\loops\LavLoopCards;
use classes\components\navigations\custom\LavCustomAccountLink;
use classes\components\navigations\custom\LavCustomBottomLine;
use classes\components\navigations\custom\LavCustomCompareIcon;
use classes\components\navigations\custom\LavCustomHomeIcon;
use classes\components\navigations\custom\LavCustomMainNavigation;
use classes\components\navigations\custom\LavCustomMiddleLine;
use classes\components\navigations\custom\LavCustomMobileLine;
use classes\components\navigations\custom\LavCustomMobileNavigation;
use classes\components\navigations\custom\LavCustomMobileToggle;
use classes\components\navigations\custom\LavCustomNavMobile;
use classes\components\navigations\custom\LavCustomNotices;
use classes\components\navigations\custom\LavCustomProductCategories;
use classes\components\navigations\custom\LavCustomPromoBar;
use classes\components\navigations\custom\LavCustomPromoMessage;
use classes\components\navigations\custom\LavCustomStickyLine;
use classes\components\navigations\custom\LavCustomTopLine;
use classes\components\navigations\custom\LavCustomWishlistIcon;
use classes\components\navigations\LavBookMenuNav;
use classes\components\navigations\LavCustomNav;
use classes\components\navigations\LavNav;
use classes\components\navigations\LavNavMobile;
use classes\components\navigations\LavSidebarMenuNav;
use classes\components\navigations\LavTwoRowsNav;
use classes\components\pages\Lav404Page;
use classes\components\pages\LavSearchPage;
use classes\components\related\LavRelatedPosts;
use classes\components\searches\LavHeaderSearch;
use classes\components\sidebars\LavFooterSidebar;
use classes\components\singles\LavElementorTemplate;
use classes\components\singles\LavSingleDonation;
use classes\components\singles\LavSingleRating;
use classes\components\singles\LavSingleReading;
use classes\components\singles\LavSingleReview;
use classes\components\singles\LavSingleService;
use classes\components\singles\LavSingleSimple;
use classes\components\social\LavSocialIcons;
use classes\components\action\LavActionButton;
use classes\components\top\LavTopLine;
use classes\components\pages\LavPage;
use classes\components\searches\LavSearchForm;
use classes\components\singles\LavSingleDefault;
use classes\components\spinner\LavSpinner;
use classes\components\paginations\LavPagination;
use classes\components\top\LavTopLineAddress;
use classes\components\top\LavTopLineEAddress;
use classes\components\top\LavTopLineMenu;
use classes\components\top\LavTopLinePhone;
use classes\components\woo\common\LavProductCountDown;
use classes\components\woo\common\LavProductCustomGallery;
use classes\components\woo\common\LavProductDiscount;
use classes\components\woo\common\LavProductFeatures;
use classes\components\woo\common\LavShopAddToCartPopupNotice;
use classes\components\woo\common\LavShopCustomButton;
use classes\components\woo\common\LavShopCustomLink;
use classes\components\woo\common\LavShopDeliveryPopup;
use classes\components\woo\common\LavShopDemoButton;
use classes\components\woo\common\LavShopDemoIcon;
use classes\components\woo\common\LavShopFakeSales;
use classes\components\woo\common\LavShopProductFixBottomBanner;
use classes\components\woo\common\LavShopQuickView;
use classes\components\woo\common\LavShopReturnPopup;
use classes\components\woo\common\LavShopSearchForm;
use classes\components\woo\common\LavShopSizesPopup;
use classes\components\woo\common\LavShopTrustedImage;
use classes\components\woo\common\LavShopVideoIcon;
use classes\components\woo\headers\LavShopHeader;
use classes\components\woo\loop\LavAddToCart;
use classes\components\woo\loop\LavBeforeContentElementor;
use classes\components\woo\loop\LavRatingCount;
use classes\components\woo\loop\LavStockStatus;
use classes\components\woo\mini\LavShopMiniCart;
use classes\components\woo\mini\LavShopMiniCartDefault;
use classes\components\woo\mini\LavShopMiniCartDrawer;
use classes\components\woo\mini\LavShopMiniCartDropdown;
use traits\TLavSingleton;

class LavComponentsProvider {
	use TLavSingleton;

	public $settings = null;
	public $helper = null;
	public $metaBoxes = null;
	public $_components = null;

	public function addComponent( LavBaseComponent $component ) {
		$this->_components[ $component->getName() ] = $component;
	}

	public function getTypeComponent( $args ) {
		switch ( $args ) {
			case 'tag':
			case 'category':
			case 'date':
			case 'author':
			case 'archive':
				return 'archive';
				break;
			case 'page':
				return 'page';
				break;
			case 'single':
				return $this->getSingleLayout( get_the_ID() );
				break;
			default:
				return 'index';
		}
	}

	public function getComponent( $args ) {
		if ( is_array( $args ) ) {
			return $this->_components[ $this->getTypeComponent( $args[0] ) ];
		} else {
			return $this->_components[ $args ];
		}
	}

	public function getValue($key) {
		$globalSettings = $this->getSettings()->getSettings();
		return !empty($globalSettings[$key]) ? $globalSettings[$key] : null;
	}

	public function getSingleLayout( $id ) {
		$globalSettings = $this->getSettings()->getSettings();
		$singleLayout = $this->metaBoxes->getPostMeta( $id, 'meta-single-layout' );
		if(get_post_type($id) === 'elementor_library' ){
			return 'elementor-template';
		}
		if($singleLayout === 'single-global' || $singleLayout === null){
			return $globalSettings['general-single-layout'];
		} else{
			return $this->metaBoxes->getPostMeta( $id, 'meta-single-layout' );
		}
	}

	public function getSettings() {
		return $this->settings;
	}

	public function setSettings( $settings ) {
		$this->settings = $settings;
	}

	public function getHelper() {
		return $this->helper;
	}

	public function setHelper( $helper ) {
		$this->helper = $helper;
	}

	public function getMetaBoxes() {
		return $this->metaBoxes;
	}

	public function setMetaBoxes( $metaBoxes ) {
		$this->metaBoxes = $metaBoxes;
	}

	public function loadComponents() {
		$this->addComponent( new LavIndex( 'index', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavArchive( 'archive', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavNav( 'nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTwoRowsNav( 'two-rows-nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomNav( 'custom-nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavNavMobile( 'nav-mobile', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomNavMobile( 'custom-nav-mobile', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomMobileToggle( 'custom-mobile-toggle', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomWishlistIcon( 'wishlist-icon', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomCompareIcon( 'compare-icon', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomHomeIcon( 'home-icon', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomPromoMessage( 'promo-message', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomPromoBar( 'promo-bar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomNotices( 'notices', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavLogo( 'logo', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTopLine( 'top-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomTopLine( 'custom-top-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomMiddleLine( 'custom-middle-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomBottomLine( 'custom-bottom-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomStickyLine( 'custom-sticky-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomMobileLine( 'custom-mobile-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomMainNavigation( 'custom-main-navigation', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomMobileNavigation( 'custom-mobile-navigation', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomProductCategories( 'custom-product-categories', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavNavHeroBanner( 'nav-hero', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSpinner( 'spinner', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSearchForm( 'search-form', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavPage( 'page', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new Lav404Page( '404', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSearchPage( 'search', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavHeaderSearch( 'header-search', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleDefault( 'single-default', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleReview( 'single-review', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleSimple( 'single-simple', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleRating( 'single-rating', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleReading( 'single-reading', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavIndexHeader( 'index-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSearchHeader( 'search-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavLoopCards( 'loop-cards', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBreadcrumbs( 'breadcrumbs', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavPagination( 'pagination', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavFooter( 'footer', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavFooterTopLine( 'footer-top-line', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavFooterCopyright( 'footer-copyright', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBurger( 'burger', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBurgerSidebar( 'burger-sidebar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavFooterSidebar( 'footer-sidebar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavRelatedPosts( 'related', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSocialIcons( 'social', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleAuthorInfo( 'single-author-info', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavArchiveAuthorInfo( 'archive-author-info', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSidebarMenuNav( 'sidebar-menu-nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSidebarMenuHeader( 'sidebar-menu-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBookMenuNav( 'book-menu-nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTopLineEAddress( 'mail-top', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTopLinePhone( 'phone-top', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTopLineAddress( 'address-top', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavActionButton( 'action-button', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavScrollTop( 'scroll-top', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavPageHeader( 'page-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleDefaultHeader( 'single-default-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleSimpleHeader( 'single-simple-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleReviewHeader( 'single-review-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleServiceHeader( 'single-service-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleReadingHeader( 'single-reading-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavIrRating( 'ir-rating', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavAuthorRating( 'author-rating', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavReviewStars( 'review-stars', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBookMeta( 'book-meta', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavContentNone( 'content-none', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new Lav404Header( '404-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavPostNav( 'post-nav', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavElementorTemplate( 'elementor-template', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavAuthorAvatar( 'author-avatar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavUserAvatar( 'user-avatar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavAuthorSectionAvatar( 'section-author-avatar', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleDonation( 'single-donation', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavSingleService( 'single-service', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavTopLineMenu( 'top-menu', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShareButtons( 'share-buttons', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavCustomAccountLink( 'account-link', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavProsCons( 'pros-cons', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavAdBanner( 'ad-banner', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		// Woo
		$this->addComponent( new LavShopHeader( 'shop-header', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavAddToCart( 'add-to-cart', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopMiniCart( 'mini-cart', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopMiniCartDropdown( 'mini-cart-dropdown', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopMiniCartDrawer( 'mini-cart-drawer', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopMiniCartDefault( 'mini-cart-default', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopCustomButton( 'product-custom-button', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopDemoButton( 'product-demo', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopDemoIcon( 'demo-icon', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopFakeSales( 'fake-sales', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavStockStatus( 'stock-status', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavRatingCount( 'rating-count', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavProductFeatures( 'product-features', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavProductDiscount( 'product-discount', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopSearchForm( 'shop-search-form', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavBeforeContentElementor( 'before-content-elementor', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopVideoIcon( 'video-icon', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopQuickView( 'quick-view', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopDeliveryPopup( 'delivery-popup', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopSizesPopup( 'sizes-popup', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopReturnPopup( 'return-popup', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopCustomLink( 'custom-link', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopTrustedImage( 'trusted-image', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopProductFixBottomBanner( 'product-fix-bottom-banner', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavProductCountDown( 'product-countdown', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavShopAddToCartPopupNotice( 'add-to-cart-popup', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
		$this->addComponent( new LavProductCustomGallery( 'product-custom-gallery', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes() ) );
	}

	public function run() {
		$this->loadComponents();
	}

}
