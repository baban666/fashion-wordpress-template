<?php

namespace classes\providers;

class LavHelpersProvider {
	public static $template_path = LAV_TPL_PATH . '/loops/';

	public function getPostTypes() {
		$post_type_args = array(
			'public'            => true,
			'show_in_nav_menus' => true
		);

		$post_types = get_post_types( $post_type_args, 'objects' );
		$post_lists = array();
		foreach ( $post_types as $post_type ) {
			$post_lists[ $post_type->name ] = $post_type->labels->singular_name;
		}

		return $post_lists;
	}

	public static function wpKses( $string ) {
		$allowed_html = [
			'b'      => [],
			's'      => [],
			'strong' => [],
			'i'      => [],
			'u'      => [],
			'br'     => [],
			'em'     => [],
			'del'    => [],
			'ins'    => [],
			'sup'    => [],
			'sub'    => [],
			'code'   => [],
			'small'  => [],
			'strike' => [],
			'abbr'   => [
				'title' => [],
			],
			'span'   => [
				'class' => [],
			],
			'a'      => [
				'href'  => [],
				'title' => [],
				'class' => [],
				'id'    => [],
			],
			'img'    => [
				'src'    => [],
				'alt'    => [],
				'height' => [],
				'width'  => [],
			],
			'hr'     => [],
		];

		return wp_kses( $string, $allowed_html );
	}

	public static function getAllCategories() {
		$cat_array  = array();
		$categories = get_categories( 'orderby=name&hide_empty=0' );
		foreach ( $categories as $category ):
			$cat_array[ $category->term_id ] = $category->name;
		endforeach;

		return $cat_array;
	}

	public static function getAllTags() {
		$tag_array = array();
		$tags      = get_tags();
		foreach ( $tags as $tag ) {
			$tag_array[ $tag->term_id ] = $tag->name;
		}

		return $tag_array;
	}

	public static function pink_milk_get_authors() {
		$user_query = new \WP_User_Query(
			[
				'who'                 => 'authors',
				'has_published_posts' => true,
				'fields'              => [
					'ID',
					'display_name',
				],
			]
		);

		$authors = array();

		foreach ( $user_query->get_results() as $result ) {
			$authors[ $result->ID ] = $result->display_name;
		}

		return $authors;
	}

	public static function getAllPosts() {
		$post_array = array(
			'posts_per_page' => - 1
		);
		$posts      = get_posts( $post_array );
		foreach ( $posts as $post ) {
			$post_array[ $post->ID ] = $post->post_title;
		}

		return $post_array;
	}

	public static function getPostArguments( $settings, $prefix ) {

		$author_ids = implode( ", ", $settings[ $prefix . '_authors' ] );

		if ( isset( $settings[ $prefix . '_categories' ] ) ) {
			$category_ids = implode( ", ", $settings[ $prefix . '_categories' ] );
		} else {
			$category_ids = [];
		}

		if ( 'yes' === $settings[ $prefix . '_ignore_sticky' ] ) {
			$alice_ignore_sticky = true;
		} else {
			$alice_ignore_sticky = false;
		}

		$post_args = array(
			'post_type'           => $settings[ $prefix . '_type' ],
			'posts_per_page'      => $settings[ $prefix . '_per_page' ],
			'offset'              => $settings[ $prefix . '_offset' ],
			'cat'                 => $category_ids,
			'category_name'       => '',
			'ignore_sticky_posts' => $alice_ignore_sticky,
			'orderby'             => 'date',
			'order'               => $settings[ $prefix . '_order' ],
			'include'             => '',
			'exclude'             => '',
			'meta_key'            => '',
			'meta_value'          => '',
			'post_mime_type'      => '',
			'post_parent'         => '',
			'author'              => $author_ids,
			'author_name'         => '',
			'post_status'         => 'publish',
			'suppress_filters'    => true,
			'tag__in'             => $settings[ $prefix . '_tags' ],
			'post__not_in'        => $settings[ $prefix . '_exclude_post' ],
		);

		return $post_args;

	}


	public static function onePostCategory() {

		$categories = get_the_category();
		$separator  = ' ';
		$output     = '';
		if ( ! empty( $categories ) ) {
			$output .= '<a class="label-top shadow-sm" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>' . $separator;

			return trim( $output, $separator );
		}
	}

	public static function theAllPostCategories() {

		if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list();
			if ( $categories_list ) {
				return '<div class="cat-links">' . $categories_list . '</div>';
			}
		}
	}

	public static function pink_milk_reading_time( $content ) {

		$word_count  = str_word_count( strip_tags( $content ) );
		$readingtime = ceil( $word_count / 200 );

		$timer = " min read";

		$totalreadingtime = $readingtime . $timer;

		return $totalreadingtime;
	}


	public static function getExcerpt( $args = '' ) {
		global $post;

		if ( is_string( $args ) ) {
			parse_str( $args, $args );
		}
		$rg = (object) array_merge( array(
			'maxchar'   => 350,
			'text'      => '',
			'autop'     => true,
			'save_tags' => '',
			'more_text' => esc_attr( 'Read more', 'alice-framework' )
		), $args );

		$rg = apply_filters( 'kama_excerpt_args', $rg );

		if ( ! $rg->text ) {
			$rg->text = $post->post_excerpt ?: $post->post_content;
		}

		$text = $rg->text;
		$text = preg_replace( '~\[([a-z0-9_-]+)[^\]]*\](?!\().*?\[/\1\]~is', '', $text );
		$text = preg_replace( '~\[/?[^\]]*\](?!\()~', '', $text );
		$text = trim( $text );

		if ( strpos( $text, '<!--more-->' ) ) {
			preg_match( '/(.*)<!--more-->/s', $text, $mm );

			$text = trim( $mm[1] );

			$text_append = ' <a href="' . get_permalink( $post ) . '#more-' . $post->ID . '">' . $rg->more_text . '</a>';
		} else {
			$text = trim( strip_tags( $text, $rg->save_tags ) );

			if ( mb_strlen( $text ) > $rg->maxchar ) {
				$text = mb_substr( $text, 0, $rg->maxchar );
				$text = preg_replace( '~(.*)\s[^\s]*$~s', '\\1...', $text );
			}
		}

		if ( $rg->autop ) {
			$text = preg_replace(
				array( "/\r/", "/\n{2,}/", "/\n/", '~</p><br ?/?>~' ),
				array( '', '</p><p>', '<br />', '</p>' ),
				$text
			);
		}

		$text = apply_filters( 'kama_excerpt', $text, $rg );

		if ( isset( $text_append ) ) {
			$text .= $text_append;
		}

		return strip_tags( strip_shortcodes( $text ) );
	}


	public static function getTheTitle( $title, $char ) {
		$tags = '<em><b><sup>';
		if ( (int) $char == 0 ) {
			return strip_tags( strip_shortcodes( $title ), $tags );
		} else {
			return strip_tags( strip_shortcodes( mb_strimwidth( $title, 0, (int) $char, '...' ) ), $tags );
		}
	}

	public static function getPostThumbnailUrl() {
		if ( has_post_thumbnail() ) {
			return the_post_thumbnail_url();
		} else {
			echo self::getPostThumbnailDefault();
		}

	}

	public static function getPostThumbnailDefault() {
		if ( ! has_post_thumbnail() ) {
			return get_template_directory_uri() . '/img/no-image.jpg';
		}
	}

	public static function thePostThumbnail(
		$size = array(
			780,
			500
		), $attr = array( 'class' => 'card-img-top' ), $class = 'card-img-top'
	) {

		if ( has_post_thumbnail() ) {
			return the_post_thumbnail( $size, $attr );
		} else {
			$output = 'src="';
			$output .= esc_url( self::getPostThumbnailDefault() ) . '"';
			$output .= 'class="' . $class . '"';
			$output .= 'alt="' . esc_html__( 'image  placeholder', 'laveria' ) . '"';
			printf( '<img %s>', $output );
		}
	}

	public static function thePostThumbnailURI(
		$size = array(
			780,
			500
		), $attr = array( 'class' => 'card-img-top' ), $class = 'card-img-top'
	) {
		if ( has_post_thumbnail() ) {
			return get_the_post_thumbnail_url( $size, $attr );
		} else {
			return esc_url( self::getPostThumbnailDefault() );
		}
	}


	public function getPosts( $settings, $template = 'post-list' ) {
		$posts = new \WP_Query( $settings['post_args'] );
		?>
        <div class="container">
            <div class="row posts-cards">
				<?php
				while ( $posts->have_posts() ) : $posts->the_post();
					if ( $template ) {
						include self::$template_path . $template . '.php';
					} else {
						_e( 'No Contents Found', 'laveria' );
					}
				endwhile;
				?>
            </div>
        </div>
		<?php
		wp_reset_postdata();
	}

	public static function firstLastNames( $first_name, $last_name ) {
		$full_name = '';

		if ( empty( $first_name ) ) {
			$full_name = $last_name;
		} elseif ( empty( $last_name ) ) {
			$full_name = $first_name;
		} else {
			$full_name = "{$first_name} {$last_name}";
		}

		return $full_name;
	}

	public function removeProtocol( $input ) {

		$input = trim( $input, '/' );

		if ( ! preg_match( '#^http(s)?://#', $input ) ) {
			$input = 'http://' . $input;
		}

		$urlParts = parse_url( $input );

		return preg_replace( '/^www\./', '', $urlParts['host'] );
	}

	public static function getPostMeta( $id = null, $name = null, $all = false ) {
		$options = get_post_meta( $id, 'alice_post_meta', true );

		if ( ! $options ) {
			return null;
		}
		if ( $all && $name == null ) {
			return $options;
		}
		$value = null;

		if ( ! array_key_exists( $name, $options ) ) {
			return null;
		}
		$value = $options[ $name ];
		if ( ! $value ) {
			return null;
		}
		if ( is_array( $value ) ) {
			return $value[0];
		} else {
			return $value;
		}
	}

	public static function getPageMeta( $id = null, $name = null ) {
		$options = get_post_meta( $id, 'alice_page_meta', true );
		if ( ! $options ) {
			return null;
		}

		$value = null;

		if ( ! array_key_exists( $name, $options ) ) {
			return null;
		}
		$value = $options[ $name ];

		if ( ! $value ) {
			return null;
		}
		if ( is_array( $value ) ) {
			return $value[0];
		} else {
			return $value;
		}
	}

	public function getMainNavStyles( $settings ) {
		$font_size = $settings['alice_nav_font_size'];
		$upper     = $settings['alice_nav_font_upper'] != '' ? 'upper' : ' ';
		$light     = $settings['alice_nav_font_light'] != '' ? 'light' : ' ';
		$shadow    = $settings['alice_enable_menu_shadow'] != '' ? 'shadow' : ' ';

		return $font_size . ' ' . $upper . ' ' . $light . ' ' . $shadow;
	}

	public function theAliceRequiredNotice() {
		if ( current_user_can( 'manage_options' ) ) {
			?>
            <div class="notice notice-warning is-dismissible">
                <p>
					<?php esc_html_e( 'lav theme requires Alice Core plugin to be installed. Please install and activate it', 'laveria' ); ?>
                    <a href="<?php echo admin_url( 'admin.php?page=lav-install-plugins' ); ?>"><?php esc_html_e( 'on this page', 'laveria' ); ?></a>
                </p>
            </div>
			<?php
		}
	}


	public function getComponentType() {
		if ( is_archive() ) {
			if ( is_tag() ) {
				return 'tag';
			} elseif ( is_category() ) {
				return 'category';
			} elseif ( is_date() ) {
				return 'date';
			} elseif ( is_author() ) {
				return 'author';
			} else {
				return 'archive';
			}
		} elseif ( is_page() ) {
			return 'page';
		} elseif ( is_single() ) {
			return 'single';
		} elseif ( is_search() ) {
			return 'search';
		} elseif ( is_404() ) {
			return '404';
		} else {
			return 'index';
		}
	}

	public function getContainer( $settings ) {
		$container = 'container';

		if ( $settings['general-layout'] === 'sidebar-menu-layout' || $settings['general-layout'] === 'book-layout' ) {
			$container = 'container-fluid';
		}

		return $container;
	}

	public function getSidebar( $settings ) {

		if ( $settings['general-sidebar'] === 'disable' || ! is_active_sidebar( 'sidebar-1' ) ) {
			return 'disable';
		} elseif ( $settings['general-layout'] === 'sidebar-menu-layout' || $settings['general-layout'] === 'book-layout' ) {
			return 'disable';
		} else {
			return $settings['general-sidebar'];
		}

	}

	public function getShopSidebar( $settings ) {

		if ( $settings['shop-sidebar'] === 'disable' || ! is_active_sidebar( 'lav-woo-1' ) ) {
			return 'disable';
		} else {
			return !empty($settings['shop-sidebar']) ? $settings['shop-sidebar'] : 'disable';
		}

	}

	public function getProductSidebar( $settings ) {

		if ( $settings['shop-sidebar'] === 'disable' || ! is_active_sidebar( 'lav-woo-1' ) ) {
			return 'disable';
		} else {
			return !empty($settings['shop-sidebar']) ? $settings['shop-sidebar'] : 'disable';
		}

	}

	public function getPageColumn( $settings ) {

		if ( $this->getSidebar( $settings ) === 'disable' ) {
			return 'col-md-12';
		} else {
			return 'col-md-12 col-lg-8';
		}

	}

	public function getShopPageColumn( $settings ) {

		if ( $this->getShopSidebar( $settings ) === 'disable' ) {
			return 'col-md-12';
		} else {
			return 'col-md-12 col-lg-8';
		}
	}

	public function getProductPageColumn( $settings ) {

		if ( $this->getProductSidebar( $settings ) === 'disable' ) {
			return 'col-md-12';
		} else {
			return 'col-md-12 col-lg-8';
		}
	}

	public function hasTopLine( $settings ) {

		return ( $settings['general-layout'] === 'top-menu-layout' || $settings['general-layout'] === 'boxed-layout' )
		       && $settings['header-top-line'] === '1'
		       && $settings['general-fixed'] !== '1';

	}

	public function topNavClassTopLine( $settings ) {
		$navClass = ' default-nav';

		if ( ( $settings['general-layout'] === 'top-menu-layout' || $settings['general-layout'] === 'boxed-layout'  || $settings['general-layout'] === 'two-rows-menu-layout' ) && $settings['general-fixed'] === '1' ) {
			return $navClass = ' fixed-top';
		} elseif ( ( $settings['general-layout'] === 'top-menu-layout' || $settings['general-layout'] === 'banner-menu-layout' || $settings['general-layout'] === 'boxed-layout' ) && ( $settings['general-fixed'] !== '1' && $settings['general-sticky'] === '1' ) ) {
			return $navClass = ' alice-sticky-top';
		} else {
			return $navClass;
		}

	}


	public static function getScoreColor( $value, $count ) {
		$i = 10 - $count;
		if ( $value > $i ) {
			if ( $i <= 3 ) {
				return 'orange';
			} elseif ( $i > 6 && $i <= 10 ) {
				return 'green';
			} elseif ( $i > 3 && $i <= 6 ) {
				return 'yellow';
			}
		}
	}


	public static function getScore( $value ) {
		for ( $i = 10; $i > 0; $i -- ): ?>
            <div class="progress-item <?php echo self::getScoreColor( $value, $i ) ?>"></div>
		<?php endfor;
	}


	public static function getStar( $value, $count, $len ) {
		$full  = 'las la-star';
		$half  = 'las la-star-half-alt';
		$empty = 'lar la-star';

		if (floatval($value) > floatval($count)) {
		    if( $len > 1 && intval($value) === intval($count)){
			    return $half;
		    }else{
		        return $full;
		    }
		} else{
			return $empty;
		}
	}

	public static function getAmazonStars( $value ) {
	?>
        <div class="review-stars">
			<?php for ( $i = 0; $i < 5; $i ++ ): ?>
                <i class="<?php echo esc_attr(self::getStar($value, $i, strlen($value)));  ?>"></i>
			<?php endfor; ?>
        </div>
	<?php
	}

	public function getUserProfileSetting( $key, $id ) {
		if ( empty( $key ) || empty( $id) ) {
			return false;
		}

		$allSettings = get_user_option( '_alice_core_profile_options', $id );

		if ( !empty( $allSettings) && !empty($allSettings[$key])  ) {
		    return $allSettings[$key];
		}
	}

	public function getBannerDetails( $value ) {

	    $bannerDetails = [
	            'bg-color' => '#0A2603',
	            'gradient-color' => '#42923A',
	            'image-url' => null,
	            'image-alt' => null,
        ];

	    if(empty( $value )){
		    return $bannerDetails;
        }

	    if(!empty( $value["background-color"] )){
		    $bannerDetails['bg-color'] = $value["background-color"];
        }

	    if(!empty( $value["background-gradient-color"])){
		    $bannerDetails['gradient-color'] = $value["background-gradient-color"];
        }

	    if(!empty( $value["background-gradient-direction"])){
		    $bannerDetails["direction"] = $value["background-gradient-direction"];
        }

	    if(!empty( $value["background-image"]) && !empty( $value["background-image"]['url'])){
		    $bannerDetails['image-url'] = $value["background-image"]['url'];
        }

	    if(!empty( $value["background-image"]) && !empty( $value["background-image"]['alt'])){
		    $bannerDetails['image-alt'] = $value["background-image"]['alt'];
        }

	    return $bannerDetails;
	}

	public function getServiceToc( $values ) {
	    if(empty($values)){
	        return;
	    }

		?>
        <div class="service-toc">
            <ul class="service-toc-list">
				<?php
                foreach ( $values as $value ) {
	                ?>
                    <li class="toc-item">
                        <a href="<?php echo esc_url($value['meta-single-toc-link']) ?>" class="toc-link">
			                <?php echo esc_html($value['meta-single-toc-title']) ?>
                        </a>
                    </li>
	                <?php
                }
				?>
            </ul>
        </div>
		<?php
		wp_reset_postdata();
	}

	public function getReadingToc( $values ) {
	    if(empty($values)){
	        return;
	    }
		?>
        <div class="service-toc">
            <ul class="service-toc-list">
				<?php
                foreach ( $values as $value ) {
	                ?>
                    <li class="toc-item">
                        <a href="<?php echo esc_url($value['meta-single-reading-toc-link']) ?>" class="toc-link">
			                <?php echo esc_html($value['meta-single-reading-toc-title']) ?>
                        </a>
                    </li>
	                <?php
                }
				?>
            </ul>
        </div>
		<?php
		wp_reset_postdata();
	}

	public function isActiveMeta($meta, $global){
	    if (empty($meta)){
	        return $global;
	    }else{
	        return !$meta;
	    }

	}

	public function getProductColumn( $value ) {

		if ( $value === 2 ) {
			return 'col-md-6';
		} elseif ($value === 4){
			return 'col-md-3';
		} else {
			return 'col-md-4';
		}

	}

	public function getEnabledElementsCustomHeader( $settings ) {
	    $enabledComponents = array();
		if ( is_array($settings) && !empty($settings)) {
			foreach ($settings as $key => $value){
			    if (!empty($settings[$key]['enabled'])){
				    $enabledComponents[$key] = $settings[$key]['enabled'];
			    }
			}
			return !empty($enabledComponents) ? $enabledComponents : array();
		} else {
			return $enabledComponents;
		}
	}

}
