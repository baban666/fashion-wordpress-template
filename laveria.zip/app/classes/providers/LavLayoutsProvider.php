<?php


namespace classes\providers;


use classes\abstracts\LavBaseLayout;
use classes\layouts\LavBannerMenuLayout;
use classes\layouts\LavBoxedLayout;
use classes\layouts\LavCustomMenuLayout;
use classes\layouts\LavTopMenuLayout;
use classes\layouts\LavTwoRowsMenuLayout;
use traits\TLavSingleton;

class LavLayoutsProvider {
	use TLavSingleton;

	private $_layouts = null;
	public $settings = null;
	public $helper = null;
	public $metaBoxes = null;
	public $components = null;

	public function addLayout( LavBaseLayout $widget ) {
		$this->_layouts[ $widget->getName() ] = $widget;
	}

	public function getLayouts($name) {
		return !empty($this->_layouts[$name]) ? $this->_layouts[$name] : $this->_layouts['top-menu-layout'];
	}

	public function getSettings() {
		return $this->settings;
	}

	public function setSettings( $settings ) {
		$this->settings = $settings;
	}

	public function getHelper() {
		return $this->helper;
	}

	public function setHelper( $helper ) {
		$this->helper = $helper;
	}

	public function getMetaBoxes() {
		return $this->metaBoxes;
	}

	public function setMetaBoxes( $metaBoxes ) {
		$this->metaBoxes = $metaBoxes;
	}

	public function getComponents() {
		return $this->components;
	}

	public function setComponents( $components ) {
		$this->components = $components;
	}

	public function run() {

		$this->addLayout(new LavTopMenuLayout('top-menu-layout', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes(), $this->getComponents() ));
		$this->addLayout(new LavBannerMenuLayout('banner-menu-layout', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes(), $this->getComponents() ));
		$this->addLayout(new LavBoxedLayout('boxed-layout', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes(), $this->getComponents() ));
		$this->addLayout(new LavTwoRowsMenuLayout('two-rows-menu-layout', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes(), $this->getComponents() ));
		$this->addLayout(new LavCustomMenuLayout('custom-menu-layout', $this->getSettings(), $this->getHelper(), $this->getMetaBoxes(), $this->getComponents() ));

	}
}
