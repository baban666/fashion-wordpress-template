<?php


namespace classes\providers;


class LavMetaBoxesProvider {



	public function getPageMeta($id, $key) {

		if ( class_exists( 'Alice_Core' ) ) {
			$meta =  get_post_meta( $id, 'page-meta-alice-core' , true );
			return !empty($meta[$key]) ? $meta[$key] : null;
		} else {
			return null;
		}
	}

	public function getProductMeta($id, $key) {

		if ( class_exists( 'Alice_Core' ) ) {
			$meta =  get_post_meta( $id, 'product-meta-alice-core' , true );
			return !empty($meta[$key]) ? $meta[$key] : null;
		} else {
			return null;
		}
	}

	public function getPostMeta($id, $key) {
		if ( class_exists( 'Alice_Core') ) {
			$meta =  get_post_meta( $id, 'post-meta-alice-core' , true );
			if(!empty($meta[$key])){
				return $meta[$key];
			}
			return $this->getSubPostMeta($key, $meta);
		} else {
			return null;
		}
	}

	public function getSubPostMeta($key, $meta) {
		if (empty($meta['meta-single-values-tabs'])){
			return null;
		}
		return !empty($meta['meta-single-values-tabs'][$key]) ? $meta['meta-single-values-tabs'][$key] : null;
	}
}
