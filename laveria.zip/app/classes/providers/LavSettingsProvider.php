<?php


namespace classes\providers;


class LavSettingsProvider {

	public $settings;

	public function __construct() {

		if ( class_exists( 'Alice_Core' ) || is_array(get_option( 'alice-core' )) ) {
			$this->settings = is_bool(get_option( 'alice-core' ))
                ? $this->getDefaultSettings()
                : get_option( 'alice-core' );
		} else {
			$this->settings = $this->getDefaultSettings();
			add_action('admin_notices', array($this, 'requiredNotice'));
		}
	}

	public function getSettings() {
		return $this->settings;
	}

	public function getDefaultSettings() {
		return array(
			'general-layout'                 => 'top-menu-layout',
			'general-hero-header-background' => array(
				'background-color'              => '#0D3439',
				'background-gradient-color'     => '#0D3439',
				'background-gradient-direction' => 'to bottom',
				'background-image'              => array(
					'url'         => '',
					'id'          => '',
					'width'       => '',
					'height'      => '',
					'thumbnail'   => '',
					'alt'         => '',
					'title'       => '',
					'description' => '',
				)
			),
			'general-sidebar'                => 'order-last',
			'general-fixed'                  => 0,
			'general-sticky'                 => 0,
			'general-page-header-layout'     => 'full-width',
			'general-page-header-background' => array(
				'background-color'              => '#0D3439',
				'background-gradient-color'     => '#0D3439',
				'background-gradient-direction' => 'to bottom',
				'background-image'              => array(
					'url'         => '',
					'id'          => '',
					'width'       => '',
					'height'      => '',
					'thumbnail'   => '',
					'alt'         => '',
					'title'       => '',
					'description' => '',
				)
			),
			'general-blog-header-layout'     => 'full-width',
			'general-blog-header-background' => array(
				'background-color'              => '#0D3439',
				'background-gradient-color'     => '#0D3439',
				'background-gradient-direction' => 'to bottom',
				'background-image'              => array(
					'url'         => '',
					'id'          => '',
					'width'       => '',
					'height'      => '',
					'thumbnail'   => '',
					'alt'         => '',
					'title'       => '',
					'description' => '',
				)
			),
			'general-desc-char'                 => 135,
			'general-pagination'                => 'simply',
			'general-index-loop-layout'         => 'list',
			'general-archive-loop-layout'       => 'list',
			'general-category-loop-layout'      => 'list',
			'general-tag-loop-layout'           => 'list',
			'general-author-loop-layout'        => 'list',
			'general-date-loop-layout'          => 'list',
			'general-search-loop-layout'        => 'list',
			'general-single-layout'             => 'single-default',
			'general-single-header-background'  => array(
				'background-color'              => '#0D3439',
				'background-gradient-color'     => '#0D3439',
				'background-gradient-direction' => 'to bottom',
				'background-image'              => array(
					'url'         => '',
					'id'          => '',
					'width'       => '',
					'height'      => '',
					'thumbnail'   => '',
					'alt'         => '',
					'title'       => '',
					'description' => '',
				)
			),
			'general-js-footer'                 => '',
			'general-js-header'                 => '',
			'header-action'                     => 0,
			'header-logo'                       => 1,
			'header-action-text'                => 'Get Started',
			'header-action-link'                => '#',
			'header-action-new-window'          => 0,
			'header-search'                     => 0,
			'header-social'                     => 0,
			'header-upper'                      => 0,
			'header-shadow'                     => 0,
			'header-top-line'                   => 0,
			'header-social-top'                 => 1,
			'header-phone-top'                  => 1,
			'header-phone'                      => '+ 012 345 6789',
			'header-email-top'                  => 1,
			'header-email'                      => 'info@example.com',
			'footer-enable'                     => 0,
			'footer-top-enable'                 => 0,
			'footer-top-container'              => 0,
			'footer-top-content'                => '',
			'footer-copyright-enable'           => 0,
			'footer-copyright-content'          => '© Copyright',
			'footer-copyright-menu'             => 0,
			'global-loader'                     => 0,
			'global-scroll-top'                 => 0,
			'global-single-show-related'        => 1,
			'global-single-related-type'        => 'category',
			'global-single-related-quantity'    => 2,
			'global-single-show-category'       => 1,
			'global-single-show-tag'            => 1,
			'global-single-show-date'           => 1,
			'global-single-show-author'         => 1,
			'global-single-show-author-section' => 1,
			'global-single-show-comment'        => 1,
			'global-single-show-crumbs'         => 0,
			'global-single-show-nav'            => 1,
			'global-loop-show-category'         => 1,
			'global-loop-show-image'            => 1,
			'global-loop-show-title'            => 1,
			'global-loop-show-date'             => 1,
			'global-loop-show-star'             => 0,
			'global-loop-show-excerpt'          => 1,
			'global-loop-show-author'           => 1,
			'global-loop-show-comment'          => 1,
			'global-loop-show-read-more'        => 1,
			'global-loop-show-description'      => 1,
			'font-navigation'                   => array(
				'font-family' => '',
				'font-weight' => '',
				'font-style'  => '',
				'subset'      => '',
				'type'        => '',
				'unit'        => ''
			),
			'font-body' => array(
				'font-family' => '',
				'font-weight' => '',
				'font-style'  => '',
				'subset'      => '',
				'type'        => '',
				'unit'        => '',
			),
			'font-headings' => array(
				'font-family' => '',
				'font-weight' => '',
				'font-style'  => '',
				'subset'      => '',
				'type'        => '',
				'unit'        => '',
			),
			'social-facebook'   => '',
			'social-twitter'    => '',
			'social-instagram'  => '',
			'social-good'       => '',
			'social-wa'         => '',
			'social-youtube'    => '',
			'social-vimeo'      => '',
			'social-pinterest'  => '',
			'social-linkedin'   => '',
			'social-soundcloud' => '',
			'social-vk'         => '',
			'social-telegram'   => '',
			'social-ok'         => '',
			'social-effects'    => '',
			'social-color'      => '',
			'social-target'     => 1,
		);
	}
	public function requiredNotice( ) {
		if ( current_user_can( 'manage_options' ) ) {
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
				<?php esc_html_e( 'Alice Core plugin adds additional features for lav theme. Please install and activate it', 'laveria'); ?> <a href="<?php echo esc_url(admin_url( 'admin.php?page=lav-install-plugins' )) ;?>"><?php esc_html_e( 'on this page', 'laveria'); ?></a>
				</p>
			</div>
			<?php
		}
	}
}
