<?php


namespace classes\providers;

use traits\TLavSingleton;

class LavWooSupportProvider {
	use TLavSingleton;

	public $settings = null;
	public $_settings = null;
	public $helper = null;
	public $metaBoxes = null;
	public $components = null;

	public function getSettings() {
		return $this->settings;
	}

	public function setSettings( $settings ) {
		$this->settings = $settings;
	}

	public function getHelper() {
		return $this->helper;
	}

	public function setHelper( $helper ) {
		$this->helper = $helper;
	}

	public function getMetaBoxes() {
		return $this->metaBoxes;
	}

	public function setMetaBoxes( $metaBoxes ) {
		$this->metaBoxes = $metaBoxes;
	}

	public function getComponents() {
		return $this->components;
	}

	public function setComponents( $components ) {
		$this->components = $components;
	}

	public function getValue( $key ) {
		return ! empty( $this->_settings[ $key ] ) ? $this->_settings[ $key ] : null;
	}

	public function getArchiveLayout() {
		return ! empty( $this->getValue( 'shop-layout' ) )
			? $this->getValue( 'shop-layout' )
			: 'product';
	}

	public function getContentLayout() {
		$shopLayout = ! empty( $this->getValue( 'shop-layout' ) )
			? $this->getValue( 'shop-layout' )
			: 'product';

		return $shopLayout === 'product'
			? 'default-content-product'
			: 'grid-content-product';
	}

	public function getProductLayout( $id ) {
		$meta         = $this->metaBoxes->getProductMeta( $id, 'single-product-layout' );
		$globalLayout = ! empty( $this->getValue( 'shop-single-product-layout' ) )
			? $this->getValue( 'shop-single-product-layout' )
			: 'single-product';

		if ( ! empty( $meta ) ) {
			return $meta !== 'global-single-product'
				? $meta
				: $globalLayout;
		} else {
			return $globalLayout;
		}
	}

	/**
	 * Add 'woocommerce-active' class to the body tag.
	 *
	 * @param array $classes CSS classes applied to the body tag.
	 *
	 * @return array $classes modified to include 'woocommerce-active' class.
	 */
	public function woocommerce_active_body_class( $classes ) {
		$classes[] = 'woocommerce-active';

		return $classes;
	}

	public function wcc_change_breadcrumb_delimiter( $defaults ) {
		// Change the breadcrumb delimeter from '/' to '-'
		$defaults['delimiter'] = '<span class="sep">-</span>';

		return $defaults;
	}

	public function lav_woocommerce_get_sidebar() {

		?>
        <!-- #secondary -->
        <aside id="secondary"
               class="col-md-12 col-lg-4 widget-area <?php echo esc_attr( $this->helper->getShopSidebar( $this->_settings ) ); ?>" data-sticky-container>
            <div class="sidebar-wrapper">
				<?php dynamic_sidebar( 'lav-woo-1' ); ?>
            </div>
        </aside>
        <!-- #secondary -->

		<?php

	}

	public function openWrapper() {
		echo '<div class="order-review-wrapper" data-sticky-container>';
		echo '<div id="sticky-section" class="order-review-sticky"  data-sticky-for="992" data-margin-top="95">';
	}

	public function closeWrapper() {
		echo '</div>';
		echo '</div>';
	}

	/**
	 * WooCommerce setup function.
	 *
	 * @link https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/
	 * @link https://github.com/woocommerce/woocommerce/wiki/Enabling-product-gallery-features-(zoom,-swipe,-lightbox)
	 * @link https://github.com/woocommerce/woocommerce/wiki/Declaring-WooCommerce-support-in-themes
	 *
	 * @return void
	 */
	function lavWoocommerceSetup() {
		add_theme_support(
			'woocommerce',
			array(
				'thumbnail_image_width' => 450,
				'single_image_width'    => 900,
				'product_grid'          => array(
					'default_rows'    => 3,
					'min_rows'        => 1,
					'default_columns' => 2,
					'min_columns'     => 2,
					'max_columns'     => 4,
					'max_rows'        => 8,
				),
			)
		);

		if ( ! empty( $this->getValue( 'shop-zoom-enable' ) ) ) {
			add_theme_support( 'wc-product-gallery-zoom' );
		}

		if ( $this->getValue( 'shop-single-product-gallery-type' ) == 'default' ) {
			add_theme_support( 'wc-product-gallery-lightbox' );
			add_theme_support( 'wc-product-gallery-slider' );
		}
	}


	/**
	 * Related Products Args.
	 *
	 * @param array $args related products args.
	 *
	 * @return array $args related products args.
	 */
	public function lavWoocommerceRelatedProducts_args( $args ) {
		$defaults = array(
			'posts_per_page' => ! empty( $this->getValue( 'shop-single-related-quantity' ) )
				? $this->getValue( 'shop-single-related-quantity' )
				: 3,
			'columns'        => $this->getValue( 'shop-single-related-columns' ) !== '3'
				? 4
				: 3,
		);

		$args = wp_parse_args( $defaults, $args );

		return $args;
	}

	public function changeH2ProductTitle() {
		echo '<h3 class="' . esc_attr( apply_filters( 'woocommerce_product_loop_title_classes', 'woocommerce-loop-product__title' ) ) . '">' . get_the_title() . '</h3>';
	}

	public function enqueueGalleryScripts() {
		wp_enqueue_style( 'swiper' );
		wp_enqueue_script( 'swiper' );
		wp_enqueue_script( 'fancybox-js', get_template_directory_uri() . '/js/fancybox.umd.js', array( 'jquery' ), '5.0.0', true );
	}

	public function hide_related_products() {
		global $product;
		$IsRelatedDisable = $this->metaBoxes->getProductMeta( $product->get_id(), 'meta-product-disable-related' );
		if ( ! empty( $IsRelatedDisable ) ) {
			remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
		}
	}

	/**
	 * Filer WooCommerce Flexslider options - Add Navigation Arrows
	 */
	public function woo_flexslider_options( $options ) {
		$options['directionNav'] = true;

		return $options;
	}

	public function change_gallery_columns() {
		return 1;
	}

	// Add the opening div to the img
	public function imgWrapperStart() {
		echo '<div class="product-img">';
	}

	// Close the div that we just added
	public function imgWrapperClose() {
		echo '</div>';
	}

	public function disableElementorLightbox( $html ) {

		// Regular expression to find the href attribute in the <a> tag
		$pattern = '/(<a\s+href=")[^"]+(")/i';

		// Replacement pattern to replace href value with #
		$replacement = '$1#$2';

		// Perform the replacement
		$new_html = preg_replace( $pattern, $replacement, $html );

		// Output the new string
		return $new_html;
	}

	public function archiveCategoriesWrapperOpen( $args ) {
		return '<div class="archive-products-categories">' . $args;
	}

	public function archiveCategoriesWrapperClose( $args ) {
		return $args . '</div>';
	}

	public function renderCustomTabs( $tabs ) {
	    $customTabs = $this->getValue( 'shop-custom-tabs' );
	    if ( !empty( $customTabs ) && is_array($customTabs)) {
	        foreach ($customTabs as $k => $tab){
	            $title = !empty($tab['tab-title']) ? $tab['tab-title'] : esc_html__('Custom Tab', 'laveria');
	            $content = !empty($tab['tab-content']) ? $tab['tab-content'] : esc_html__(' ', 'laveria');
		        $tabs['alice-custom-tab' . $k] = array(
			        'title' => esc_html( $title), // TAB TITLE
			        'priority' => 50, // TAB SORTING (DESC 10, ADD INFO 20, REVIEWS 30)
			        'callback' => function() use ( $content ) {
				        $this->getCustomTabsContent( $content );
			        }, // TAB CONTENT CALLBACK
		        );
	        }
	    }
		return $tabs;
	}

	public function getCustomTabsContent( $content ) {
		echo do_shortcode( wp_kses_post($content) );
	}

	public function run() {
		$this->_settings = $this->settings->getSettings();

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueGalleryScripts' ) );

		if ( empty( $this->getValue( 'shop-gallery-enable' ) ) ) {
			add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'imgWrapperClose' ), 12 );
			add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'imgWrapperStart' ), 5 );
		}

		if ( !empty( $this->getValue( 'shop-custom-tabs-enable' ) ) ) {
			add_filter( 'woocommerce_product_tabs', array( $this, 'renderCustomTabs' ), 9999 );
		}

		if ( $this->getValue( 'shop-single-product-gallery-type' ) != 'default' ) {
			remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
		}

		if ( empty( $this->getValue( 'shop-zoom-enable' ) && $this->getValue( 'shop-single-product-gallery-type' ) == 'default' ) ) {
			add_filter( 'woocommerce_single_product_image_thumbnail_html', array( $this, 'disableElementorLightbox' ) );
		}
		add_action( 'after_setup_theme', array( $this, 'lavWoocommerceSetup' ), 90 );

		add_filter( 'woocommerce_output_related_products_args', array( $this, 'lavWoocommerceRelatedProducts_args' ) );

		add_filter( 'body_class', array( $this, 'woocommerce_active_body_class' ) );

		/**
		 * Disable the default WooCommerce stylesheet.
		 *
		 * Removing the default WooCommerce stylesheet and enqueing your own will
		 * protect you during WooCommerce core updates.
		 *
		 * @link https://docs.woocommerce.com/document/disable-the-default-stylesheet/
		 */
		add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );


		/**
		 * Remove default WooCommerce wrapper.
		 */
		remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
		remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );


		/**
		 * Remove default WooCommerce pagination.
		 */
		remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );


		/**
		 * Change the breadcrumb separator
		 */
		add_filter( 'woocommerce_breadcrumb_defaults', array( $this, 'wcc_change_breadcrumb_delimiter' ) );

		/**
		 * Add order review wrapper
		 */
		add_action( 'woocommerce_checkout_before_order_review_heading', array( $this, 'openWrapper' ) );
		add_action( 'woocommerce_checkout_after_order_review', array( $this, 'closeWrapper' ) );

		/**
		 * Layout Customization -remove actions
		 */
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
		add_action( 'woocommerce_sidebar', array( $this, 'lav_woocommerce_get_sidebar' ), 10 );
		/**
		 * Remove "Description" Heading Title @ WooCommerce Single Product Tabs
		 */
		add_filter( 'woocommerce_product_description_heading', '__return_null' );
		add_filter( 'woocommerce_product_additional_information_heading', '__return_null' );


		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 10 );
		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 20 );


		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		add_action( 'woocommerce_shop_loop_item_title', array( $this, 'changeH2ProductTitle' ), 10 );

		// 3. Hide related products in single product page
		add_action( 'woocommerce_after_single_product_summary', array( $this, 'hide_related_products' ), 1 );


		// Carousel options
		add_filter( 'woocommerce_single_product_carousel_options', array( $this, 'woo_flexslider_options' ) );
		add_filter( 'woocommerce_product_thumbnails_columns', array( $this, 'change_gallery_columns' ) );


		// Archive categories wrapper
		add_filter( 'woocommerce_before_output_product_categories', array(
			$this,
			'archiveCategoriesWrapperOpen'
		), 10 );
		add_filter( 'woocommerce_after_output_product_categories', array(
			$this,
			'archiveCategoriesWrapperClose'
		), 10 );

	}
}
