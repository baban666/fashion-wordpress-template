<?php


namespace interfaces;


interface ILavComponent {

	public function getName();
	public function render();

}
