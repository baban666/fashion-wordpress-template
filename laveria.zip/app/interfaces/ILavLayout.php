<?php


namespace interfaces;


interface ILavLayout {

	public function getName();
	public function renderBodyHead();
	public function renderHeader();
	public function renderPage();
	public function render404Page();
	public function renderSearchPage();
	public function renderIndex();
	public function renderSingle();
	public function renderSidebar();
	public function renderFooter();
	public function renderBodyFooter();

}
