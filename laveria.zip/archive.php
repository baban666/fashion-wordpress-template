<?php
use classes\providers\LavLayoutsProvider;

$lavArchiveRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavArchiveRenderer->getSettings()->getSettings();


$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavLayout = $lavArchiveRenderer->getLayouts($lavGeneralLayout);

$lavLayout->renderIndex();
