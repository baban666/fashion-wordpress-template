<?php


use classes\providers\LavLayoutsProvider;

$lavFooterRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavFooterRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavFooterLayout = $lavFooterRenderer->getLayouts($lavGeneralLayout );


$lavFooterLayout->renderFooter();
$lavFooterLayout->renderBodyFooter();




