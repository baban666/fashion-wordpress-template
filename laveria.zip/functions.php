<?php

use classes\core\LavCore;

if ( ! defined( 'LAV_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( 'LAV_VERSION', '1.0.0' );
}

if ( ! defined( 'LAV_TPL_PATH' ) ) {
	define( 'LAV_TPL_PATH', get_template_directory() . '/template-parts' );
}
if ( ! defined( 'LAV_LOOPS_PATH' ) ) {
	define( 'LAV_LOOPS_PATH', get_template_directory() . '/template-parts/loops/' );
}
if ( ! defined( 'LAV_IMG_URI' ) ) {
	define( 'LAV_IMG_URI', get_template_directory_uri() . '/img/' );
}

/**
 * Classes autoload.
 */
require get_template_directory() . '/app/class-autoload.php';

/**
 * Run Theme Core.
 */

$lavCore = LavCore::getInstance();
$lavCore->run();
