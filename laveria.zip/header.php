<?php


use classes\providers\LavLayoutsProvider;

$lavHeaderRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavHeaderRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavHeaderLayout = $lavHeaderRenderer->getLayouts($lavGeneralLayout);


$lavHeaderLayout->renderHeader();

