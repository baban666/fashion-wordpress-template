<?php
use classes\providers\LavLayoutsProvider;

$lavIndexRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavIndexRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavLayout = $lavIndexRenderer->getLayouts($lavGeneralLayout);

$lavLayout->renderIndex();
