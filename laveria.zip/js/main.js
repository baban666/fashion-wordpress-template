(function ($) {
    'use strict';

    // Spinner
    $(window).on('load', () => {
        $('#alice-spinner-status').fadeOut();
        $('#alice-spinner-preloader').fadeOut('slow');
    });


    // Sticky Nav

    const navBannerSticky = $('.banner-menu-layout .navbar.alice-sticky-top');
    const navSticky = $('.navbar.alice-sticky-top, .custom-sticky-row-nav.alice-sticky-top, .mobile-top-row.alice-sticky-top');
    const navFixed = $('.navbar.fixed-top');


    const toggleSticky = (height, element) => {
        if ($(window).scrollTop() > height) {
            element.addClass('sticky-top');
        } else {
            element.removeClass('sticky-top');
        }
    }

    if (navSticky) {
        $(window).on('scroll', () => {
            if (navBannerSticky.length) {
                toggleSticky(window.innerHeight, navSticky);
            } else {
                toggleSticky(190, navSticky);
            }
        });
    }

    if (navFixed) {
        $(window).on('scroll', () => {
            if ($(window).scrollTop() > 70) {
                navFixed.addClass('alice-sticky-top');
            } else {
                navFixed.removeClass('alice-sticky-top');
            }
        });
    }

    // Dropdown on mouse hover
    const $dropdown = $('.top-menu-layout .dropdown, .boxed-layout .dropdown, .banner-menu-layout .dropdown');
    const $dropdownToggle = $('.top-menu-layout .dropdown-toggle, .boxed-layout .dropdown-toggle, .banner-menu-layout .dropdown-toggle');
    const $dropdownMenu = $('.top-menu-layout .dropdown-menu, .boxed-layout .dropdown-menu, .banner-menu-layout .dropdown-menu');
    const showClass = 'show';

    $(window).on('load resize', function () {
        if (this.matchMedia('(min-width: 992px)').matches) {
            $dropdown.hover(
                () => {
                    const $this = $(this);
                    $this.addClass(showClass);
                    $this.find($dropdownToggle).attr('aria-expanded', 'true');
                    const el = $this.find($dropdownMenu)[0];
                    $(el).addClass(showClass);
                },
                () => {
                    const $this = $(this);
                    $this.removeClass(showClass);
                    $this.find($dropdownToggle).attr('aria-expanded', 'false');
                    $this.find($dropdownMenu).removeClass(showClass);
                }
            );
        } else {
            $dropdown.off('mouseenter mouseleave');
        }
    });



    // progress
    const progressInit = () => {
        const value = 5;
        const percent = 100;
        const review = document.querySelector(`.ir-rating`);

        const runProgress = () => {
            const progress = document.querySelector(`.ir-rating .determinate`);
            const ratingValue = review.dataset.rating / value * percent;
            if (progress) {
                progress.style.width = ratingValue + '%';
            }

            const aliceTooltip = document.querySelector(`.ir-rating .alice-tooltip`);
            if (aliceTooltip) {
                aliceTooltip.style.left = ratingValue + '%';
            }

            const loaderMaskLeft = document.querySelector(`.ir-rating .loader-mask-left .loader-line`);
            const loaderMaskRight = document.querySelector(`.ir-rating .loader-mask-right .loader-line`);

            if (loaderMaskLeft && loaderMaskRight) {
                loaderMaskRight.classList.add('show');
                loaderMaskLeft.classList.add('show');
            }
        };

        if (!!window.IntersectionObserver && review) {
            const observerCallback = (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        runProgress();
                    }
                });
            };
            const observer = new IntersectionObserver(observerCallback);
            observer.observe(review);
        }
    };

    progressInit();



    // update Mini Cart
    $(document.body).trigger('wc_fragment_refresh');

    //
    // 3D on hover
    //

    const cards = document.querySelectorAll('.moveable-3d');

    if (cards.length) {
        cards.forEach((card) => {
            // calculating card width and height
            const cardWidth = card.clientWidth;
            const cardHeight = card.clientHeight;
            // event handler when mouse moves in the card
            card.addEventListener('mousemove', (e) => {
                //storing the distance of the point where mouse cursor w.r.t. card(relative distance - origin is at center of card)
                const xWidth = e.layerX;
                const yHeight = e.layerY;

                //Calculating rotation (you can try different values to see change in effect)
                const xRotation = 15 * ((xWidth - cardWidth) / cardWidth);
                const yRotation = 15 * ((yHeight - cardHeight) / cardHeight);
                //tilting the card based on rotating values stored in transform variable
                card.style.transform = `rotateX(${xRotation}deg) rotateY(${yRotation}deg)`;

            });

            //bringing the card in the normal position when mouse is out
            card.addEventListener('mouseout', () => {
                card.style.transform = 'rotateX(0deg) rotateY(0deg)';
            });
        })
    }

    // header promotion bar
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 7);
    const promotionClose = document.getElementById("promo-bar-close");
    if (promotionClose) {
        promotionClose.addEventListener("click", () => {
            document.getElementById("promo-bar").classList.add("closed");
            document.cookie = "promotionClosed=true; expires=" + expiryDate.toUTCString() + "; path=/";
        });
    }

    // Mini cart Drawer
    const body = $("body");
    let ic_quantity_update_send = true
    /* global  lav_mini_cart_drawer */

    // Update cart on button click
    const updateQutButtons = (el) => {
        if (ic_quantity_update_send) {
            $(".ic-cart-sidebar-wrapper_body ul").addClass("loading")
            ic_quantity_update_send = false
            const wrap = $(el).closest(".woocommerce-mini-cart-item")
            const input = $(wrap).find(".qty")
            const key = $(wrap).data("key")
            let number = parseInt($(input).val())
            const type = $(el).data("type")
            if (type === "minus") {
                number--
            } else {
                number++
            }
            if (number < 1) {
                number = 1
            }

            $(input).val(number)
            const data = {
                action: "lav_qty_update",
                key: key,
                number: number,
                security: lav_mini_cart_drawer.nonce
            }

            $.post(lav_mini_cart_drawer.ajax_url, data, (res) => {
                const cart_res = JSON.parse(res)
                $(".ic-cart-sidebar-wrapper_body  p.woocommerce-mini-cart__total.total .amount").html(cart_res["total"]);
                $(wrap).find(".ic-custom-render-total").html(cart_res["item_price"]);
                ic_quantity_update_send = true;
                $(".ic-cart-sidebar-wrapper_body ul").removeClass("loading");
            });
        }
    }

    // Update cart on input blur
    function updateQutButtonsBlur(input) {
        $(".ic-cart-sidebar-wrapper_body ul").addClass("loading")
        ic_quantity_update_send = false
        const wrap = $(input).closest(".woocommerce-mini-cart-item")
        const key = $(wrap).data("key")
        let number = parseInt($(input).val());
        if (!number || number < 1) {
            number = 1;
        }

        $(input).val(number)
        const data = {
            action: "lav_qty_update",
            key: key,
            number: number,
            security: lav_mini_cart_drawer.nonce
        }

        $.post(lav_mini_cart_drawer.ajax_url, data, (res) => {
            const cart_res = JSON.parse(res)
            $(".ic-cart-sidebar-wrapper_body  p.woocommerce-mini-cart__total.total .amount").html(cart_res["total"]);
            $(wrap).find(".ic-custom-render-total").html(cart_res["item_price"]);
            $(".ic-cart-sidebar-wrapper_body ul").removeClass("loading");

        });
    }
    body.on("click", ".ic-item-quantity-btn", function () {
        updateQutButtons($(this))
    });
    body.on("change blur", ".ic-cart-sidebar-wrapper_body input", function () {
        updateQutButtonsBlur($(this))
    })

    document.addEventListener('DOMContentLoaded', function () {
        $('[data-toggle="tooltip"]').tooltip();
        /*------------------------------------------------------------*/
        /*	Sticky Element
        /*------------------------------------------------------------*/
        const observedElement = document.querySelector('#sticky-section'); // Select the element to observe

        if (observedElement) {
            // Initialize Sticky instance outside of the observer to manage it globally
            let stickyInstance = new Sticky('#sticky-section');

            const observedElement = document.querySelector('.woocommerce-tabs.wc-tabs-wrapper'); // Select the element to observe

            if (observedElement) {
                const resizeObserver = new IntersectionObserver(entries => {
                    for (let entry of entries) {
                        if (entry.isIntersecting) {
                            stickyInstance.update();
                        }else {
                            stickyInstance = new Sticky('#sticky-section');
                        }
                    }
                });

                // Start observing the element
                resizeObserver.observe(observedElement);
            }
        }



        /*------------------------------------------------------------*/
        /*	SCROLL TO TOP
        /*------------------------------------------------------------*/

        const target = document.querySelector('#colophon') || document.querySelector('#scrollToTopBtnAnchor');
        const scrollToTopBtn = document.querySelector('.scrollToTopBtn');

        if (scrollToTopBtn) {
            const callback = (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        scrollToTopBtn.classList.add('showBtn');
                    } else {
                        scrollToTopBtn.classList.remove('showBtn');
                    }
                });
            };

            const scrollToTop = () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth',
                });
            };

            scrollToTopBtn.addEventListener('click', scrollToTop);
            const observer = new IntersectionObserver(callback);
            observer.observe(target);
        }


        if(typeof Swiper !== 'undefined'){
            // Gallery Slider in archive
            const swipers = document.querySelectorAll('.woocommerce .product-item .swiper-container');
            swipers.forEach((swiperContainer) => {
                new Swiper(swiperContainer, {
                    loop: true,
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                        dynamicBullets: true,
                    },
                });
            });
            // Gallery Slider in single product
            const galleryThumbs = new Swiper('.gallery-thumbs', {
                spaceBetween: 5,
                slidesPerView: 4,
                freeMode: false,
                watchSlidesVisibility: true,
                watchSlidesProgress: true,
            });
            // Gallery Slider in single product
            const galleryTop = new Swiper('.gallery-top', {
                spaceBetween: 5,
                loop: true,
                thumbs: {
                    swiper: galleryThumbs
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
            });
        }

        // Video Popup in single product
        Fancybox.bind(document.getElementById('alice-gallery-wrap-a'), "[data-fancybox]", {
            wheel: "slide",
            contentClick: "close",
        });

        // Video Popup in archive
        const videos = document.querySelectorAll('.site-main .product-item');
        if(videos.length) {
            videos.forEach((video) => {
                Fancybox.bind(video, "[data-fancybox]", {
                    wheel: "slide",
                    contentClick: "close",
                });
            });

        }

        const customGallery = document.querySelectorAll('.alice-masonry-grid');
        if(customGallery.length && typeof Macy !== 'undefined'){
            customGallery.forEach((image) => {
                Fancybox.bind(image, "[data-fancybox]", {
                    wheel: "slide",
                    contentClick: "close",
                });
            });

            Macy({
                container: '#custom-product-masonry-grid',
                trueOrder: false,
                waitForImages: false,
                margin: 25,
                columns: 5,
                breakAt: {
                    1200: 4,
                    940: 4,
                    520: 3,
                    400: 2
                }
            });

        }

        // Quick View
        $('.quick-view-btn').on('click', function(e) {
            e.preventDefault();
            const product_id = $(this).data('product_id');
            $.ajax({
                url: quickViewParams.ajax_url,
                type: 'POST',
                data: {
                    action: 'load_quick_view',
                    product_id: product_id,
                    nonce: quickViewParams.nonce
                },
                success: function(response) {
                    $('#quickViewModal .modal-body').html(response.data);
                    const galleryThumbs = new Swiper('.modal-body .gallery-thumbs', {
                        spaceBetween: 10,
                        slidesPerView: 4,
                        freeMode: false,
                        watchSlidesVisibility: true,
                        watchSlidesProgress: true,
                    });
                    const galleryTop = new Swiper('.modal-body .quick-view', {
                        spaceBetween: 10,
                        loop: true,
                        thumbs: {
                            swiper: galleryThumbs
                        },
                        navigation: {
                            nextEl: ".swiper-button-next",
                            prevEl: ".swiper-button-prev",
                        },
                    });
                    $('#quickViewModal').offcanvas('show');
                },
                error: function (response) {
                   return false;
                }
            });
        });


        // Sticky Bottom product
        const navBannerSticky = $('.alice-bottom-mobile-nav');


        const toggleSticky = (height, element) => {
            if ($(window).scrollTop() > height) {
                element.addClass('fixed-bottom');
            } else {
                element.removeClass('fixed-bottom');
            }
        }

        if (navBannerSticky) {
            $(window).on('scroll', () => {
                if (navBannerSticky.length) {
                    toggleSticky(window.innerHeight, navBannerSticky);
                } else {
                    toggleSticky(190, navBannerSticky);
                }
            });
        }

    });

    // WooCommerce's "added to cart" event (for archives and other areas)
    if($('#alice-add-to-cart-popup-notice').length){
        $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
            // Get the product name from the button (for archive) or form (for single page)
            const productTitle = $('h1.entry-title').text() || $button.closest('.product').find('h3.woocommerce-loop-product__title').text() ;

            // Update popup content with the product title
            $('#alice-add-to-cart-popup-notice .product-title-text').text(productTitle);

            // Show the popup
            $('#alice-add-to-cart-popup-notice').fadeIn();

            // Close the popup when "Continue Shopping" button is clicked
            $('.close-popup').click(function() {
                $('#alice-add-to-cart-popup-notice').fadeOut();
            });

            // Automatically close the popup after 5 seconds
            setTimeout(function() {
                $('#alice-add-to-cart-popup-notice').fadeOut();
            }, 5000);
        });

        // Single product page AJAX handling
        $('form.cart').on('submit', function(e) {
            const form = $(this);
            const formData = form.serialize(); // Get form data

            $.post(form.attr('action'), formData, function(response) {
                if (response.error && response.product_url) {
                    window.location = response.product_url;
                    return;
                }

                // Trigger the added_to_cart event to show the popup
                $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, form]);

            }).fail(function() {
                window.location = form.attr('action');
            });

            // Prevent default form submission
            e.preventDefault();
        });
    }


    if($('.alice-products .type-4').length){
        // Listen for the WooCommerce event when an item is added to the cart
        $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
            // Check if the button that triggered this is from the archive page
            if ($button && $button.hasClass('ajax_add_to_cart') ) {
                // Retrieve the cart URL from the data attribute and set it as the button's new href
                const cartUrl = $button.data('cart-url');
                const cartText = $button.data('cart-text');
                if (cartUrl && cartText){
                    $button.text(cartText);
                    $button.attr('href', cartUrl);
                }
                $button.removeClass('ajax_add_to_cart').addClass('view_cart_button');
            }
        });
    }

}(jQuery));
