<?php


use classes\providers\LavLayoutsProvider;

$lavPageRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavPageRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavLayout = $lavPageRenderer->getLayouts($lavGeneralLayout);


$lavLayout->renderSearchPage();
