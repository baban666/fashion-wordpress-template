<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$uid = wp_unique_id( 's-' ); // The search form specific unique ID for the input.

$aria_label = '';
if ( isset( $args['aria_label'] ) && ! empty( $args['aria_label'] ) ) {
	$aria_label = 'aria-label="' . esc_attr( $args['aria_label'] ) . '"';
}

?>

    <form role="search" class="search-form" method="get"
          action="<?php echo esc_url( home_url( '/' ) ); ?>" <?php echo esc_attr($aria_label) ;?>>
        <label class="screen-reader-text"
               for="<?php echo esc_attr( $uid ); ?>"><?php echo esc_html_x( 'Search for:', 'label', 'laveria' ); ?></label>
        <div class="input-group">
            <input type="search" class="field search-field form-control" id="<?php echo esc_attr( $uid ); ?>" name="s"
                   value="<?php the_search_query(); ?>"
                   placeholder="<?php echo esc_attr_x( 'Search &hellip;', 'placeholder', 'laveria' ); ?>">
            <button type="submit" class="wp-block-search__button  has-icon" aria-label="Search">
                <svg id="search-icon" class="search-icon" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M13.5 6C10.5 6 8 8.5 8 11.5c0 1.1.3 2.1.9 3l-3.4 3 1 1.1 3.4-2.9c1 .9 2.2 1.4 3.6 1.4 3 0 5.5-2.5 5.5-5.5C19 8.5 16.5 6 13.5 6zm0 9.5c-2.2 0-4-1.8-4-4s1.8-4 4-4 4 1.8 4 4-1.8 4-4 4z"></path>
                </svg>
            </button>
        </div>
    </form>
<?php
