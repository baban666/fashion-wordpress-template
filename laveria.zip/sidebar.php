<?php
use classes\providers\LavLayoutsProvider;

$lavSidebarRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavSidebarRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavLayout = $lavSidebarRenderer->getLayouts($lavGeneralLayout);

$lavLayout->renderSidebar();
