<?php
use classes\providers\LavLayoutsProvider;

$lavSingleRenderer = LavLayoutsProvider::getInstance();
$lavSettings = $lavSingleRenderer->getSettings()->getSettings();

$lavGeneralLayout = !empty($lavSettings['general-layout'])
	? $lavSettings['general-layout']
	: 'top-menu-layout';

$lavLayout = $lavSingleRenderer->getLayouts($lavGeneralLayout);


$lavLayout->renderSingle();
