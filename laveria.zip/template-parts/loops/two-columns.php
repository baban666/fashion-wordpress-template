<?php


use classes\providers\LavHelpersProvider;

$lavIsSticky      = is_sticky( get_the_ID() );
$lavColumnsNumber = $lavIsSticky ? 'col-md-12  card-item' : 'col-md-6  card-item';
$commentAlign          = $this->settings['global-loop-show-author'] ? 'text-end' : 'text-start';
$aValue = $this->metaBoxes->getPostMeta( get_the_ID(), 'meta-single-layout-amazon-rating' );

?>

<div class="<?php echo esc_attr( $lavColumnsNumber ); ?>">
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'card card-blog' ); ?>>
        <div class="card-head">
			<?php if ( $lavIsSticky ) : ?>
                <span class="badge sticky-badge">
                  <?php esc_html_e( 'Sticky post', 'laveria' ) ?>
                </span>
			<?php endif; ?>
			<?php if ( $this->settings['global-loop-show-category'] ): ?>
				<?php echo wp_kses_post( LavHelpersProvider::onePostCategory() ); ?>
			<?php endif; ?>
			<?php if ( $this->settings['global-loop-show-image'] ): ?>
            <a class="post-thumbnail d-block" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                <div class="card-image">
					<?php lav_post_thumbnail(); ?>
                </div>
            </a>
			<?php endif; ?>
        </div>
        <div class="card-body">
			<?php if ( 'post' === get_post_type() && ($this->settings['global-loop-show-date'] || $this->settings['global-loop-show-star']) ) : ?>
                <div class="entry-meta d-flex justify-content-between align-items-center">
					<?php if ( $this->settings['global-loop-show-date'] ): ?>
						<?php lav_posted_on(); ?>
					<?php endif; ?>
					<?php if ( $this->settings['global-loop-show-star'] && !empty($aValue) ): ?>
                        <div class="rating">
                            <i class="las fa-star"></i><span><?php echo esc_html($aValue) ?></span>
                        </div>
					<?php endif; ?>
                </div><!-- .entry-meta -->
			<?php endif; ?>
            <header class="entry-header">
				<?php if ( $this->settings['global-loop-show-title'] ): ?>
					<?php the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><h2 class="entry-title card-caption">', '</h2></a>' ); ?>
				<?php endif; ?>
            </header><!-- .entry-header -->
			<?php if ( $this->settings['global-loop-show-excerpt'] ): ?>
                <div class=" card-description">
					<?php echo LavHelpersProvider::getExcerpt( [ 'maxchar' => $this->settings['general-desc-char'] ] ); ?>
                </div>
			<?php endif; ?>
	        <?php if ( $this->getValue('global-loop-show-read-more') ): ?>
                <a  class="lav-btn-default" href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html__( 'Read more', 'laveria' ); ?></a>
	        <?php endif; ?>
            <footer class="entry-footer d-flex justify-content-between author-comments align-items-center">
	            <?php if ( $this->getValue('global-loop-show-author') ): ?>
		            <?php $this->components->getComponent( 'author-avatar' )->render(); ?>
	            <?php endif; ?>
				<?php if ( $this->settings['global-loop-show-comment'] ): ?>
                    <div class="comments">
                        <a href="<?php echo esc_url( get_comments_link() ); ?>">
                            <i class="las la-comment"></i>
							<?php echo get_comments_number(); ?>
                        </a>
                    </div>
				<?php endif; ?>
            </footer>
        </div>
    </article><!-- #post-<?php the_ID(); ?> -->
</div><!-- .end Card col -->
