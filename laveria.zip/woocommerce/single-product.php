<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woo.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

use classes\providers\LavComponentsProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$lavComponents = LavComponentsProvider::getInstance();
$shopSlug = $lavComponents->getValue('shop-single-product-layout') !== 'single-product'
	? 'woo-components/content-single-product/single-product'
	: 'content';
$mainType = $lavComponents->getValue('shop-single-product-layout');
$singleLayout = $lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'single-product-layout' );
if(!empty($singleLayout) && $singleLayout != 'global-single-product'){
	$shopSlug = $singleLayout !== 'default-single-product'
		? 'woo-components/content-single-product/single-product'
		: 'content';
	$mainType = $singleLayout !== 'default-single-product'
		? 'virtual'
		: 'single-product';
}

get_header( 'shop' ); ?>
    <!-- Start Content -->
    <div class="wrapper <?php echo esc_attr( 'col ps-md-2' ); ?>" id="page-wrapper">
        <div class="<?php echo esc_attr( $lavComponents->helper->getContainer( $lavComponents->getSettings()->getSettings() ) ); ?>"
             id="content" tabindex="-1">
            <!-- Start Main -->
            <main id="primary" class="site-main content-area col-md-12">
				<?php
				/**
				 * woocommerce_before_main_content hook.
				 *
				 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
				 * @hooked woocommerce_breadcrumb - 20
				 */
				do_action( 'woocommerce_before_main_content' );
				?>
				<?php while ( have_posts() ) : ?>
					<?php the_post(); ?>

					<?php wc_get_template_part( $shopSlug, $mainType ); ?>

				<?php endwhile; // end of the loop. ?>
				<?php
				/**
				 * woocommerce_after_main_content hook.
				 *
				 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
				 */
				do_action( 'woocommerce_after_main_content' );
				?>
				<?php
				/**
				 * woocommerce_sidebar hook.
				 *
				 * @hooked woocommerce_get_sidebar - 10
				 */
				// do_action( 'woocommerce_sidebar' );
				?>
            </main><!-- #main -->
            <!-- End Main -->
        </div><!-- #content -->

    </div><!-- #page-wrapper -->
    <!-- End Content -->
<?php
get_footer( 'shop' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
