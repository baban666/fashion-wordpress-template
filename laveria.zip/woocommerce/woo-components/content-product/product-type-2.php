<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

use classes\providers\LavComponentsProvider;

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 5 );
add_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 15 );

$lavComponents = LavComponentsProvider::getInstance();
$pid           = $product->get_id();
$price         = $product->get_price_html();
$name          = $product->get_name();
$link          = $product->get_permalink();
$type          = $product->get_type();
$review        = $product->get_review_count();
$count         = $product->get_rating_count();
$rating        = $product->get_average_rating();
$upsells       = $product->get_upsell_ids();


$stock = $lavComponents->getValue( 'shop-stock-enable' );

$attachment_ids = array();
if ( ! empty( $lavComponents->getValue( 'shop-gallery-enable' ) ) ) {
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
	$attachment_ids = $product->get_gallery_image_ids();
}

if ( $lavComponents->getValue( 'shop-rating-enable' ) ) {
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
}

if ( $lavComponents->getValue( 'shop-sale-enable' ) ) {
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
}
?>

<div class="product-item custom-product-type type-2 grid-product <?php echo esc_attr( $lavComponents->helper->getProductColumn( wc_get_loop_prop( 'columns' ) ) ); ?>">
    <div <?php wc_product_class( ' ', $product ); ?>>
	    <?php $lavComponents->getComponent('demo-icon')->render(); ?>
		<?php
		/**
		 * Hook: woocommerce_before_shop_loop_item.
		 *
		 * @hooked woocommerce_template_loop_product_link_open - 10
		 */
		do_action( 'woocommerce_before_shop_loop_item' );

		/**
		 * Hook: woocommerce_before_shop_loop_item_title.
		 *
		 * @hooked woocommerce_show_product_loop_sale_flash - 10
		 * @hooked woocommerce_template_loop_product_thumbnail - 10
		 */

		do_action( 'woocommerce_before_shop_loop_item_title' );

		if ( $lavComponents->getValue( 'shop-rating-count-enable' ) ) {
			$lavComponents->getComponent( 'rating-count' )->render( array( 'type'   => 2,
			                                                               'rating' => $rating,
			                                                               'count'  => $count,
			                                                               'review' => $review
			) );
		}

		if ( $lavComponents->getValue( 'shop-discount-enable' ) ) {
			$lavComponents->getComponent( 'product-discount' )->render( array( 'echo'  => true,
			                                                                   'style' => true,
			                                                                   'pid'   => null
			) );
		}

		?>
		<?php if ( ! empty( $lavComponents->getValue( 'shop-gallery-enable' ) ) ): ?>
            <div class="swiper-container">
	            <?php $lavComponents->getComponent( 'product-countdown' )->render(); ?>
                <div class="swiper-wrapper">
					<?php
					// Main Image
					echo '<div class="swiper-slide">' . wp_get_attachment_image( $product->get_image_id(), 'woocommerce_thumbnail' ) . '</div>';

					// Gallery Images
					foreach ( $attachment_ids as $attachment_id ) {
						echo '<div class="swiper-slide">' . wp_get_attachment_image( $attachment_id, 'woocommerce_thumbnail' ) . '</div>';
					}
					?>
                </div>
                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>
            </div>
		<?php endif; ?>

		<?php
		/**
		 * Hook: woocommerce_shop_loop_item_title.
		 *
		 * @hooked woocommerce_template_loop_product_title - 10
		 */
		do_action( 'woocommerce_shop_loop_item_title' );

		/**
		 * Hook: woocommerce_after_shop_loop_item_title.
		 *
		 * @hooked woocommerce_template_loop_rating - 5
		 * @hooked woocommerce_template_loop_price - 10
		 */

		?>
        <div class="product-actions hint-top">
		    <?php $lavComponents->getComponent( 'quick-view' )->render($product->get_id()); ?>
		    <?php $lavComponents->getComponent( 'video-icon' )->render(); ?>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 rating-and-price">
					<?php $lavComponents->getComponent( 'stock-status' )->render(); ?>
					<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
					<?php $lavComponents->getComponent( 'fake-sales' )->render(); ?>
                </div>
                <div class="product-footer">
                    <div class="col-12 features-deck">
		                <?php $lavComponents->getComponent( 'product-features' )->render(); ?>
                    </div>
                    <div class="col-12 buttons-deck">
		                <?php
		                /**
		                 * Hook: woocommerce_after_shop_loop_item.
		                 *
		                 * @hooked woocommerce_template_loop_product_link_close - 5
		                 * @hooked woocommerce_template_loop_add_to_cart - 10
		                 */
		                do_action( 'woocommerce_after_shop_loop_item' );
		                ?>
		                <?php $lavComponents->getComponent( 'product-custom-button' )->render(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
