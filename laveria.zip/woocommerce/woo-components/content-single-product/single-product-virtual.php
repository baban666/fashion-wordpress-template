<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woo.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

use classes\providers\LavComponentsProvider;

defined( 'ABSPATH' ) || exit;

global $product;
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_template_single_meta', 15 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 3 );

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.

	return;
}
$bootstrapColumns = 12;
$lavComponents = LavComponentsProvider::getInstance();
$galleryColumn = !empty($lavComponents->getValue('shop-single-product-gallery-width'))
	? $lavComponents->getValue('shop-single-product-gallery-width')
	: 6;
$galleryType = $lavComponents->getValue('shop-single-product-gallery-type');
$stickySummary = $lavComponents->getValue('shop-sticky-summary-enable')
	? 'sticky-section'
	: 'in-sticky-section';

add_filter( 'woocommerce_single_product_image_gallery_classes', function( $classes ) {
	$lavCompon = LavComponentsProvider::getInstance();
	$galleryColumn = !empty($lavCompon->getValue('shop-single-product-gallery-width'))
		? $lavCompon->getValue('shop-single-product-gallery-width')
		: 6;
	$classes[] = 'col-md-' . $galleryColumn;
	return $classes;
} );

$col = $bootstrapColumns - $galleryColumn;

if($galleryType == 'image-gallery'){
	$galleryType .=  '-virtual';
}

?>
	<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'lav-virtual-product', $product ); ?>>
        <div class="row">
            <?php
            /**
             * Hook: woocommerce_before_single_product_summary.
             *
             * @hooked woocommerce_show_product_sale_flash - 10
             * @hooked woocommerce_show_product_images - 20
             */
            if ( $galleryType != 'default' ){
	            wc_get_template_part( 'woo-components/single-product/product', $galleryType );
            }
            do_action( 'woocommerce_before_single_product_summary' );

            ?>

            <div data-sticky-container  class=" col-md-<?php echo esc_attr($col) ?> ">

                <div id="<?php echo esc_attr($stickySummary) ?>" data-sticky-for="992" data-margin-top="85" class="summary entry-summary">
                    <?php
                    /**
                     * Hook: woocommerce_single_product_summary.
                     *
                     * @hooked woocommerce_template_single_title - 5
                     * @hooked woocommerce_template_single_rating - 10
                     * @hooked woocommerce_template_single_price - 10
                     * @hooked woocommerce_template_single_excerpt - 20
                     * @hooked woocommerce_template_single_add_to_cart - 30
                     * @hooked woocommerce_template_single_meta - 40
                     * @hooked woocommerce_template_single_sharing - 50
                     * @hooked WC_Structured_Data::generate_product_data() - 60
                     */
                    do_action( 'woocommerce_single_product_summary' );
                    ?>
                    <?php if($lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-desc' )): ?>
                        <div class="button-desc text-center"><?php echo esc_html($lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-button-desc' )) ?></div>
                    <?php endif; ?>
                    <?php $lavComponents->getComponent('product-custom-button')->render(); ?>
                    <div class="btn-group btn-group-custom" role="group" aria-label="Custom buttons group">
                        <?php
                        $lavComponents->getComponent('delivery-popup')->render(get_the_ID());
                        $lavComponents->getComponent('sizes-popup')->render(get_the_ID());
                        $lavComponents->getComponent('return-popup')->render(get_the_ID());
                        $lavComponents->getComponent('custom-link')->render();
                        ?>
                    </div>
                    <div class="trusted-imag">
		                <?php
		                $lavComponents->getComponent('trusted-image')->render(get_the_ID());
		                ?>
                    </div>
                </div>
            </div>
            <?php
            /**
             * Hook: woocommerce_after_single_product_summary.
             *
             * @hooked woocommerce_output_product_data_tabs - 10
             * @hooked woocommerce_upsell_display - 15
             * @hooked woocommerce_output_related_products - 20
             */
            do_action( 'woocommerce_after_single_product_summary' );
            ?>

        </div>
	</div>
<?php  $lavComponents->getComponent('product-fix-bottom-banner')->render(get_the_ID()); ?>
<?php do_action( 'woocommerce_after_single_product' ); ?>
<?php

/* End the Loop */
