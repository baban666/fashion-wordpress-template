<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

use classes\providers\LavComponentsProvider;

defined( 'ABSPATH' ) || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
	return;
}

global $product;

$columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
$post_thumbnail_id = $product->get_image_id();
$wrapper_classes   = apply_filters(
	'woocommerce_single_product_image_gallery_classes',
	array(
		'woocommerce-product-gallery',
		'woocommerce-product-gallery--' . ( $post_thumbnail_id ? 'with-images' : 'without-images' ),
		'woocommerce-product-gallery--columns-' . absint( $columns ),
		'images',
	)
);
$lavComponents     = LavComponentsProvider::getInstance();
$videoType         = $lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'single-video-enable' );
$isVideo           = $videoType != 'video-disable';
$iframeVideo       = null;
$iframe_html       = null;

if ( $isVideo ) {
	$iframeVideo = $lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-youtube-pop' );
	$iframe_html      = '<iframe class="lazy" loading="lazy" src="https://www.youtube.com/embed/' . $iframeVideo . '?playlist=' . $iframeVideo . '&modestbranding=1&rel=0&controls=0&autoplay=1&enablejsapi=1&showinfo=0&mute=1&loop=1" allow="autoplay; fullscreen; accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" frameborder="0" allowfullscreen></iframe>';
}

$imagePlaceholder = sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'laveria' ) );
$attachment_ids   = $product->get_gallery_image_ids();

?>

<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>"
     data-columns="<?php echo esc_attr( $columns ); ?>">
    <div id="alice-gallery-wrap-a" class="woocommerce-product-gallery__wrapper">
	    <?php $lavComponents->getComponent('product-demo')->render(); ?>
        <?php
        if ( ! empty( $iframeVideo ) && $videoType == 'video-popup' ) {
	       echo   '<a class="popup-youtube fancybox" data-fancybox="gallery"  data-fancybox href="http://www.youtube.com/watch?v=' . $iframeVideo . '"><i class="lar la-play-circle"></i></a>';
        }
        ?>
        <div class="swiper-container gallery-top alice-swiper-container">
            <div class="swiper-wrapper">
				<?php
				if ( has_post_thumbnail() ) {
					$post_thumbnail_id   = $product->get_image_id();
					$post_thumbnail_url  = wp_get_attachment_url( $post_thumbnail_id );
					$image_full_size_url = wp_get_attachment_image_url( $post_thumbnail_id, 'full' );
					echo '<div class="swiper-slide"><div  class="popup-image fancybox" data-fancybox="gallery"  data-fancybox data-src="' . esc_url( $image_full_size_url ) . '"><img src="' . esc_url( $post_thumbnail_url ) . '"></div></div>';
				} else {
					echo '<div class="swiper-slide"><div  class="popup-image fancybox" data-fancybox="gallery"  data-fancybox  data-src="' . esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ) . '">' . $imagePlaceholder . '</div></div>';
				}
				foreach ( $attachment_ids as $attachment_id ) {
					$image_url           = wp_get_attachment_url( $attachment_id );
					$image_full_size_url = wp_get_attachment_image_url( $attachment_id, 'full' );
					echo '<div class="swiper-slide"><div class="popup-image" data-fancybox="gallery"  data-fancybox data-src="' . esc_url( $image_full_size_url ) . '"><img src="' . esc_url( $image_url ) . '"></div></div>';
				}
				if ( ! empty( $iframeVideo ) && $videoType == 'video-item' ) {
					echo '<div class="swiper-slide iframe-video"><div class="popup-youtube fancybox" data-fancybox="gallery"  data-fancybox data-src="http://www.youtube.com/watch?v=' . $iframeVideo . '"><i class="las la-arrows-alt"></i></div>' . $iframe_html . '</div>';
				}
				?>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
        </div>
        <div class="swiper-container gallery-thumbs alice-swiper-container">
            <div class="swiper-wrapper">
				<?php
				if ( has_post_thumbnail() ) {
					$post_thumbnail_id  = $product->get_image_id();
					$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
					echo '<div class="swiper-slide"><img src="' . esc_url( $post_thumbnail_url ) . '"></div>';
				} else {
					echo '<div class="swiper-slide">' . $imagePlaceholder . '</div>';
				}
				foreach ( $attachment_ids as $attachment_id ) {
					$image_url = wp_get_attachment_url( $attachment_id );
					echo '<div class="swiper-slide"><img src="' . esc_url( $image_url ) . '"></div>';
				}

				if (  ! empty( $iframeVideo ) && $videoType == 'video-item'  ) {
					echo '<div class="swiper-slide"><img src="' . esc_url( ALICE_CORE_IMG_URI . 'video-placeholder.jpg' ) . '"></div>';
				}
				?>
            </div>
            <div class="swiper-button-next alice-swiper-next alice-nav-bg "></div>
            <div class="swiper-button-prev alice-swiper-prev alice-nav-bg"></div>
        </div>
    </div>
    <div class="product-information">
		<?php
		// Product Rating
		$rating_count = $product->get_rating_count();
		$review_count = $product->get_review_count();
		$average      = $product->get_average_rating();

		if ( $rating_count > 0 ) : ?>

            <div class="woocommerce-product-rating">
				<?php echo wc_get_rating_html( $average, $rating_count ); // WPCS: XSS ok. ?>
				<?php if ( comments_open() ) : ?>
					<?php //phpcs:disable ?>
                    <a href="#reviews" class="woocommerce-review-link" rel="nofollow">(<?php printf( _n( '%s customer review', '%s customer reviews', $review_count, 'laveria' ), '<span class="count">' . esc_html( $review_count ) . '</span>' ); ?>)</a>
					<?php // phpcs:enable ?>
				<?php endif ?>
            </div>

		<?php endif; ?>
		<?php
		// Product Created Date
		$created_date = $product->get_date_created();
		echo '<div class="product-created-date product-meta-data">';
		echo '<span>'. esc_html__('Created: ', 'laveria') .'</span>' . $created_date->date('Y-m-d');
		echo '</div>';

		// Product Update Date
		$updated_date = $product->get_date_modified();
		echo '<div class="product-update-date product-meta-data">';
		echo '<span>'. esc_html__('Updated: ', 'laveria') .'</span>' . $updated_date->date('Y-m-d');
		echo '</div>';

		// SKU (Product Code)
		$sku = $product->get_sku();
		echo '<div class="product-sku product-meta-data">';
		echo '<span>'. esc_html__('SKU: ', 'laveria') .'</span>' . $sku;
		echo '</div>';
		?>
    </div>
	<?php
	$lavComponents->getComponent('custom-link')->render('two');
	$lavComponents->getComponent('share-buttons')->render(get_the_ID());
	?>
</div>
