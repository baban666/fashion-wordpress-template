<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

use classes\providers\LavComponentsProvider;

defined( 'ABSPATH' ) || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
	return;
}

global $product;

$columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
$post_thumbnail_id = $product->get_image_id();
$wrapper_classes   = apply_filters(
	'woocommerce_single_product_image_gallery_classes',
	array(
		'woocommerce-product-gallery',
		'woocommerce-product-gallery--' . ( $post_thumbnail_id ? 'with-images' : 'without-images' ),
		'woocommerce-product-gallery--columns-' . absint( $columns ),
		'images',
	)
);
$lavComponents     = LavComponentsProvider::getInstance();
$videoType         = $lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'single-video-enable' );
$isVideo           = $videoType != 'video-disable';
$iframeVideo       = null;
$iframe_html       = null;
$stackColumn       = $lavComponents->getValue( 'shop-single-product-stack-gallery-width' )
	? $lavComponents->getValue( 'shop-single-product-stack-gallery-width' )
	: 12;

$col = $stackColumn == 12 ? $stackColumn : 12 / $stackColumn;

if ( $isVideo ) {
	$iframeVideo = $lavComponents->metaBoxes->getProductMeta( get_the_ID(), 'meta-product-youtube-pop' );
	$iframe_html = '<iframe class="lazy" loading="lazy" src="https://www.youtube.com/embed/' . $iframeVideo . '?playlist=' . $iframeVideo . '&modestbranding=1&rel=0&controls=0&autoplay=1&enablejsapi=1&showinfo=0&mute=1&loop=1" allow="autoplay; fullscreen; accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" frameborder="0" allowfullscreen></iframe>';
}

$imagePlaceholder = sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'laveria' ) );
$attachment_ids   = $product->get_gallery_image_ids();
$i = 1;
$colMobile = 'col-6 ';

?>

<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>"
     data-columns="<?php echo esc_attr( $columns ); ?>">
    <div id="alice-gallery-wrap-a" class="woocommerce-product-gallery__wrapper">

		<?php
		if ( ! empty( $iframeVideo ) && $videoType == 'video-popup' ) {
			echo '<a class="popup-youtube fancybox" data-fancybox="gallery"  data-fancybox href="http://www.youtube.com/watch?v=' . $iframeVideo . '"><i class="lar la-play-circle"></i></a>';
		}
		?>
        <div class="row">
			<?php
			$lavComponents->getComponent( 'product-demo' )->render();
			if ( has_post_thumbnail() ) {
				$post_thumbnail_id   = $product->get_image_id();
				$post_thumbnail_url  = wp_get_attachment_url( $post_thumbnail_id );
				$image_full_size_url = wp_get_attachment_image_url( $post_thumbnail_id, 'full' );
				echo '<div class="col-12 mb-3"><div  class="popup-image fancybox" data-fancybox="gallery"  data-fancybox data-src="' . esc_url( $image_full_size_url ) . '"><img src="' . esc_url( $post_thumbnail_url ) . '">';
				echo '</div></div>';
			} else {
				echo '<div class="col-12 mb-3"><div  class="popup-image fancybox" data-fancybox="gallery"  data-fancybox  data-src="' . esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ) . '">' . $imagePlaceholder;
				$lavComponents->getComponent( 'product-demo' )->render();
				echo '</div></div>';
			}
			foreach ( $attachment_ids as $attachment_id ) {
				if (count($attachment_ids) > 0 && count($attachment_ids) % 2 != 0) {
					$colMobile = $i == count($attachment_ids) ? 'col-12 ': 'col-6 ';
				}
				$image_url           = wp_get_attachment_url( $attachment_id );
				$image_full_size_url = wp_get_attachment_image_url( $attachment_id, 'full' );
				echo '<div class="' . esc_attr( $colMobile ) . ' col-lg-' . esc_attr( $col ) . ' mb-3"><div class="popup-image" data-fancybox="gallery"  data-fancybox data-src="' . esc_url( $image_full_size_url ) . '"><img src="' . esc_url( $image_url ) . '"></div></div>';
				$i++;
			}
			if ( ! empty( $iframeVideo ) && $videoType == 'video-item' ) {
				echo '<div class="col-12 mb-3"><div class="iframe-video"><a class="popup-youtube fancybox" data-fancybox="gallery"  data-fancybox href="http://www.youtube.com/watch?v=' . $iframeVideo . '"><i class="las la-arrows-alt"></i></a>' . $iframe_html . '</div></div>';
			}

			?>
        </div>
    </div>
</div>
